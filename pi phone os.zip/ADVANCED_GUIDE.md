# Pi Phone OS - Advanced Features Guide

## Table of Contents

1. [Animations & Effects](#animations--effects)
2. [Lock Screen](#lock-screen)
3. [On-Screen Keyboard](#on-screen-keyboard)
4. [File Browser](#file-browser)
5. [Notifications](#notifications)
6. [Custom App Development](#custom-app-development)

---

## Animations & Effects

### Using Animations

Import the effects module:

```python
from effects import Animation, AnimationType

# Create a fade-in animation
anim = Animation(
    duration=0.5,
    anim_type=AnimationType.FADE_IN,
    on_complete=lambda: print("Animation done!")
)

# Apply to image
animated_image = anim.apply_to_image(image, width, height)

# Check if finished
if anim.finished:
    # Animation complete
    pass
```

### Available Animation Types

- `FADE_IN` - Fade image into view
- `FADE_OUT` - Fade image out
- `SLIDE_LEFT` - Slide from right to left
- `SLIDE_RIGHT` - Slide from left to right
- `SLIDE_UP` - Slide from bottom to top
- `SLIDE_DOWN` - Slide from top to bottom
- `SCALE` - Scale from 0 to 100%
- `BOUNCE` - Bouncing entrance
- `ROTATE` - Rotation effect

### Animation Manager

```python
from effects import AnimationManager

manager = AnimationManager()

# Add multiple animations
manager.add(Animation(0.5, AnimationType.FADE_IN))
manager.add(Animation(0.3, AnimationType.SLIDE_LEFT))

# Update each frame
manager.update()

# Check if active
if manager.has_active():
    # Still animating
    pass
```

### Screen Transitions

```python
from effects import TransitionEffect

transition = TransitionEffect(320, 480)

# Start transition
transition.start_transition("fade")  # or "slide_left", "slide_right"

# Apply each frame
next_frame = transition.apply(current_frame, new_frame)
```

### Notifications

```python
from effects import NotificationCenter

notif_center = NotificationCenter()

# Add notification
notif_center.add(
    title="Save Complete",
    message="File saved successfully",
    duration=2.0,
    notification_type="success"  # info, success, warning, error
)

# Render in your app
notif_center.render(draw, width, height, font)
```

### Progress Bar

```python
from effects import ProgressBar

progress = ProgressBar(width=200, height=10)

# Update progress
progress.set_progress(0.75)  # 75%
progress.update()

# Draw
progress.draw(draw, x, y, color=(100, 180, 255))
```

### Particle Effects

```python
from effects import ParticleEffect

particles = ParticleEffect()

# Emit particles
particles.emit(
    x=160, y=240,
    count=20,
    color=(100, 180, 255),
    speed=150,
    lifetime=0.5
)

# Update and draw
particles.update(delta_time=0.016)
particles.draw(draw, width, height)
```

---

## Lock Screen

The lock screen provides PIN-based device security.

### Enabling Lock Screen

In `ui.py`:

```python
from apps.lockscreen import LockScreen
from ui import AppID

# Add to apps dictionary
self.apps[AppID.LOCKSCREEN] = LockScreen(width, height)
```

### PIN Configuration

In `apps/lockscreen.py`:

```python
# Change default PIN
self.correct_pin = "1234"

# Adjust security settings
self.max_attempts = 5      # Attempts before lockout
self.locked_until = 0      # Seconds of lockout
```

### Features

- 6-digit PIN entry
- Visual PIN dots (● for entered, ○ for remaining)
- Automatic lockout after 5 failed attempts
- 60-second timeout before retry
- Error messages for incorrect PIN
- Date and time display
- Touch numpad

### Usage

User taps numbers to enter PIN, then presses ✓ to submit.

---

## On-Screen Keyboard

Integrated text input system with QWERTY keyboard.

### Using Text Input Field

```python
from keyboard import TextInputField, KeyboardManager

# Create input field
input_field = TextInputField(
    x=10, y=50,
    w=300, h=40,
    placeholder="Enter your name..."
)

# Create manager for multiple fields
kb_manager = KeyboardManager()
kb_manager.add_field(input_field)

# Handle touch
def on_tap(x, y):
    kb_manager.on_tap(x, y)

# Update each frame
kb_manager.update()

# Draw
kb_manager.draw(draw, font_default, font_small)

# Access text
entered_text = input_field.text
```

### Keyboard Features

- QWERTY layout
- Shift for uppercase
- Space bar
- Backspace
- Automatic shift toggle
- Cursor blinking
- Touch keyboard appears when field is tapped

### Customization

```python
# Extend Keyboard class
class CustomKeyboard(Keyboard):
    def _create_layout(self):
        # Custom layout
        pass
```

---

## File Browser

Browse and manage files on the device.

### Using File Browser

In home screen icons or app list:

```python
from apps.files import FileBrowser
from ui import AppID

# Add to apps
self.apps[AppID.FILES] = FileBrowser(width, height)
```

### Features

- Browse directories
- View file sizes
- Navigate with back button or swipe
- Directory history
- File selection
- Permission handling

### Storage Management

```python
from apps.files import StorageManager, CacheManager

# Disk usage
total, used, free = StorageManager.get_disk_usage("/")
print(f"Free: {StorageManager.format_size(free)}")

# Directory size
size = StorageManager.get_directory_size("/home/pi/Pictures")

# Free space percentage
free_percent = StorageManager.get_free_space_percent()

# Cache management
cache_size = CacheManager.get_cache_size()
freed_bytes = CacheManager.clear_cache()
```

---

## Notifications

System-wide notification management.

### Create Notification

```python
from effects import Notification, NotificationCenter

notif_center = NotificationCenter()

# Add various notifications
notif_center.add("Success", "Operation completed!", duration=2.0, notification_type="success")
notif_center.add("Error", "Something went wrong!", duration=3.0, notification_type="error")
notif_center.add("Info", "Important update available", duration=5.0, notification_type="info")
notif_center.add("Warning", "Low battery", duration=2.0, notification_type="warning")
```

### Notification Types

- `info` - Blue, informational
- `success` - Green, positive
- `warning` - Yellow, caution
- `error` - Red, alert

### Render Notifications

```python
# In your render() method
notif_center.render(draw, self.width, self.height, self.font_small)
```

---

## Custom App Development

### Creating a Custom App

1. Create file: `apps/myapp.py`

```python
from apps import BaseApp
from ui import AppID
from PIL import Image, ImageDraw
import logging

logger = logging.getLogger(__name__)

class MyApp(BaseApp):
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "My App"
        
        # Your app state
        self.counter = 0
    
    def on_activate(self) -> None:
        """Called when app opens"""
        logger.info(f"{self.name} activated")
    
    def on_tap(self, x: int, y: int) -> Optional[AppID]:
        """Handle tap, return AppID to navigate"""
        # Back button
        if 10 <= x < 70 and self.height - 45 <= y < self.height - 5:
            return AppID.HOME
        
        # Custom button
        if 100 <= x < 200 and 100 <= y < 150:
            self.counter += 1
            logger.info(f"Counter: {self.counter}")
        
        return None
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe"""
        if x2 - x1 > 50:  # Right swipe
            logger.info("Swiped right")
    
    def on_long_press(self, x: int, y: int) -> None:
        """Handle long press"""
        logger.info(f"Long press at {x}, {y}")
    
    def update(self) -> None:
        """Update app state each frame"""
        pass
    
    def render(self) -> Image.Image:
        """Render app"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), 
                                     color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Title
        draw.text((10, 10), self.name, fill=(200, 200, 200), font=self.font_title)
        
        # Counter display
        draw.text((160, 100), str(self.counter), fill=(100, 180, 255), 
                 font=self.font_title, anchor="mm")
        
        # Button
        draw.rectangle([(100, 100), (200, 150)], outline=(100, 100, 120), width=2)
        draw.text((150, 125), "Tap Me", fill=(180, 180, 200), 
                 font=self.font_default, anchor="mm")
        
        # Back button
        draw.rectangle([(10, self.height - 45), (60, self.height - 5)], 
                      outline=(100, 100, 120), width=2)
        draw.text((35, self.height - 25), "Back", fill=(180, 180, 200), 
                 font=self.font_small, anchor="mm")
        
        return self.framebuffer
```

2. Register in `ui.py`:

```python
from apps.myapp import MyApp

# Add to AppID enum
class AppID(Enum):
    HOME = "home"
    MYAPP = "myapp"  # Add this
    # ... other apps

# In UIManager.__init__()
self.apps[AppID.MYAPP] = MyApp(width, height)
```

3. Add icon to home screen (in `apps/home.py`):

```python
self.icons = [
    # ... existing icons
    AppIcon("My App", "⭐", AppID.MYAPP, 230, 50, 70),
]
```

### Advanced Features in Custom Apps

#### Using Animations

```python
from effects import Animation, AnimationType

class AnimatedApp(BaseApp):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.animations = []
    
    def trigger_animation(self):
        anim = Animation(0.5, AnimationType.SLIDE_LEFT)
        self.animations.append(anim)
    
    def update(self):
        self.animations = [a for a in self.animations if not a.finished]
        for anim in self.animations:
            anim.get_progress()
```

#### Using Notifications

```python
from effects import NotificationCenter

class NotifiedApp(BaseApp):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.notif_center = NotificationCenter()
    
    def on_tap(self, x, y):
        self.notif_center.add(
            "Alert",
            "You tapped the app!",
            notification_type="info"
        )
    
    def render(self):
        # ... render app
        self.notif_center.render(draw, self.width, self.height, self.font_small)
        return self.framebuffer
```

#### Using File Operations

```python
from apps.files import StorageManager
import os

class DataApp(BaseApp):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.data_dir = os.path.expanduser("~/.pi-phone/myapp")
        os.makedirs(self.data_dir, exist_ok=True)
    
    def save_data(self, data):
        filepath = os.path.join(self.data_dir, "data.txt")
        with open(filepath, 'w') as f:
            f.write(data)
    
    def load_data(self):
        filepath = os.path.join(self.data_dir, "data.txt")
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return f.read()
        return ""
```

### App Lifecycle

```
on_activate()
    ↓
on_touch_down() / on_tap() / on_swipe() / on_long_press()
    ↓
update()
    ↓
render()
    ↓ (repeat)
on_deactivate() [when navigating away]
```

---

## Performance Tips

1. **Minimize Redraws**: Only redraw changed areas if possible
2. **Cache Images**: Pre-load and cache images instead of loading each frame
3. **Use Simpler Fonts**: Default fonts are faster than custom fonts
4. **Reduce FPS**: Lower target FPS saves CPU
5. **Optimize Loops**: Avoid nested loops in render()
6. **Profile Code**: Use logging to identify bottlenecks

---

## Troubleshooting

### App Crashes on Tap
- Check `on_tap()` returns Optional[AppID]
- Verify AppID enum has the app defined
- Check for index out of bounds errors

### Animation Too Slow
- Reduce duration value
- Use simpler animation types
- Reduce target FPS less critical during animation

### Keyboard Not Appearing
- Ensure `TextInputField` is created
- Check `on_tap()` handler calls keyboard manager
- Verify keyboard is within visible area

### High Memory Usage
- Clear image cache
- Use `CacheManager.clear_cache()`
- Reduce image sizes
- Limit animation count

---

## Examples

See `apps/EXAMPLE_TODO.py` for a complete custom app example.

---

**Last Updated:** 2025
**Version:** Pi Phone OS 1.0+

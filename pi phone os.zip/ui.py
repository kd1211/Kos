"""
UI Manager - Handles screen rendering, app lifecycle, and navigation
"""

import logging
import time
from typing import Optional, Tuple, List
from enum import Enum

from PIL import Image, ImageDraw, ImageFont

from apps.home import HomeApp
from apps.settings import SettingsApp
from apps.paint import PaintApp
from apps.gallery import GalleryApp
from apps.music import MusicApp
from apps.terminal import TerminalApp

logger = logging.getLogger(__name__)


class AppID(Enum):
    """Application identifiers"""
    HOME = "home"
    SETTINGS = "settings"
    PAINT = "paint"
    GALLERY = "gallery"
    MUSIC = "music"
    TERMINAL = "terminal"


class UIManager:
    """Central UI manager - handles all screen rendering and touch events"""
    
    def __init__(self, width: int = 320, height: int = 480):
        """
        Initialize UI manager
        
        Args:
            width: Screen width
            height: Screen height
        """
        self.width = width
        self.height = height
        
        # Create framebuffer
        self.framebuffer = Image.new('RGB', (width, height), color=(15, 15, 20))
        self.draw = ImageDraw.Draw(self.framebuffer)
        
        # Load fonts
        self._load_fonts()
        
        # Initialize apps
        self.apps = {
            AppID.HOME: HomeApp(width, height),
            AppID.SETTINGS: SettingsApp(width, height),
            AppID.PAINT: PaintApp(width, height),
            AppID.GALLERY: GalleryApp(width, height),
            AppID.MUSIC: MusicApp(width, height),
            AppID.TERMINAL: TerminalApp(width, height),
        }
        
        # Current state
        self.current_app = AppID.HOME
        self.previous_app = None
        
        # Status bar
        self.status_time = ""
        self.status_battery = 100
        self.last_time_update = 0
        
        logger.info("UI Manager initialized")
    
    def _load_fonts(self) -> None:
        """Load system fonts"""
        try:
            self.font_large = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
            self.font_default = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
            self.font_small = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
        except:
            # Fallback to default font
            logger.warning("Could not load custom fonts, using default")
            self.font_large = ImageFont.load_default()
            self.font_default = ImageFont.load_default()
            self.font_small = ImageFont.load_default()
    
    def _update_status_bar(self) -> None:
        """Update status bar (time and battery)"""
        current_time = time.time()
        
        if current_time - self.last_time_update > 1.0:
            import datetime
            now = datetime.datetime.now()
            self.status_time = now.strftime("%H:%M")
            self.last_time_update = current_time
    
    def _draw_status_bar(self, img: Image.Image) -> None:
        """Draw top status bar with time and battery"""
        draw = ImageDraw.Draw(img)
        
        # Background
        draw.rectangle([(0, 0), (self.width, 30)], fill=(30, 30, 40))
        
        # Time
        draw.text((10, 6), self.status_time, fill=(200, 200, 200), font=self.font_small)
        
        # Battery indicator
        battery_w = 25
        battery_h = 12
        battery_x = self.width - battery_w - 10
        battery_y = 9
        
        # Battery outline
        draw.rectangle(
            [(battery_x, battery_y), (battery_x + battery_w, battery_y + battery_h)],
            outline=(100, 200, 100), width=1
        )
        
        # Battery fill
        battery_fill = int(battery_w * self.status_battery / 100)
        if self.status_battery > 20:
            fill_color = (100, 200, 100)
        else:
            fill_color = (200, 100, 100)
        
        draw.rectangle(
            [(battery_x + 1, battery_y + 1),
             (battery_x + battery_fill, battery_y + battery_h - 1)],
            fill=fill_color
        )
        
        # Battery cap
        draw.rectangle(
            [(battery_x + battery_w + 1, battery_y + 3),
             (battery_x + battery_w + 2, battery_y + battery_h - 3)],
            fill=(100, 200, 100)
        )
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Handle touch down event"""
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_touch_down'):
            current_app.on_touch_down(x, y)
    
    def on_touch_up(self, x: int, y: int) -> None:
        """Handle touch up event"""
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_touch_up'):
            current_app.on_touch_up(x, y)
    
    def on_touch_move(self, x: int, y: int, dx: int, dy: int) -> None:
        """Handle touch move event"""
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_touch_move'):
            current_app.on_touch_move(x, y, dx, dy)
    
    def on_tap(self, x: int, y: int) -> None:
        """Handle tap event"""
        # Check home button area
        if y < 30:
            return  # Can't tap status bar
        
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_tap'):
            result = current_app.on_tap(x, y)
            
            # Check if app returned a navigation request
            if isinstance(result, AppID):
                self.navigate_to_app(result)
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe event"""
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_swipe'):
            current_app.on_swipe(x1, y1, x2, y2)
    
    def on_long_press(self, x: int, y: int) -> None:
        """Handle long press event"""
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'on_long_press'):
            current_app.on_long_press(x, y)
    
    def navigate_to_app(self, app_id: AppID) -> None:
        """Navigate to a different app"""
        if app_id != self.current_app:
            logger.info(f"Navigating to {app_id.value}")
            self.previous_app = self.current_app
            self.current_app = app_id
            
            # Notify app of activation
            app = self.apps[app_id]
            if hasattr(app, 'on_activate'):
                app.on_activate()
    
    def navigate_back(self) -> None:
        """Navigate back to previous app"""
        if self.previous_app:
            self.navigate_to_app(self.previous_app)
        else:
            self.navigate_to_app(AppID.HOME)
    
    def update(self) -> None:
        """Update UI state"""
        self._update_status_bar()
        
        # Update current app
        current_app = self.apps[self.current_app]
        if hasattr(current_app, 'update'):
            current_app.update()
    
    def render(self) -> Image.Image:
        """
        Render current frame
        
        Returns:
            PIL Image of the current frame
        """
        # Create fresh framebuffer
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        
        # Render app
        current_app = self.apps[self.current_app]
        app_frame = current_app.render()
        
        # Composite app onto framebuffer (app renders full screen including status bar)
        self.framebuffer = app_frame
        
        # Draw status bar on top
        self._draw_status_bar(self.framebuffer)
        
        return self.framebuffer

"""
Touch controller driver for FT6336U capacitive touch sensor via I2C
Handles coordinate mapping and touch event detection
"""

import logging
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class Touch:
    """I2C touch controller for FT6336U"""
    
    # I2C Address
    FT6336U_I2C_ADDR = 0x38
    
    # Registers
    REG_TD_STATUS = 0x02       # Touch point status
    REG_TP1_XH = 0x03          # Touch point 1 X high byte
    REG_TP1_XL = 0x04          # Touch point 1 X low byte
    REG_TP1_YH = 0x05          # Touch point 1 Y high byte
    REG_TP1_YL = 0x06          # Touch point 1 Y low byte
    REG_TP2_XH = 0x09          # Touch point 2 X high byte
    REG_TP2_XL = 0x0A          # Touch point 2 X low byte
    REG_TP2_YH = 0x0B          # Touch point 2 Y high byte
    REG_TP2_YL = 0x0C          # Touch point 2 Y low byte
    
    # Touch state
    TOUCH_STATE_UP = 0x01
    TOUCH_STATE_DOWN = 0x00
    
    def __init__(self, width: int = 320, height: int = 480, demo_mode: bool = False):
        """
        Initialize touch controller
        
        Args:
            width: Display width
            height: Display height
            demo_mode: If True, run without hardware
        """
        self.width = width
        self.height = height
        self.demo_mode = demo_mode
        
        self.smbus = None
        self.bus_num = 1  # Raspberry Pi I2C bus 1
        
        logger.info(f"Initializing touch controller {width}x{height}")
        
        if not demo_mode:
            self._init_i2c()
        else:
            logger.info("Running in demo mode (no hardware)")
    
    def _init_i2c(self) -> None:
        """Initialize I2C bus"""
        try:
            import smbus
            self.smbus = smbus.SMBus(self.bus_num)
            logger.info(f"I2C bus {self.bus_num} initialized")
        except Exception as e:
            logger.error(f"Failed to initialize I2C: {e}")
            raise
    
    def read(self) -> Optional[Tuple[int, int]]:
        """
        Read touch coordinates from FT6336U
        
        Returns:
            Tuple of (x, y) if touch detected, None if not touched
        """
        if self.demo_mode or not self.smbus:
            return None
        
        try:
            # Read touch status
            status = self.smbus.read_byte_data(self.FT6336U_I2C_ADDR, self.REG_TD_STATUS)
            
            # Check if any touch points are active (bits 0-3 = number of touches)
            num_touches = status & 0x0F
            
            if num_touches == 0:
                return None
            
            # Read first touch point
            x_high = self.smbus.read_byte_data(self.FT6336U_I2C_ADDR, self.REG_TP1_XH)
            x_low = self.smbus.read_byte_data(self.FT6336U_I2C_ADDR, self.REG_TP1_XL)
            y_high = self.smbus.read_byte_data(self.FT6336U_I2C_ADDR, self.REG_TP1_YH)
            y_low = self.smbus.read_byte_data(self.FT6336U_I2C_ADDR, self.REG_TP1_YL)
            
            # Extract coordinates (10-bit values)
            # Remove flag bits from X and Y high bytes
            x = ((x_high & 0x0F) << 8) | x_low
            y = ((y_high & 0x0F) << 8) | y_low
            
            # Clamp to valid range
            x = max(0, min(self.width - 1, x))
            y = max(0, min(self.height - 1, y))
            
            return (x, y)
        
        except Exception as e:
            logger.warning(f"Touch read error: {e}")
            return None
    
    def calibrate(self) -> None:
        """
        Calibration routine (optional)
        Can be used to test touch points and verify orientation
        """
        logger.info("Touch calibration started")
        logger.info("Touch the four corners of the screen when prompted")
        
        # This would require UI feedback, so for now it's a placeholder
        logger.info("Calibration skipped - using default orientation")
    
    def cleanup(self) -> None:
        """Clean up I2C resources"""
        try:
            if self.smbus:
                self.smbus.close()
            logger.info("Touch cleanup complete")
        except Exception as e:
            logger.error(f"Error cleaning up touch: {e}")

#!/usr/bin/env python3
"""
Hardware Diagnostics Utility for Pi Phone OS
Tests display, touch, and GPIO without running the full UI
"""

import sys
import time
import logging
from typing import Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_gpio() -> bool:
    """Test GPIO availability"""
    logger.info("Testing GPIO...")
    try:
        import RPi.GPIO as GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(25, GPIO.OUT)
        GPIO.setup(27, GPIO.OUT)
        GPIO.output(25, GPIO.HIGH)
        GPIO.output(25, GPIO.LOW)
        GPIO.cleanup()
        logger.info("✓ GPIO test passed")
        return True
    except Exception as e:
        logger.error(f"✗ GPIO test failed: {e}")
        return False


def test_spi() -> bool:
    """Test SPI interface"""
    logger.info("Testing SPI...")
    try:
        from spidev import SpiDev
        spi = SpiDev()
        spi.open(0, 0)
        spi.max_speed_hz = 1000000
        # Send dummy byte
        spi.writebytes([0xFF])
        spi.close()
        logger.info("✓ SPI test passed")
        return True
    except Exception as e:
        logger.error(f"✗ SPI test failed: {e}")
        return False


def test_i2c() -> bool:
    """Test I2C interface and FT6336U detection"""
    logger.info("Testing I2C and FT6336U...")
    try:
        import smbus
        bus = smbus.SMBus(1)
        
        # Try to detect FT6336U at 0x38
        try:
            data = bus.read_byte_data(0x38, 0x00)
            logger.info(f"✓ FT6336U detected at 0x38 (chip ID: 0x{data:02x})")
            bus.close()
            return True
        except Exception as e:
            logger.warning(f"✗ FT6336U not detected: {e}")
            logger.info("  Check I2C connections and enable I2C in raspi-config")
            bus.close()
            return False
    except Exception as e:
        logger.error(f"✗ I2C test failed: {e}")
        return False


def test_display_initialization() -> bool:
    """Test display initialization sequence"""
    logger.info("Testing display initialization...")
    try:
        from display import Display
        display = Display(320, 480, 10000000, demo_mode=False)
        logger.info("✓ Display initialized successfully")
        display.cleanup()
        return True
    except Exception as e:
        logger.error(f"✗ Display initialization failed: {e}")
        return False


def test_touch_reading() -> bool:
    """Test touch reading"""
    logger.info("Testing touch input...")
    try:
        from touch import Touch
        touch = Touch(320, 480, demo_mode=False)
        
        logger.info("Waiting for touch input (5 seconds)...")
        start_time = time.time()
        touched = False
        
        while time.time() - start_time < 5:
            data = touch.read()
            if data:
                x, y = data
                logger.info(f"✓ Touch detected at ({x}, {y})")
                touched = True
                break
            time.sleep(0.1)
        
        if not touched:
            logger.warning("✗ No touch detected (hardware may not be connected)")
        
        touch.cleanup()
        return touched
    except Exception as e:
        logger.error(f"✗ Touch test failed: {e}")
        return False


def test_image_rendering() -> bool:
    """Test image rendering"""
    logger.info("Testing image rendering...")
    try:
        from PIL import Image, ImageDraw
        
        # Create test image
        img = Image.new('RGB', (320, 480), color=(0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        # Draw some shapes
        draw.rectangle([(10, 10), (100, 100)], fill=(255, 0, 0))
        draw.ellipse([(150, 150), (250, 250)], fill=(0, 255, 0))
        draw.text((160, 240), "Test", fill=(0, 0, 255))
        
        logger.info("✓ Image rendering works")
        return True
    except Exception as e:
        logger.error(f"✗ Image rendering failed: {e}")
        return False


def run_full_diagnostic() -> None:
    """Run complete hardware diagnostic"""
    logger.info("=" * 50)
    logger.info("Pi Phone OS - Hardware Diagnostic")
    logger.info("=" * 50)
    
    results = {
        "GPIO": False,
        "SPI": False,
        "I2C": False,
        "Display": False,
        "Touch": False,
        "Image Rendering": False,
    }
    
    # Run tests
    results["GPIO"] = test_gpio()
    results["SPI"] = test_spi()
    results["I2C"] = test_i2c()
    results["Image Rendering"] = test_image_rendering()
    
    # Only test display if SPI is working
    if results["SPI"]:
        results["Display"] = test_display_initialization()
    
    # Only test touch if I2C is working
    if results["I2C"]:
        results["Touch"] = test_touch_reading()
    
    # Summary
    logger.info("=" * 50)
    logger.info("Diagnostic Results:")
    logger.info("=" * 50)
    
    passed = 0
    failed = 0
    
    for test_name, result in results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        logger.info(f"{test_name:20} {status}")
        if result:
            passed += 1
        else:
            failed += 1
    
    logger.info("=" * 50)
    logger.info(f"Passed: {passed}/{len(results)}")
    logger.info(f"Failed: {failed}/{len(results)}")
    
    if failed == 0:
        logger.info("✓ All tests passed! Ready to run Pi Phone OS")
    else:
        logger.warning(f"✗ {failed} test(s) failed. Check connections and configuration.")
    
    logger.info("=" * 50)


def interactive_test() -> None:
    """Interactive testing mode"""
    logger.info("Interactive Hardware Test")
    logger.info("Options:")
    logger.info("  1 - Test GPIO")
    logger.info("  2 - Test SPI")
    logger.info("  3 - Test I2C")
    logger.info("  4 - Test Display")
    logger.info("  5 - Test Touch")
    logger.info("  6 - Full Diagnostic")
    logger.info("  7 - Test Image Rendering")
    logger.info("  0 - Exit")
    
    while True:
        try:
            choice = input("\nSelect test (0-7): ").strip()
            
            if choice == '0':
                break
            elif choice == '1':
                test_gpio()
            elif choice == '2':
                test_spi()
            elif choice == '3':
                test_i2c()
            elif choice == '4':
                test_display_initialization()
            elif choice == '5':
                test_touch_reading()
            elif choice == '6':
                run_full_diagnostic()
            elif choice == '7':
                test_image_rendering()
            else:
                logger.info("Invalid selection")
        except KeyboardInterrupt:
            break


def main():
    """Entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Pi Phone OS Hardware Diagnostics')
    parser.add_argument('--interactive', '-i', action='store_true',
                       help='Run interactive testing mode')
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_test()
    else:
        run_full_diagnostic()


if __name__ == "__main__":
    main()

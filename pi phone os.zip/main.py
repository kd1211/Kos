#!/usr/bin/env python3
"""
Pi Phone OS - A lightweight touchscreen phone UI for Raspberry Pi Zero
Supports: Waveshare 3.5inch Capacitive Touch LCD (320x480)
Hardware: ST7796S display driver, FT6336U touch controller
"""

import sys
import time
import logging
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Hardware imports (safe fallback for development)
try:
    import RPi.GPIO as GPIO
    from spidev import SpiDev
    import smbus
    HARDWARE_AVAILABLE = True
except (ImportError, RuntimeError) as e:
    logger.warning(f"Hardware modules not available: {e}. Running in demo mode.")
    HARDWARE_AVAILABLE = False

from PIL import Image, ImageDraw, ImageFont
import numpy as np

from display import Display
from touch import Touch
from ui import UIManager


class PhoneOS:
    """Main OS controller - handles display, touch, and app lifecycle"""
    
    def __init__(self, width: int = 320, height: int = 480, spi_speed: int = 10000000):
        """
        Initialize the phone OS
        
        Args:
            width: Display width in pixels
            height: Display height in pixels
            spi_speed: SPI clock speed in Hz
        """
        self.width = width
        self.height = height
        self.spi_speed = spi_speed
        self.running = False
        
        logger.info("Initializing Pi Phone OS...")
        
        # Initialize hardware
        try:
            self.display = Display(width, height, spi_speed, HARDWARE_AVAILABLE)
            self.touch = Touch(width, height, HARDWARE_AVAILABLE)
            logger.info("Hardware initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize hardware: {e}")
            raise
        
        # Initialize UI manager
        self.ui = UIManager(width, height)
        
        # Timing
        self.last_frame_time = time.time()
        self.frame_count = 0
        self.target_fps = 15  # Low FPS for Pi Zero (~66ms per frame)
        self.frame_time = 1.0 / self.target_fps
        
        # Touch state
        self.last_touch_pos = None
        self.touch_start_time = None
        self.touch_start_pos = None
        
    def handle_touch(self) -> None:
        """Process touch input and send to UI manager"""
        touch_data = self.touch.read()
        
        if not touch_data:
            self.last_touch_pos = None
            self.touch_start_time = None
            return
        
        x, y = touch_data
        current_time = time.time()
        
        # Touch press (first contact)
        if self.last_touch_pos is None:
            self.touch_start_pos = (x, y)
            self.touch_start_time = current_time
            self.ui.on_touch_down(x, y)
            logger.debug(f"Touch down: {x}, {y}")
        
        # Touch move
        elif self.last_touch_pos != (x, y):
            dx = x - self.touch_start_pos[0]
            dy = y - self.touch_start_pos[1]
            self.ui.on_touch_move(x, y, dx, dy)
        
        self.last_touch_pos = (x, y)
        
        # Check for tap vs swipe on release (done in a separate method)
    
    def handle_touch_release(self) -> None:
        """Handle touch release and distinguish between tap and swipe"""
        if self.last_touch_pos is None or self.touch_start_pos is None:
            return
        
        current_time = time.time()
        touch_duration = current_time - self.touch_start_time
        
        dx = self.last_touch_pos[0] - self.touch_start_pos[0]
        dy = self.last_touch_pos[1] - self.touch_start_pos[1]
        distance = (dx**2 + dy**2)**0.5
        
        # Swipe threshold: > 30 pixels AND < 500ms
        if distance > 30 and touch_duration < 0.5:
            self.ui.on_swipe(
                self.touch_start_pos[0], self.touch_start_pos[1],
                self.last_touch_pos[0], self.last_touch_pos[1]
            )
            logger.debug(f"Swipe: {dx}, {dy}")
        
        # Tap: < 30 pixels AND < 300ms
        elif distance < 30 and touch_duration < 0.3:
            self.ui.on_tap(self.last_touch_pos[0], self.last_touch_pos[1])
            logger.debug(f"Tap: {self.last_touch_pos}")
        
        # Long press: stationary for > 500ms
        elif distance < 15 and touch_duration > 0.5:
            self.ui.on_long_press(self.touch_start_pos[0], self.touch_start_pos[1])
            logger.debug(f"Long press: {self.touch_start_pos}")
        
        self.ui.on_touch_up(self.last_touch_pos[0], self.last_touch_pos[1])
        self.last_touch_pos = None
        self.touch_start_time = None
    
    def update(self) -> None:
        """Update game state and UI"""
        # Check if touch is still active
        current_touch = self.touch.read()
        
        if current_touch and self.last_touch_pos is None:
            self.handle_touch()
        elif current_touch and self.last_touch_pos is not None:
            self.handle_touch()
        elif not current_touch and self.last_touch_pos is not None:
            self.handle_touch_release()
        
        # Update UI state
        self.ui.update()
    
    def render(self) -> None:
        """Render current frame to display"""
        # Render UI to image buffer
        frame = self.ui.render()
        
        # Display image
        self.display.show_image(frame)
    
    def run(self) -> None:
        """Main event loop"""
        self.running = True
        logger.info("Starting main loop...")
        
        try:
            while self.running:
                frame_start = time.time()
                
                # Update and render
                self.update()
                self.render()
                
                # Frame timing
                frame_time_actual = time.time() - frame_start
                sleep_time = max(0, self.frame_time - frame_time_actual)
                time.sleep(sleep_time)
                
                self.frame_count += 1
                
                # Log FPS every 30 frames
                if self.frame_count % 30 == 0:
                    elapsed = time.time() - self.last_frame_time
                    fps = 30 / elapsed if elapsed > 0 else 0
                    logger.debug(f"FPS: {fps:.1f}")
                    self.last_frame_time = time.time()
        
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception as e:
            logger.error(f"Error in main loop: {e}", exc_info=True)
        finally:
            self.shutdown()
    
    def shutdown(self) -> None:
        """Clean up resources"""
        logger.info("Shutting down...")
        self.running = False
        
        try:
            self.display.cleanup()
            self.touch.cleanup()
            if HARDWARE_AVAILABLE:
                GPIO.cleanup()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        
        logger.info("Goodbye!")


def main():
    """Entry point"""
    try:
        os = PhoneOS()
        os.run()
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

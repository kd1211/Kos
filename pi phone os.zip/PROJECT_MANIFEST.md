# Pi Phone OS - Complete Project Manifest

## Project Overview

**Pi Phone OS** is a lightweight, fully-featured touch-driven operating system UI for Raspberry Pi Zero with Waveshare 3.5" capacitive touch display. It provides a complete smartphone-like experience with modular apps, animations, notifications, and system features.

**Current Version:** 1.0+  
**Target Hardware:** Raspberry Pi Zero / Zero W  
**Display:** Waveshare 3.5" Capacitive Touch LCD (320x480)  
**Performance:** 15 FPS, ~15-25% CPU, ~50-80 MB RAM  

---

## Complete File Listing

### Core System Files

```
pi_phone_ui/
├── main.py                      # Main event loop and OS controller
│   - PhoneOS class: Main OS lifecycle
│   - Touch handling (tap, swipe, long press)
│   - Frame timing and FPS control
│   - Hardware initialization
│
├── display.py                   # ST7796S SPI display driver
│   - Hardware initialization
│   - Image rendering to SPI
│   - 18-bit color conversion
│   - Display commands and data
│
├── touch.py                     # FT6336U I2C touch controller
│   - I2C communication
│   - Touch coordinate reading
│   - Touch filtering
│
├── ui.py                        # UI manager and app navigation
│   - App lifecycle management
│   - Navigation system
│   - Status bar rendering
│   - Touch event routing
│
├── config.py                    # Centralized configuration
│   - GPIO pin definitions
│   - Display and touch settings
│   - UI colors and themes
│   - Performance parameters
│
├── effects.py                   # Advanced visual effects
│   - Animation system
│   - Notifications
│   - Transitions
│   - Progress bars
│   - Particle effects
│
├── keyboard.py                  # On-screen text input
│   - QWERTY keyboard layout
│   - Text input fields
│   - Shift and modifiers
│   - Keyboard manager
│
├── test_hardware.py             # Hardware diagnostics tool
│   - GPIO testing
│   - SPI testing
│   - I2C and FT6336U detection
│   - Display initialization test
│   - Touch reading test
│   - Interactive test mode
│
└── requirements.txt             # Python dependencies
    - Pillow: Image processing
    - numpy: Numerical operations
    - spidev: SPI interface
    - RPi.GPIO: GPIO control
    - smbus-cffi: I2C communication
```

### Built-in Apps

```
apps/
├── __init__.py                  # BaseApp class template
│   - Base functionality for all apps
│   - Touch event handlers
│   - Rendering framework
│   - Font management
│
├── home.py                      # Home screen / App launcher
│   - 3x2 or 3x3 app grid
│   - App icons with labels
│   - Quick info display
│
├── settings.py                  # System settings
│   - Display settings
│   - Device information
│   - Hardware details
│
├── paint.py                     # Drawing / Paint app
│   - Freehand drawing
│   - Color palette (6 colors)
│   - Adjustable brush
│   - Canvas operations
│
├── gallery.py                   # Image viewer
│   - Browse ~/Pictures
│   - Image scaling and centering
│   - Swipe navigation
│   - Image counter
│
├── music.py                     # Music player UI
│   - Play/pause controls
│   - Next/previous buttons
│   - Progress bar
│   - Time display
│
├── terminal.py                  # Command terminal
│   - Command interface
│   - Built-in commands (help, clear, info, time, echo, version)
│   - Command history
│   - Extensible command system
│
├── lockscreen.py                # PIN-based lock screen
│   - 6-digit PIN entry
│   - Numpad interface
│   - Automatic lockout
│   - Failed attempt tracking
│
├── files.py                     # File browser and storage
│   - Directory browsing
│   - File listing with sizes
│   - Permission handling
│   - Storage statistics
│   - Cache management
│
├── EXAMPLE_TODO.py              # Example custom app template
│   - Todo list functionality
│   - Item management
│   - Complete integration guide
│
└── EXAMPLE_ADVANCED.py          # Advanced features showcase
    - Notifications
    - Animations
    - Text input
    - File I/O
    - Multi-screen navigation
    - Particle effects
```

### Documentation

```
├── README.md                    # Setup and usage guide
│   - Hardware requirements
│   - Hardware setup instructions
│   - Installation steps
│   - Usage guide
│   - Troubleshooting
│   - Configuration options
│   - Development tips
│
├── ADVANCED_GUIDE.md            # Advanced features manual
│   - Animation system
│   - Lock screen configuration
│   - On-screen keyboard usage
│   - File browser features
│   - Notifications
│   - Custom app development
│   - Performance tips
│
├── QUICKREF.txt                 # Quick reference card
│   - Feature list
│   - Hardware support
│   - UI overview
│   - Built-in apps
│   - Touch gestures
│   - Performance specs
│   - Color scheme
│   - Troubleshooting quick fixes
│
└── PROJECT_MANIFEST.txt (this file)
    - Complete project overview
    - File structure
    - Feature list
    - API reference
    - Examples
```

---

## Core Features

### System Features

✅ **Event Loop**
- 15 FPS target (adjustable)
- Touch event handling
- Frame timing and FPS control
- Hardware initialization and cleanup

✅ **Display Management**
- ST7796S SPI driver
- 320x480 resolution
- Double buffering
- 18-bit RGB color
- Hardware initialization

✅ **Touch Input**
- FT6336U I2C controller
- TAP detection (< 300ms, < 30px)
- SWIPE detection (> 30px, < 500ms)
- LONG PRESS detection (> 500ms)
- Coordinate mapping

✅ **App System**
- Modular app architecture
- App lifecycle management
- Navigation system (home, back)
- BaseApp template
- State management

✅ **Status Bar**
- Current time display
- Battery indicator (simulated)
- Always-on display
- System information

### UI Features

✅ **Visual Effects**
- Fade in/out animations
- Slide transitions
- Scale animations
- Bounce effects
- Particle systems
- Progress bars
- Smooth transitions

✅ **Notifications**
- Info, success, warning, error types
- Auto-dismissing
- Manual dismiss
- Color-coded
- Non-intrusive display

✅ **Text Input**
- On-screen QWERTY keyboard
- Shift for uppercase
- Backspace/delete
- Cursor blinking
- Multi-field support

✅ **File Management**
- Directory browsing
- File listing
- Size display
- Permission handling
- File operations
- Cache management
- Storage statistics

### Built-in Apps

✅ **Home Screen**
- App grid launcher (customizable layout)
- App icons with labels
- Quick information

✅ **Settings**
- Device information
- Hardware details
- Configurable options

✅ **Paint / Drawing**
- Freehand drawing
- Color palette
- Brush adjustment
- Canvas operations
- Stroke history

✅ **Gallery**
- Image browsing
- Image scaling
- Swipe navigation
- Image counter

✅ **Music Player**
- Play/pause controls
- Next/previous buttons
- Progress bar
- Time display
- Playlist support

✅ **Terminal**
- Command interface
- Built-in commands
- Command history
- Extensible system

✅ **Lock Screen**
- PIN-based security
- Numpad interface
- Lockout protection
- Failed attempt tracking

✅ **File Browser**
- Directory navigation
- File listing
- Size information
- Swipe navigation

---

## API Reference

### PhoneOS (main.py)

```python
class PhoneOS:
    def __init__(self, width: int = 320, height: int = 480, 
                 spi_speed: int = 10000000)
    
    def handle_touch() -> None
    def handle_touch_release() -> None
    def update() -> None
    def render() -> None
    def run() -> None
    def shutdown() -> None
```

### Display (display.py)

```python
class Display:
    def __init__(self, width: int = 320, height: int = 480,
                 spi_speed: int = 10000000, demo_mode: bool = False)
    
    def show_image(image: Image.Image) -> None
    def cleanup() -> None
```

### Touch (touch.py)

```python
class Touch:
    def __init__(self, width: int = 320, height: int = 480,
                 demo_mode: bool = False)
    
    def read() -> Optional[Tuple[int, int]]  # Returns (x, y) or None
    def calibrate() -> None
    def cleanup() -> None
```

### UIManager (ui.py)

```python
class UIManager:
    def __init__(self, width: int = 320, height: int = 480)
    
    def on_touch_down(x: int, y: int) -> None
    def on_touch_up(x: int, y: int) -> None
    def on_touch_move(x: int, y: int, dx: int, dy: int) -> None
    def on_tap(x: int, y: int) -> None
    def on_swipe(x1: int, y1: int, x2: int, y2: int) -> None
    def on_long_press(x: int, y: int) -> None
    
    def navigate_to_app(app_id: AppID) -> None
    def navigate_back() -> None
    
    def update() -> None
    def render() -> Image.Image
```

### BaseApp (apps/__init__.py)

```python
class BaseApp:
    def __init__(self, width: int = 320, height: int = 480)
    
    def on_activate() -> None
    def on_touch_down(x: int, y: int) -> None
    def on_touch_up(x: int, y: int) -> None
    def on_touch_move(x: int, y: int, dx: int, dy: int) -> None
    def on_tap(x: int, y: int) -> Optional[AppID]
    def on_swipe(x1: int, y1: int, x2: int, y2: int) -> None
    def on_long_press(x: int, y: int) -> None
    
    def update() -> None
    def render() -> Image.Image
```

### Animation (effects.py)

```python
class Animation:
    def __init__(self, duration: float = 0.5,
                 anim_type: AnimationType = AnimationType.FADE_IN,
                 on_complete: Optional[Callable] = None)
    
    def get_progress() -> float
    def get_eased_progress() -> float
    def apply_to_image(img: Image.Image, width: int, height: int) -> Image.Image
```

### Notification (effects.py)

```python
class Notification:
    def __init__(self, title: str, message: str, duration: float = 2.0,
                 notification_type: str = "info")
    
    def is_expired() -> bool
    def dismiss() -> None
    def get_color() -> Tuple[int, int, int]

class NotificationCenter:
    def add(title: str, message: str, duration: float = 2.0,
            notification_type: str = "info") -> None
    def remove_expired() -> None
    def render(draw: ImageDraw, width: int, height: int, font) -> None
```

---

## Color Scheme

### Dark Mode (Default)

```python
COLOR_BG_DARK       = (15, 15, 20)      # Almost black
COLOR_BG_LIGHT      = (240, 240, 245)   # Off-white
COLOR_TEXT_DARK     = (180, 180, 200)   # Light gray
COLOR_TEXT_LIGHT    = (50, 50, 60)      # Dark gray
COLOR_ACCENT        = (100, 180, 255)   # Cyan blue
COLOR_SUCCESS       = (100, 200, 100)   # Green
COLOR_WARNING       = (200, 200, 50)    # Yellow
COLOR_ERROR         = (200, 100, 100)   # Red
COLOR_BORDER        = (100, 100, 120)   # Light gray
```

---

## Touch Gesture Reference

| Gesture | Duration | Distance | Action |
|---------|----------|----------|--------|
| TAP | < 300ms | < 30px | Open app / Press button |
| SWIPE | < 500ms | > 30px | Navigate / Page change |
| LONG PRESS | > 500ms | < 15px | Context menu / Special action |
| DRAG | Any | > 30px | Draw / Scroll / Move |

---

## Hardware Specifications

### Display (ST7796S)

- **Resolution:** 320x480 pixels
- **Colors:** 18-bit RGB (262,144 colors)
- **Interface:** 4-wire SPI
- **Frequency:** 10 MHz (typical)
- **Bus Width:** 8-bit data
- **Command Set:** 150+ commands
- **Memory:** 384K SRAM

### Touch Controller (FT6336U)

- **Technology:** Capacitive touch sensor
- **Points:** Up to 10-point multi-touch
- **Interface:** I2C
- **Address:** 0x38 (default)
- **Resolution:** 10-bit X/Y coordinates
- **Sensitivity:** Adjustable
- **Response Time:** ~50-100ms

### Raspberry Pi Zero

- **CPU:** ARM11 @1GHz
- **RAM:** 512 MB
- **GPIO:** 40 pins
- **SPI:** 2 interfaces
- **I2C:** 2 interfaces
- **Power:** 5V USB

---

## Example: Adding a Custom App

```python
# Step 1: Create apps/weather.py
from apps import BaseApp
from ui import AppID

class WeatherApp(BaseApp):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.name = "Weather"
        self.temp = 72
        self.humidity = 65
    
    def on_tap(self, x, y):
        if 10 <= x < 70 and self.height - 45 <= y < self.height - 5:
            return AppID.HOME
        return None
    
    def render(self):
        from PIL import ImageDraw
        self.framebuffer = Image.new('RGB', (self.width, self.height), 
                                     color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        draw.text((160, 100), f"{self.temp}°F", fill=(100, 180, 255),
                 font=self.font_title, anchor="mm")
        draw.text((160, 150), f"Humidity: {self.humidity}%", fill=(180, 180, 200),
                 font=self.font_default, anchor="mm")
        
        return self.framebuffer

# Step 2: Edit ui.py
from apps.weather import WeatherApp
from ui import AppID

class AppID(Enum):
    HOME = "home"
    WEATHER = "weather"  # Add this
    # ... other apps

# In UIManager.__init__()
self.apps[AppID.WEATHER] = WeatherApp(width, height)

# Step 3: Edit apps/home.py
self.icons = [
    # ... existing icons
    AppIcon("Weather", "🌤", AppID.WEATHER, 230, 50, 70),
]

# Step 4: Run!
# python3 main.py
```

---

## Performance Optimization Tips

1. **Reduce FPS** for less CPU: `target_fps = 10`
2. **Cache images** instead of loading each frame
3. **Minimize redraws** in render() methods
4. **Use simple shapes** instead of complex graphics
5. **Profile with logging** to find bottlenecks
6. **Optimize PIL operations** with batch operations
7. **Limit animation count** to 2-3 simultaneous

---

## Troubleshooting Guide

### Issue: Black screen

**Solutions:**
- Check SPI connections
- Verify GPIO pins in display.py
- Enable SPI in raspi-config
- Run test_hardware.py

### Issue: Touch not working

**Solutions:**
- Check I2C connections
- Enable I2C in raspi-config
- Verify FT6336U at 0x38: `i2cdetect -y 1`
- Check touch.py GPIO pins

### Issue: High CPU usage

**Solutions:**
- Reduce target FPS
- Simplify app rendering
- Use Monitor with `top` or `htop`
- Check for infinite loops

### Issue: App crashes

**Solutions:**
- Run test_hardware.py
- Check logs with debug=True
- Verify AppID enum
- Check method signatures

---

## Future Enhancements

- [ ] Real music playback
- [ ] Camera integration
- [ ] Bluetooth support
- [ ] Cloud sync
- [ ] Voice control
- [ ] Multi-language support
- [ ] Theme customization
- [ ] App store / package manager
- [ ] System widgets
- [ ] Advanced gesture support

---

## License & Credits

**License:** MIT / Educational Use

**Based on:**
- Waveshare 3.5" LCD Display
- FT6336U Touch Controller
- ST7796S Display Driver
- PIL/Pillow Image Library
- RPi.GPIO and SMBus libraries

---

## Support & Documentation

- **Quick Start:** See README.md
- **Setup Guide:** See ADVANCED_GUIDE.md
- **Features:** See QUICKREF.txt
- **Hardware Tests:** `python3 test_hardware.py -i`
- **Examples:** See apps/EXAMPLE_*.py

---

## Version History

**v1.0 (Current)**
- Core OS and event loop
- Touch handling and gestures
- 6 built-in apps
- Animation system
- Notifications
- File browser
- Lock screen
- On-screen keyboard
- Hardware diagnostics

**Future versions will add:**
- Real-time audio playback
- Network connectivity
- Extended app ecosystem
- Advanced gestures
- System themes

---

**Pi Phone OS v1.0 - Lightweight phone OS for Raspberry Pi Zero**  
**Created:** 2025  
**Last Updated:** 2025

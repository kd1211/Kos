"""
Lock Screen App - PIN-based device locking
"""

import logging
import time
from typing import Optional
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class LockScreen(BaseApp):
    """Lock screen with PIN authentication"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Lock"
        
        # PIN settings
        self.correct_pin = "1234"
        self.entered_pin = ""
        self.pin_attempts = 0
        self.max_attempts = 5
        self.locked_until = 0
        
        # UI state
        self.show_error = False
        self.error_message = ""
        self.error_time = 0
        
        # Button layout (numpad + actions)
        self.buttons = self._create_numpad()
    
    def _create_numpad(self):
        """Create numpad button layout"""
        buttons = []
        
        # 3x3 grid for numbers
        for i in range(9):
            row = i // 3
            col = i % 3
            num = i + 1
            
            x = 50 + col * 80
            y = 120 + row * 60
            
            buttons.append({
                'type': 'number',
                'value': str(num),
                'x': x,
                'y': y,
                'w': 70,
                'h': 50,
                'label': str(num),
            })
        
        # 0
        buttons.append({
            'type': 'number',
            'value': '0',
            'x': 130,
            'y': 300,
            'w': 70,
            'h': 50,
            'label': '0',
        })
        
        # Delete/Backspace
        buttons.append({
            'type': 'delete',
            'value': None,
            'x': 210,
            'y': 300,
            'w': 70,
            'h': 50,
            'label': '⌫',
        })
        
        # Unlock/Submit
        buttons.append({
            'type': 'submit',
            'value': None,
            'x': 50,
            'y': 300,
            'w': 70,
            'h': 50,
            'label': '✓',
        })
        
        return buttons
    
    def _check_lockout(self) -> bool:
        """Check if device is locked out"""
        if time.time() < self.locked_until:
            return True
        return False
    
    def _verify_pin(self, pin: str) -> bool:
        """Verify PIN"""
        return pin == self.correct_pin
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle button taps"""
        
        # Check if locked out
        if self._check_lockout():
            remaining = int(self.locked_until - time.time())
            self.error_message = f"Locked for {remaining}s"
            self.show_error = True
            return None
        
        # Check buttons
        for btn in self.buttons:
            if (btn['x'] <= x < btn['x'] + btn['w'] and
                btn['y'] <= y < btn['y'] + btn['h']):
                
                if btn['type'] == 'number':
                    if len(self.entered_pin) < 6:  # Max 6 digits
                        self.entered_pin += btn['value']
                        logger.info(f"PIN digit entered (length: {len(self.entered_pin)})")
                
                elif btn['type'] == 'delete':
                    if self.entered_pin:
                        self.entered_pin = self.entered_pin[:-1]
                        logger.info(f"PIN digit deleted (length: {len(self.entered_pin)})")
                
                elif btn['type'] == 'submit':
                    if self._verify_pin(self.entered_pin):
                        logger.info("PIN verified - unlocking device")
                        return None  # Return to home
                    else:
                        self.pin_attempts += 1
                        self.entered_pin = ""
                        self.show_error = True
                        self.error_message = f"Incorrect PIN ({self.max_attempts - self.pin_attempts} attempts left)"
                        self.error_time = time.time()
                        
                        if self.pin_attempts >= self.max_attempts:
                            self.locked_until = time.time() + 60  # 60 second lockout
                            self.error_message = "Too many attempts! Locked for 60 seconds."
                            logger.warning("Device locked due to too many failed attempts")
                        
                        logger.warning(f"Incorrect PIN attempt {self.pin_attempts}/{self.max_attempts}")
        
        return None
    
    def update(self) -> None:
        """Update lock screen state"""
        # Hide error message after 2 seconds
        if self.show_error and time.time() - self.error_time > 2.0:
            self.show_error = False
    
    def render(self) -> Image.Image:
        """Render lock screen"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(10, 10, 15))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Wallpaper effect (gradient-like dark background)
        for y in range(0, self.height, 5):
            shade = int(15 + (y / self.height) * 10)
            draw.line([(0, y), (self.width, y)], fill=(shade, shade, shade + 5), width=5)
        
        # Time display
        import datetime
        now = datetime.datetime.now()
        time_str = now.strftime("%H:%M")
        date_str = now.strftime("%a, %b %d")
        
        draw.text((self.width // 2, 50), time_str, fill=(200, 200, 200),
                 font=self.font_title, anchor="mm")
        draw.text((self.width // 2, 80), date_str, fill=(150, 150, 150),
                 font=self.font_default, anchor="mm")
        
        # PIN indicator
        draw.text((self.width // 2, 100), "Enter PIN", fill=(180, 180, 200),
                 font=self.font_default, anchor="mm")
        
        # PIN dots
        pin_display = "● " * len(self.entered_pin) + "○ " * (6 - len(self.entered_pin))
        draw.text((self.width // 2, 110), pin_display.strip(), fill=(100, 180, 255),
                 font=self.font_large, anchor="mm")
        
        # Error message
        if self.show_error:
            draw.rectangle([(10, self.height // 2 - 20), (self.width - 10, self.height // 2 + 20)],
                          fill=(100, 30, 30), outline=(200, 100, 100), width=2)
            draw.text((self.width // 2, self.height // 2), self.error_message,
                     fill=(255, 150, 150), font=self.font_small, anchor="mm", align="center")
        
        # Draw numpad buttons
        for btn in self.buttons:
            # Button background
            bg_color = (40, 40, 50)
            border_color = (100, 100, 120)
            
            draw.rectangle([(btn['x'], btn['y']),
                           (btn['x'] + btn['w'], btn['y'] + btn['h'])],
                          fill=bg_color, outline=border_color, width=2)
            
            # Button text
            text_color = (180, 180, 200)
            if btn['type'] == 'submit':
                text_color = (100, 200, 100)
            elif btn['type'] == 'delete':
                text_color = (200, 100, 100)
            
            draw.text((btn['x'] + btn['w'] // 2, btn['y'] + btn['h'] // 2),
                     btn['label'], fill=text_color, font=self.font_large, anchor="mm")
        
        # Lock icon
        draw.text((10, 10), "🔒", fill=(150, 150, 150), font=self.font_large)
        
        # Status bar (simplified)
        draw.line([(0, self.height - 30), (self.width, self.height - 30)],
                 fill=(50, 50, 60), width=1)
        draw.text((self.width // 2, self.height - 15), "Device Locked",
                 fill=(100, 100, 120), font=self.font_small, anchor="mm")
        
        return self.framebuffer

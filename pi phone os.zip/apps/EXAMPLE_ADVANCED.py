"""
Advanced Example App - Demonstrates all Pi Phone OS features
Shows animations, notifications, keyboard input, file operations, and more
"""

import logging
import os
from typing import Optional, List
from PIL import Image, ImageDraw

from apps import BaseApp
from effects import (
    Animation, AnimationType, NotificationCenter, 
    TransitionEffect, ProgressBar, ParticleEffect
)
from keyboard import TextInputField, KeyboardManager

logger = logging.getLogger(__name__)


class AdvancedExampleApp(BaseApp):
    """Complete example using all advanced features"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Advanced Example"
        
        # UI State
        self.current_screen = "menu"  # menu, notes, progress, animation
        self.menu_selected = 0
        
        # Notifications
        self.notif_center = NotificationCenter()
        
        # Text input
        self.input_field = TextInputField(20, 100, 280, 40, "Enter note title...")
        self.kb_manager = KeyboardManager()
        self.kb_manager.add_field(self.input_field)
        
        # Notes
        self.notes: List[str] = []
        self.notes_file = os.path.expanduser("~/.pi-phone/example_notes.txt")
        os.makedirs(os.path.dirname(self.notes_file), exist_ok=True)
        self._load_notes()
        
        # Animations
        self.animations: List[Animation] = []
        self.transition = TransitionEffect(width, height)
        
        # Progress bar
        self.progress = ProgressBar(width=260, height=15)
        self.progress_target = 0.0
        
        # Particles
        self.particles = ParticleEffect()
    
    def _load_notes(self) -> None:
        """Load notes from file"""
        try:
            if os.path.exists(self.notes_file):
                with open(self.notes_file, 'r') as f:
                    self.notes = [line.strip() for line in f.readlines()]
            logger.info(f"Loaded {len(self.notes)} notes")
        except Exception as e:
            logger.error(f"Error loading notes: {e}")
    
    def _save_notes(self) -> None:
        """Save notes to file"""
        try:
            with open(self.notes_file, 'w') as f:
                for note in self.notes:
                    f.write(note + '\n')
            logger.info("Notes saved")
        except Exception as e:
            logger.error(f"Error saving notes: {e}")
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle tap events"""
        
        # Back button (all screens)
        if 10 <= x < 60 and self.height - 45 <= y < self.height - 5:
            if self.current_screen != "menu":
                self.current_screen = "menu"
                self.notif_center.add("Back", "Returned to menu", notification_type="info")
                return None
            else:
                from ui import AppID
                return AppID.HOME
        
        # Menu screen
        if self.current_screen == "menu":
            if 50 <= x < 270 and 100 <= y < 150:
                self.current_screen = "notes"
                self.transition.start_transition("fade")
                self.notif_center.add("Notes", "Opening notes app", notification_type="info")
            elif 50 <= x < 270 and 170 <= y < 220:
                self.current_screen = "progress"
                self.transition.start_transition("slide_left")
                self.progress_target = 0.0
                self.notif_center.add("Progress", "Starting task", notification_type="info")
            elif 50 <= x < 270 and 240 <= y < 290:
                self.current_screen = "animation"
                self.transition.start_transition("slide_right")
                self.notif_center.add("Animation", "Starting animation demo", notification_type="info")
        
        # Notes screen
        elif self.current_screen == "notes":
            self.kb_manager.on_tap(x, y)
            
            # Add note button
            if 220 <= x < 280 and 160 <= y < 190:
                if self.input_field.text.strip():
                    self.notes.append(self.input_field.text)
                    self._save_notes()
                    self.input_field.text = ""
                    self.notif_center.add("Saved", "Note added!", notification_type="success")
                    # Emit particles
                    self.particles.emit(x, y, 15, (100, 200, 100), 200, 0.5)
                    logger.info(f"Note added: {self.notes[-1]}")
        
        # Progress screen
        elif self.current_screen == "progress":
            # Simulate progress
            if 50 <= x < 270 and 200 <= y < 240:
                self.progress_target = min(1.0, self.progress_target + 0.2)
                self.notif_center.add("Progress", f"{int(self.progress_target * 100)}%", 
                                    notification_type="info")
                
                # Add animation
                anim = Animation(0.3, AnimationType.SCALE)
                self.animations.append(anim)
                logger.info(f"Progress: {self.progress_target}")
        
        # Animation screen
        elif self.current_screen == "animation":
            # Trigger animations on tap
            animations = [
                AnimationType.FADE_IN,
                AnimationType.SLIDE_LEFT,
                AnimationType.BOUNCE,
                AnimationType.SCALE,
            ]
            
            anim_type = animations[len(self.animations) % len(animations)]
            anim = Animation(0.5, anim_type)
            self.animations.append(anim)
            
            self.particles.emit(x, y, 20, (100, 180, 255), 250, 0.7)
            self.notif_center.add("Animation", f"Playing {anim_type.value}", 
                                notification_type="info")
        
        return None
    
    def update(self) -> None:
        """Update app state"""
        # Update keyboard
        self.kb_manager.update()
        
        # Update animations
        self.animations = [a for a in self.animations if not a.finished]
        
        # Update progress
        self.progress.set_progress(self.progress_target)
        self.progress.update()
        
        # Update particles
        self.particles.update(0.016)
    
    def render(self) -> Image.Image:
        """Render app"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Title bar
        draw.rectangle([(0, 0), (self.width, 50)], fill=(30, 30, 40))
        draw.text((10, 25), self.name, fill=(200, 200, 200), font=self.font_title, anchor="lm")
        
        # Back button
        draw.rectangle([(self.width - 60, 10), (self.width - 10, 40)], 
                      outline=(100, 100, 120), width=2)
        draw.text((self.width - 35, 25), "Back", fill=(180, 180, 200), 
                 font=self.font_small, anchor="mm")
        
        # Separator
        draw.line([(0, 50), (self.width, 50)], fill=(50, 50, 60), width=1)
        
        # Content based on screen
        if self.current_screen == "menu":
            self._render_menu(draw)
        elif self.current_screen == "notes":
            self._render_notes(draw)
        elif self.current_screen == "progress":
            self._render_progress(draw)
        elif self.current_screen == "animation":
            self._render_animation(draw)
        
        # Render particles
        self.particles.draw(draw, self.width, self.height)
        
        # Render notifications
        self.notif_center.render(draw, self.width, self.height, self.font_small)
        
        return self.framebuffer
    
    def _render_menu(self, draw: ImageDraw.ImageDraw) -> None:
        """Render menu screen"""
        draw.text((self.width // 2, 70), "Select Feature", fill=(180, 180, 200),
                 font=self.font_default, anchor="mm")
        
        # Notes button
        draw.rectangle([(50, 100), (270, 150)], outline=(100, 150, 255), width=2)
        draw.text((160, 125), "📝 Notes", fill=(150, 200, 255), 
                 font=self.font_default, anchor="mm")
        
        # Progress button
        draw.rectangle([(50, 170), (270, 220)], outline=(100, 150, 255), width=2)
        draw.text((160, 195), "⏳ Progress Demo", fill=(150, 200, 255), 
                 font=self.font_default, anchor="mm")
        
        # Animation button
        draw.rectangle([(50, 240), (270, 290)], outline=(100, 150, 255), width=2)
        draw.text((160, 265), "✨ Animations", fill=(150, 200, 255), 
                 font=self.font_default, anchor="mm")
    
    def _render_notes(self, draw: ImageDraw.ImageDraw) -> None:
        """Render notes screen"""
        # Input field
        self.input_field.draw(draw, self.font_default, self.font_small)
        
        # Add button
        draw.rectangle([(220, 160), (280, 190)], outline=(100, 200, 100), width=2)
        draw.text((250, 175), "+", fill=(100, 200, 100), font=self.font_large, anchor="mm")
        
        # Notes list
        draw.text((20, 210), "Notes:", fill=(180, 180, 200), font=self.font_default)
        
        y = 240
        for i, note in enumerate(self.notes[:3]):
            display_note = note[:30] + "..." if len(note) > 30 else note
            draw.text((30, y), f"• {display_note}", fill=(150, 180, 220), 
                     font=self.font_small)
            y += 25
        
        if len(self.notes) > 3:
            draw.text((30, y), f"... and {len(self.notes) - 3} more", 
                     fill=(100, 100, 120), font=self.font_small)
    
    def _render_progress(self, draw: ImageDraw.ImageDraw) -> None:
        """Render progress screen"""
        draw.text((self.width // 2, 80), "Task Progress", fill=(180, 180, 200),
                 font=self.font_default, anchor="mm")
        
        # Progress bar
        self.progress.draw(draw, 30, 150, (100, 180, 255))
        
        # Percentage
        percent = int(self.progress_target * 100)
        draw.text((self.width // 2, 180), f"{percent}%", fill=(100, 180, 255),
                 font=self.font_large, anchor="mm")
        
        # Advance button
        draw.rectangle([(50, 200), (270, 240)], outline=(100, 150, 255), width=2)
        draw.text((160, 220), "Advance Progress", fill=(150, 200, 255), 
                 font=self.font_default, anchor="mm")
        
        # Status
        if percent < 25:
            status = "Just started..."
        elif percent < 50:
            status = "Making progress..."
        elif percent < 75:
            status = "More than halfway there!"
        elif percent < 100:
            status = "Almost done!"
        else:
            status = "✓ Complete!"
        
        draw.text((self.width // 2, 280), status, fill=(100, 200, 100),
                 font=self.font_small, anchor="mm")
    
    def _render_animation(self, draw: ImageDraw.ImageDraw) -> None:
        """Render animation screen"""
        draw.text((self.width // 2, 80), "Tap to Animate", fill=(180, 180, 200),
                 font=self.font_default, anchor="mm")
        
        # Animation box
        box_size = 100
        box_x = (self.width - box_size) // 2
        box_y = 150
        
        # Draw base box
        draw.rectangle([(box_x, box_y), (box_x + box_size, box_y + box_size)],
                      outline=(100, 150, 255), width=2)
        
        # Apply animation if active
        if self.animations:
            anim = self.animations[-1]
            progress = anim.get_eased_progress()
            
            # Scale effect visualization
            if anim.anim_type == AnimationType.SCALE:
                scale = progress
                scaled_size = int(box_size * scale)
                offset = (box_size - scaled_size) // 2
                draw.rectangle([(box_x + offset, box_y + offset),
                              (box_x + offset + scaled_size, box_y + offset + scaled_size)],
                             fill=(100, 180, 255))
            
            # Color based on animation
            color = (150, 200, 255) if progress < 0.5 else (100, 200, 150)
            draw.text((self.width // 2, box_y + box_size // 2), "✨",
                     fill=color, font=self.font_large, anchor="mm")
        else:
            draw.text((self.width // 2, box_y + box_size // 2), "?",
                     fill=(100, 150, 200), font=self.font_large, anchor="mm")
        
        # Info
        draw.text((self.width // 2, 290), "Active animations: " + str(len(self.animations)),
                 fill=(100, 100, 120), font=self.font_small, anchor="mm")
        
        draw.text((self.width // 2, 310), "Tap anywhere above to animate",
                 fill=(80, 80, 100), font=self.font_small, anchor="mm")


# Integration instructions:
"""
To add this advanced example to your Pi Phone OS:

1. Save as: apps/advanced_example.py

2. Edit ui.py:
   
   from apps.advanced_example import AdvancedExampleApp
   from ui import AppID
   
   # Add to AppID enum:
   class AppID(Enum):
       HOME = "home"
       ADVANCED = "advanced"  # Add this
       ...
   
   # In UIManager.__init__():
   self.apps[AppID.ADVANCED] = AdvancedExampleApp(width, height)

3. Edit apps/home.py and add to icons list:
   
   AppIcon("Advanced", "⚡", AppID.ADVANCED, 230, 160, 70),

4. Run main.py and tap the Advanced icon!

Features demonstrated:
- Notifications system
- Text input with keyboard
- File I/O and persistence
- Animations and transitions
- Progress tracking
- Particle effects
- Multi-screen navigation
- State management
"""

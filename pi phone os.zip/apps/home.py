"""
Home Screen App - Shows app grid and allows navigation
"""

import logging
from typing import Optional, Tuple
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class AppIcon:
    """Simple app icon for home screen"""
    
    def __init__(self, name: str, icon_char: str, app_id: 'AppID',
                 x: int, y: int, size: int = 70):
        self.name = name
        self.icon_char = icon_char
        self.app_id = app_id
        self.x = x
        self.y = y
        self.size = size
        self.pressed = False
    
    def contains(self, x: int, y: int) -> bool:
        """Check if point is inside icon"""
        return (self.x <= x < self.x + self.size and
                self.y <= y < self.y + self.size)
    
    def draw(self, draw: ImageDraw.ImageDraw, font_large, font_small) -> None:
        """Draw icon"""
        # Background
        bg_color = (40, 50, 70) if not self.pressed else (70, 90, 120)
        border_color = (100, 150, 200) if not self.pressed else (150, 200, 255)
        
        draw.rectangle(
            [(self.x, self.y), (self.x + self.size, self.y + self.size)],
            fill=bg_color, outline=border_color, width=2
        )
        
        # Icon character
        draw.text(
            (self.x + self.size // 2, self.y + self.size // 2 - 10),
            self.icon_char, fill=(100, 180, 255), font=font_large, anchor="mm"
        )
        
        # Label
        draw.text(
            (self.x + self.size // 2, self.y + self.size - 10),
            self.name, fill=(180, 180, 200), font=font_small, anchor="mm"
        )


class HomeApp(BaseApp):
    """Home screen with app grid"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Home"
        
        # Import AppID here to avoid circular imports
        from ui import AppID
        
        # Create app icons
        self.icons = [
            AppIcon("Settings", "⚙", AppID.SETTINGS, 20, 50, 70),
            AppIcon("Paint", "🎨", AppID.PAINT, 125, 50, 70),
            AppIcon("Gallery", "🖼", AppID.GALLERY, 230, 50, 70),
            AppIcon("Music", "♫", AppID.MUSIC, 20, 160, 70),
            AppIcon("Terminal", "⌘", AppID.TERMINAL, 125, 160, 70),
            AppIcon("About", "ℹ", None, 230, 160, 70),  # Placeholder
        ]
        
        self.pressed_icon = None
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Handle touch down on icon"""
        for icon in self.icons:
            if icon.contains(x, y):
                icon.pressed = True
                self.pressed_icon = icon
                break
    
    def on_touch_up(self, x: int, y: int) -> None:
        """Handle touch up"""
        if self.pressed_icon:
            self.pressed_icon.pressed = False
            self.pressed_icon = None
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle tap on app icon"""
        for icon in self.icons:
            if icon.contains(x, y):
                logger.info(f"Tapped app: {icon.name}")
                return icon.app_id
        return None
    
    def render(self) -> Image.Image:
        """Render home screen"""
        # Create fresh framebuffer
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Draw title
        draw.text((10, 35), "Apps", fill=(200, 200, 200), font=self.font_title)
        
        # Draw app icons
        for icon in self.icons:
            icon.draw(draw, self.font_large, self.font_small)
        
        # Draw separator
        draw.line([(10, 275), (self.width - 10, 275)], fill=(50, 50, 60), width=1)
        
        # Draw quick info
        info_y = 300
        draw.text((10, info_y), "Pi Phone OS v1.0", fill=(100, 100, 120), font=self.font_small)
        draw.text((10, info_y + 25), "Tap icons to open apps", fill=(80, 80, 100), font=self.font_small)
        draw.text((10, info_y + 50), "Swipe to navigate", fill=(80, 80, 100), font=self.font_small)
        
        return self.framebuffer

"""
Music App - Simple music player interface
"""

import logging
import os
from typing import Optional, List
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class MusicApp(BaseApp):
    """Music player application"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Music"
        
        # Music library
        self.music_folder = os.path.expanduser("~/Music")
        self.playlist: List[str] = []
        self.current_index = 0
        self.is_playing = False
        
        # Playback simulation
        self.current_time = 0
        self.total_time = 180  # 3 minutes
        
        self._load_playlist()
    
    def _load_playlist(self) -> None:
        """Load music files from folder"""
        if not os.path.exists(self.music_folder):
            os.makedirs(self.music_folder)
        
        # Look for audio files
        supported_formats = ('.mp3', '.wav', '.flac', '.m4a')
        for filename in os.listdir(self.music_folder):
            if filename.lower().endswith(supported_formats):
                self.playlist.append(filename)
        
        self.playlist.sort()
        logger.info(f"Loaded {len(self.playlist)} songs")
    
    def _get_current_song(self) -> Optional[str]:
        """Get current song name"""
        if self.playlist and self.current_index < len(self.playlist):
            return self.playlist[self.current_index]
        return "No music files"
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle button taps"""
        # Play/Pause button
        if 110 <= x < 210 and 200 <= y < 260:
            self.is_playing = not self.is_playing
            logger.info(f"Playback: {'started' if self.is_playing else 'paused'}")
            return None
        
        # Previous button
        if 40 <= x < 100 and 200 <= y < 260:
            if self.current_index > 0:
                self.current_index -= 1
                self.current_time = 0
                logger.info(f"Previous song: {self._get_current_song()}")
            return None
        
        # Next button
        if 220 <= x < 280 and 200 <= y < 260:
            if self.current_index < len(self.playlist) - 1:
                self.current_index += 1
                self.current_time = 0
                logger.info(f"Next song: {self._get_current_song()}")
            return None
        
        # Back button
        if 10 <= x < 60 and 35 <= y < 55:
            from ui import AppID
            return AppID.HOME
        
        return None
    
    def update(self) -> None:
        """Update playback progress"""
        if self.is_playing and self.current_time < self.total_time:
            self.current_time += 0.1  # Simulate playback
    
    def render(self) -> Image.Image:
        """Render music player"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Back button
        draw.rectangle([(10, 35), (60, 55)], outline=(100, 100, 120), width=2)
        draw.text((35, 45), "< Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Title
        draw.text((80, 45), "Music", fill=(200, 200, 200), font=self.font_title)
        
        # Separator
        draw.line([(10, 65), (self.width - 10, 65)], fill=(50, 50, 60), width=1)
        
        # Album art placeholder
        album_size = 120
        album_x = (self.width - album_size) // 2
        album_y = 90
        draw.rectangle(
            [(album_x, album_y), (album_x + album_size, album_y + album_size)],
            fill=(50, 50, 70), outline=(100, 100, 120), width=2
        )
        draw.text((self.width // 2, album_y + album_size // 2), "♫", fill=(100, 180, 255),
                 font=self.font_title, anchor="mm")
        
        # Song title
        song_name = self._get_current_song()
        if song_name and len(song_name) > 30:
            song_name = song_name[:27] + "..."
        
        draw.text((self.width // 2, 230), song_name, fill=(180, 180, 200),
                 font=self.font_default, anchor="mm", align="center")
        
        # Progress bar
        progress_y = 270
        progress_w = self.width - 40
        progress_x = 20
        
        draw.rectangle([(progress_x, progress_y), (progress_x + progress_w, progress_y + 10)],
                      outline=(80, 80, 100), width=1)
        
        # Progress fill
        if self.total_time > 0:
            fill_w = int(progress_w * self.current_time / self.total_time)
            draw.rectangle([(progress_x, progress_y), (progress_x + fill_w, progress_y + 10)],
                          fill=(100, 180, 255))
        
        # Time display
        min_s = int(self.current_time) // 60
        sec_s = int(self.current_time) % 60
        min_e = int(self.total_time) // 60
        sec_e = int(self.total_time) % 60
        
        time_text = f"{min_s}:{sec_s:02d} / {min_e}:{sec_e:02d}"
        draw.text((self.width // 2, progress_y + 20), time_text, fill=(100, 100, 120),
                 font=self.font_small, anchor="mm")
        
        # Control buttons
        button_y = 200
        
        # Previous
        draw.rectangle([(40, button_y), (100, button_y + 60)], outline=(100, 100, 120), width=2)
        draw.text((70, button_y + 30), "<<", fill=(180, 180, 200), font=self.font_large, anchor="mm")
        
        # Play/Pause
        play_button_color = (100, 200, 100) if self.is_playing else (100, 100, 120)
        draw.rectangle([(110, button_y), (210, button_y + 60)], outline=play_button_color, width=2)
        button_text = "▶" if not self.is_playing else "⏸"
        draw.text((160, button_y + 30), button_text, fill=(180, 180, 200), font=self.font_large, anchor="mm")
        
        # Next
        draw.rectangle([(220, button_y), (280, button_y + 60)], outline=(100, 100, 120), width=2)
        draw.text((250, button_y + 30), ">>", fill=(180, 180, 200), font=self.font_large, anchor="mm")
        
        return self.framebuffer

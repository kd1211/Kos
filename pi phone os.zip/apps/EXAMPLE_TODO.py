"""
Example Custom App - Simple Todo List
Demonstrates how to build new apps for Pi Phone OS

Copy this as a template for creating your own apps.
"""

import logging
from typing import Optional, List
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class TodoApp(BaseApp):
    """Simple todo list application"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Todo"
        
        # Application state
        self.todos: List[str] = [
            "Learn Pi programming",
            "Build awesome projects",
            "Explore hardware",
        ]
        
        self.input_text = ""
        self.selected_index = -1
        self.scroll_offset = 0
    
    def on_activate(self) -> None:
        """Called when app is shown"""
        logger.info("Todo app activated")
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle tap events"""
        
        # Back button
        if 10 <= x < 70 and self.height - 45 <= y < self.height - 5:
            from ui import AppID
            return AppID.HOME
        
        # Todo item selection
        item_y = 70
        for i, todo in enumerate(self.todos):
            if item_y <= y < item_y + 40:
                self.selected_index = i
                logger.info(f"Selected todo {i}: {todo}")
                return None
            item_y += 45
        
        # Delete button
        if self.selected_index >= 0:
            if self.width - 70 <= x < self.width - 10 and 300 <= y < 340:
                self.todos.pop(self.selected_index)
                self.selected_index = -1
                logger.info("Todo deleted")
                return None
        
        # Add button
        if 10 <= x < 70 and 300 <= y < 340:
            if self.input_text.strip():
                self.todos.append(self.input_text)
                self.input_text = ""
                logger.info(f"Todo added: {self.input_text}")
            return None
        
        return None
    
    def on_long_press(self, x: int, y: int) -> None:
        """Mark todo as done with long press"""
        item_y = 70
        for i, todo in enumerate(self.todos):
            if item_y <= y < item_y + 40:
                # Mark as done (add strikethrough effect)
                if not todo.startswith("✓ "):
                    self.todos[i] = "✓ " + todo
                else:
                    self.todos[i] = todo[2:]
                logger.info(f"Todo toggled: {self.todos[i]}")
                return
            item_y += 45
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Swipe to delete"""
        # Right-to-left swipe deletes
        if x1 - x2 > 50 and self.selected_index >= 0:
            self.todos.pop(self.selected_index)
            self.selected_index = -1
            logger.info("Todo swiped away")
    
    def render(self) -> Image.Image:
        """Render the todo app"""
        
        # Create fresh framebuffer
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Header
        draw.rectangle([(0, 0), (self.width, 50)], fill=(30, 30, 40))
        
        # Back button
        draw.rectangle([(10, 10), (60, 40)], outline=(100, 100, 120), width=2)
        draw.text((35, 25), "Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Title
        draw.text((70, 25), "Todo List", fill=(200, 200, 200), font=self.font_title, anchor="lm")
        
        # Separator
        draw.line([(0, 50), (self.width, 50)], fill=(50, 50, 60), width=1)
        
        # Todo list
        item_y = 70
        for i, todo in enumerate(self.todos):
            # Highlight selected
            if i == self.selected_index:
                draw.rectangle([(5, item_y), (self.width - 5, item_y + 40)],
                              fill=(40, 50, 70), outline=(100, 150, 255), width=2)
                text_color = (150, 200, 255)
            else:
                text_color = (180, 180, 200)
            
            # Item number
            draw.text((15, item_y + 10), f"{i+1}.", fill=(100, 100, 120), font=self.font_default)
            
            # Item text
            draw.text((40, item_y + 10), todo, fill=text_color, font=self.font_default)
            
            # Separator
            draw.line([(10, item_y + 40), (self.width - 10, item_y + 40)], fill=(50, 50, 60), width=1)
            item_y += 45
            
            if item_y > self.height - 100:
                break
        
        # Input area
        draw.rectangle([(0, self.height - 80), (self.width, self.height)], fill=(25, 25, 35))
        draw.line([(0, self.height - 80), (self.width, self.height - 80)], fill=(50, 50, 60), width=2)
        
        # Add button
        draw.rectangle([(10, self.height - 70), (60, self.height - 10)],
                      outline=(100, 100, 120), width=2)
        draw.text((35, self.height - 40), "Add", fill=(100, 200, 100), font=self.font_small, anchor="mm")
        
        # Input field
        draw.rectangle([(70, self.height - 70), (self.width - 10, self.height - 10)],
                      outline=(100, 100, 120), width=1)
        
        # Input text (limit length)
        input_display = self.input_text[:35]
        draw.text((75, self.height - 40), input_display, fill=(180, 180, 200),
                 font=self.font_small, anchor="lm")
        
        # Delete button (only if item selected)
        if self.selected_index >= 0:
            draw.rectangle([(self.width - 60, self.height - 70), (self.width - 10, self.height - 10)],
                          fill=(200, 100, 100), outline=(150, 50, 50), width=2)
            draw.text((self.width - 35, self.height - 40), "Del", fill=(255, 255, 255),
                     font=self.font_small, anchor="mm")
        
        # Instructions
        draw.text((10, self.height - 105), "Tap: select | Long press: done | Swipe: delete",
                 fill=(80, 80, 100), font=self.font_small)
        
        return self.framebuffer


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================
"""
To use this app in your Pi Phone OS:

1. Save this file as: apps/todo.py

2. Edit ui.py and add:
   
   from apps.todo import TodoApp
   from ui import AppID
   
   # In UIManager.__init__(), add:
   self.apps[AppID.TODO] = TodoApp(width, height)
   
   # Add AppID.TODO to AppID enum:
   class AppID(Enum):
       HOME = "home"
       TODO = "todo"
       ...

3. Edit apps/home.py and add the icon:
   
   self.icons = [
       ...
       AppIcon("Todo", "✓", AppID.TODO, x, y, size),
       ...
   ]

4. Run main.py and tap the Todo icon!

CUSTOMIZATION IDEAS:
- Add persistent storage (save to JSON file)
- Add due dates and reminders
- Add categories/tags
- Add sorting options
- Add recurring todos
- Add notifications
- Add cloud sync
- Add touch-based input (on-screen keyboard)
"""

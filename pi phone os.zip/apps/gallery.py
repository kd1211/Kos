"""
Gallery App - View images from a folder
"""

import logging
import os
from typing import Optional, List
from PIL import Image

from apps import BaseApp

logger = logging.getLogger(__name__)


class GalleryApp(BaseApp):
    """Gallery app for viewing images"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Gallery"
        
        # Load images from ~/Pictures or create dummy
        self.image_folder = os.path.expanduser("~/Pictures")
        self.images: List[str] = []
        self.current_index = 0
        self.current_image = None
        
        self._load_images()
    
    def _load_images(self) -> None:
        """Load images from folder"""
        if not os.path.exists(self.image_folder):
            os.makedirs(self.image_folder)
            logger.info(f"Created images folder: {self.image_folder}")
        
        # Load image files
        supported_formats = ('.jpg', '.jpeg', '.png', '.gif', '.bmp')
        for filename in os.listdir(self.image_folder):
            if filename.lower().endswith(supported_formats):
                self.images.append(os.path.join(self.image_folder, filename))
        
        self.images.sort()
        logger.info(f"Loaded {len(self.images)} images")
        
        if self.images:
            self._load_current_image()
    
    def _load_current_image(self) -> None:
        """Load current image and scale to fit"""
        if not self.images:
            return
        
        try:
            img = Image.open(self.images[self.current_index])
            
            # Scale to fit screen
            img.thumbnail((self.width, self.height - 80), Image.Resampling.LANCZOS)
            
            # Center image
            bg = Image.new('RGB', (self.width, self.height - 80), color=(30, 30, 40))
            offset = ((bg.width - img.width) // 2, (bg.height - img.height) // 2)
            bg.paste(img, offset)
            
            self.current_image = bg
            logger.info(f"Loaded image {self.current_index + 1}/{len(self.images)}")
        except Exception as e:
            logger.error(f"Failed to load image: {e}")
            self.current_image = None
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle navigation"""
        # Left side - previous
        if x < self.width // 3 and y < self.height - 50:
            if self.current_index > 0:
                self.current_index -= 1
                self._load_current_image()
            return None
        
        # Right side - next
        if x > 2 * self.width // 3 and y < self.height - 50:
            if self.current_index < len(self.images) - 1:
                self.current_index += 1
                self._load_current_image()
            return None
        
        # Back button
        if 10 <= x < 60 and self.height - 45 <= y < self.height - 5:
            from ui import AppID
            return AppID.HOME
        
        return None
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe navigation"""
        dx = x2 - x1
        
        # Swipe left - next
        if dx < -50:
            if self.current_index < len(self.images) - 1:
                self.current_index += 1
                self._load_current_image()
        
        # Swipe right - previous
        elif dx > 50:
            if self.current_index > 0:
                self.current_index -= 1
                self._load_current_image()
    
    def render(self) -> Image.Image:
        """Render gallery"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        
        # Draw image
        if self.current_image:
            self.framebuffer.paste(self.current_image, (0, 0))
        else:
            # No images placeholder
            draw = ImageDraw.Draw(self.framebuffer)
            draw.text(
                (self.width // 2, self.height // 2),
                "No images\nAdd images to ~/Pictures",
                fill=(100, 100, 120), font=self.font_default, anchor="mm", align="center"
            )
        
        # Draw toolbar
        from PIL import ImageDraw
        draw = ImageDraw.Draw(self.framebuffer)
        toolbar_y = self.height - 50
        
        draw.rectangle([(0, toolbar_y), (self.width, self.height)], fill=(30, 30, 40))
        draw.line([(0, toolbar_y), (self.width, toolbar_y)], fill=(80, 80, 100), width=2)
        
        # Image counter
        if self.images:
            counter = f"{self.current_index + 1}/{len(self.images)}"
            draw.text(
                (self.width // 2, toolbar_y + 25),
                counter, fill=(180, 180, 200), font=self.font_default, anchor="mm"
            )
        
        # Back button
        draw.rectangle([(10, toolbar_y + 5), (60, toolbar_y + 45)], outline=(100, 100, 120), width=2)
        draw.text((35, toolbar_y + 25), "Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        return self.framebuffer

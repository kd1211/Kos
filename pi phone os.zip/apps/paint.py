"""
Paint App - Simple drawing application
"""

import logging
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class PaintApp(BaseApp):
    """Simple painting app with touch drawing"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Paint"
        
        # Drawing area
        self.canvas = Image.new('RGB', (width, height - 50), color=(240, 240, 245))
        
        # Drawing state
        self.drawing = False
        self.last_pos = None
        self.stroke_color = (50, 100, 200)
        self.stroke_width = 3
        
        # Undo buffer (store recent strokes)
        self.stroke_history: List[Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int, int], int]] = []
        
        # Tools
        self.current_tool = "pencil"
        self.colors = [
            (50, 100, 200),    # Blue
            (200, 50, 50),     # Red
            (50, 200, 50),     # Green
            (200, 200, 50),    # Yellow
            (50, 50, 50),      # Black
            (240, 240, 245),   # White (eraser)
        ]
        self.color_index = 0
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Start drawing"""
        if y < self.height - 50:  # In drawing area
            self.drawing = True
            self.last_pos = (x, y)
    
    def on_touch_move(self, x: int, y: int, dx: int, dy: int) -> None:
        """Draw line"""
        if self.drawing and self.last_pos and y < self.height - 50:
            draw = ImageDraw.Draw(self.canvas)
            draw.line([self.last_pos, (x, y)], fill=self.stroke_color, width=self.stroke_width)
            self.last_pos = (x, y)
    
    def on_touch_up(self, x: int, y: int) -> None:
        """Stop drawing"""
        self.drawing = False
        self.last_pos = None
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle button taps"""
        # Toolbar buttons
        toolbar_y = self.height - 50
        
        # Clear button
        if 10 <= x < 70 and toolbar_y + 5 <= y < toolbar_y + 45:
            self.canvas = Image.new('RGB', (self.width, self.height - 50), color=(240, 240, 245))
            self.stroke_history.clear()
            logger.info("Canvas cleared")
            return None
        
        # Color selector
        color_start_x = 80
        for i, color in enumerate(self.colors):
            color_x = color_start_x + i * 40
            if color_x <= x < color_x + 30 and toolbar_y + 5 <= y < toolbar_y + 45:
                self.color_index = i
                self.stroke_color = color
                logger.info(f"Color changed to index {i}")
                return None
        
        # Back button
        if self.width - 60 <= x < self.width - 10 and toolbar_y + 5 <= y < toolbar_y + 45:
            from ui import AppID
            return AppID.HOME
        
        return None
    
    def render(self) -> Image.Image:
        """Render paint app"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        
        # Draw canvas
        self.framebuffer.paste(self.canvas, (0, 0))
        
        # Draw toolbar
        draw = ImageDraw.Draw(self.framebuffer)
        toolbar_y = self.height - 50
        
        # Toolbar background
        draw.rectangle([(0, toolbar_y), (self.width, self.height)], fill=(30, 30, 40))
        draw.line([(0, toolbar_y), (self.width, toolbar_y)], fill=(80, 80, 100), width=2)
        
        # Clear button
        draw.rectangle([(10, toolbar_y + 5), (70, toolbar_y + 45)], outline=(100, 100, 120), width=2)
        draw.text((40, toolbar_y + 25), "Clear", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Color palette
        color_start_x = 80
        for i, color in enumerate(self.colors):
            color_x = color_start_x + i * 40
            outline = (255, 200, 100) if i == self.color_index else (80, 80, 100)
            draw.rectangle(
                [(color_x, toolbar_y + 10), (color_x + 30, toolbar_y + 40)],
                fill=color, outline=outline, width=2 if i == self.color_index else 1
            )
        
        # Back button
        draw.rectangle(
            [(self.width - 60, toolbar_y + 5), (self.width - 10, toolbar_y + 45)],
            outline=(100, 100, 120), width=2
        )
        draw.text((self.width - 35, toolbar_y + 25), "Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        return self.framebuffer

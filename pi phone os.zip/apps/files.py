"""
File Browser - Browse and manage files on the device
"""

import logging
import os
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class FileItem:
    """File or directory item"""
    
    def __init__(self, path: str, name: str, is_dir: bool):
        self.path = path
        self.name = name
        self.is_dir = is_dir
        self.selected = False
        
        # Get size
        try:
            if is_dir:
                self.size = None
            else:
                self.size = os.path.getsize(path)
        except:
            self.size = 0
    
    def get_display_name(self) -> str:
        """Get display name with truncation"""
        if len(self.name) > 25:
            return self.name[:22] + "..."
        return self.name
    
    def get_display_size(self) -> str:
        """Get formatted size"""
        if self.is_dir:
            return "<DIR>"
        
        if self.size is None or self.size == 0:
            return "0 B"
        
        for unit in ['B', 'KB', 'MB', 'GB']:
            if self.size < 1024:
                return f"{self.size:.1f} {unit}"
            self.size /= 1024
        
        return f"{self.size:.1f} TB"


class FileBrowser(BaseApp):
    """File browser application"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Files"
        
        # Current directory
        self.current_path = os.path.expanduser("~")
        self.files: List[FileItem] = []
        self.scroll_offset = 0
        self.selected_index = -1
        
        # Metadata
        self.history: List[str] = []
        
        self._load_directory(self.current_path)
    
    def _load_directory(self, path: str) -> None:
        """Load files from directory"""
        self.files = []
        
        try:
            # Add parent directory link (unless at root)
            if path != "/":
                parent = os.path.dirname(path)
                self.files.append(FileItem(parent, "..", is_dir=True))
            
            # List directory contents
            items = os.listdir(path)
            items.sort()
            
            for item_name in items:
                item_path = os.path.join(path, item_name)
                
                # Skip hidden files
                if item_name.startswith('.'):
                    continue
                
                is_dir = os.path.isdir(item_path)
                self.files.append(FileItem(item_path, item_name, is_dir))
            
            self.current_path = path
            self.selected_index = -1
            self.scroll_offset = 0
            
            logger.info(f"Loaded {len(self.files)} items from {path}")
        
        except PermissionError:
            logger.warning(f"Permission denied: {path}")
            self.files = []
        except Exception as e:
            logger.error(f"Error loading directory: {e}")
            self.files = []
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle tap"""
        # Back button
        if 10 <= x < 70 and self.height - 45 <= y < self.height - 5:
            from ui import AppID
            return AppID.HOME
        
        # File list
        file_y = 70
        for i, file_item in enumerate(self.files):
            if file_y <= y < file_y + 40:
                if file_item.is_dir:
                    # Open directory
                    self.history.append(self.current_path)
                    self._load_directory(file_item.path)
                    return None
                else:
                    # Select file
                    self.selected_index = i
                    logger.info(f"Selected file: {file_item.path}")
                    return None
            
            file_y += 45
            if file_y > self.height - 60:
                break
        
        return None
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe navigation"""
        # Swipe right to go back
        if x2 - x1 > 50:
            if self.history:
                prev_path = self.history.pop()
                self._load_directory(prev_path)
                logger.info("Navigated back")
    
    def render(self) -> Image.Image:
        """Render file browser"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Header
        draw.rectangle([(0, 0), (self.width, 50)], fill=(30, 30, 40))
        
        # Back button
        draw.rectangle([(10, 10), (60, 40)], outline=(100, 100, 120), width=2)
        draw.text((35, 25), "Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Path display
        path_display = self.current_path
        if len(path_display) > 20:
            path_display = "..." + path_display[-17:]
        
        draw.text((70, 25), path_display, fill=(150, 150, 200), font=self.font_small, anchor="lm")
        
        # Separator
        draw.line([(0, 50), (self.width, 50)], fill=(50, 50, 60), width=1)
        
        # File list
        file_y = 70
        for i, file_item in enumerate(self.files):
            if file_y > self.height - 60:
                break
            
            # Highlight selected
            if i == self.selected_index:
                draw.rectangle([(5, file_y), (self.width - 5, file_y + 40)],
                              fill=(40, 50, 70), outline=(100, 150, 255), width=2)
                text_color = (150, 200, 255)
            else:
                text_color = (180, 180, 200)
            
            # Icon
            icon = "📁" if file_item.is_dir else "📄"
            draw.text((15, file_y + 10), icon, fill=text_color, font=self.font_default)
            
            # Filename
            draw.text((45, file_y + 10), file_item.get_display_name(),
                     fill=text_color, font=self.font_default)
            
            # Size
            draw.text((self.width - 15, file_y + 10), file_item.get_display_size(),
                     fill=(100, 100, 120), font=self.font_small, anchor="rm")
            
            # Separator
            draw.line([(10, file_y + 40), (self.width - 10, file_y + 40)],
                     fill=(50, 50, 60), width=1)
            
            file_y += 45
        
        # Toolbar
        draw.rectangle([(0, self.height - 50), (self.width, self.height)], fill=(30, 30, 40))
        draw.line([(0, self.height - 50), (self.width, self.height - 50)], fill=(50, 50, 60), width=2)
        
        # File count
        file_count = len(self.files)
        draw.text((10, self.height - 25), f"{file_count} items",
                 fill=(100, 100, 120), font=self.font_small, anchor="lm")
        
        # Current size info
        if self.selected_index >= 0:
            file_item = self.files[self.selected_index]
            draw.text((self.width - 10, self.height - 25), file_item.get_display_size(),
                     fill=(150, 180, 200), font=self.font_small, anchor="rm")
        
        return self.framebuffer


class StorageManager:
    """System storage management and statistics"""
    
    @staticmethod
    def get_disk_usage(path: str = "/") -> Tuple[int, int, int]:
        """
        Get disk usage statistics
        
        Returns:
            Tuple of (total, used, free) in bytes
        """
        try:
            import shutil
            stat = shutil.disk_usage(path)
            return (stat.total, stat.used, stat.free)
        except:
            return (0, 0, 0)
    
    @staticmethod
    def get_directory_size(path: str) -> int:
        """Calculate total size of directory"""
        total_size = 0
        
        try:
            for entry in os.scandir(path):
                if entry.is_file(follow_symlinks=False):
                    total_size += entry.stat().st_size
                elif entry.is_dir(follow_symlinks=False):
                    total_size += StorageManager.get_directory_size(entry.path)
        except PermissionError:
            pass
        
        return total_size
    
    @staticmethod
    def format_size(bytes_size: int) -> str:
        """Format bytes to human-readable string"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_size < 1024:
                return f"{bytes_size:.1f} {unit}"
            bytes_size /= 1024
        return f"{bytes_size:.1f} PB"
    
    @staticmethod
    def get_free_space_percent(path: str = "/") -> float:
        """Get percentage of free disk space"""
        total, used, free = StorageManager.get_disk_usage(path)
        
        if total == 0:
            return 0.0
        
        return (free / total) * 100


class CacheManager:
    """Manage application cache and temporary files"""
    
    @staticmethod
    def get_cache_dir() -> str:
        """Get cache directory"""
        cache_dir = os.path.expanduser("~/.cache/pi-phone")
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir
    
    @staticmethod
    def clear_cache() -> int:
        """Clear cache directory and return bytes freed"""
        import shutil
        cache_dir = CacheManager.get_cache_dir()
        freed = 0
        
        try:
            for filename in os.listdir(cache_dir):
                path = os.path.join(cache_dir, filename)
                
                if os.path.isfile(path):
                    freed += os.path.getsize(path)
                    os.remove(path)
                elif os.path.isdir(path):
                    freed += StorageManager.get_directory_size(path)
                    shutil.rmtree(path)
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
        
        return freed
    
    @staticmethod
    def get_cache_size() -> int:
        """Get total cache size"""
        cache_dir = CacheManager.get_cache_dir()
        
        if not os.path.exists(cache_dir):
            return 0
        
        return StorageManager.get_directory_size(cache_dir)

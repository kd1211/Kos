"""
Terminal App - Simple command interface
"""

import logging
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class TerminalApp(BaseApp):
    """Simple terminal/command interface"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Terminal"
        
        # Command history and output
        self.history: List[str] = [
            "Pi Phone OS Terminal",
            "Type commands below...",
            "",
        ]
        
        self.input_text = ""
        self.cursor_visible = True
        self.cursor_time = 0
        
        # Known commands
        self.commands = {
            "help": self._cmd_help,
            "clear": self._cmd_clear,
            "info": self._cmd_info,
            "time": self._cmd_time,
            "echo": self._cmd_echo,
            "version": self._cmd_version,
        }
        
        # Scroll offset
        self.scroll_offset = 0
    
    def _cmd_help(self, args: str = "") -> str:
        """Help command"""
        return ("Available commands:\n"
                "  help - Show this help\n"
                "  clear - Clear terminal\n"
                "  info - System info\n"
                "  time - Show current time\n"
                "  echo [text] - Echo text\n"
                "  version - Show OS version")
    
    def _cmd_clear(self, args: str = "") -> str:
        """Clear terminal"""
        self.history.clear()
        return ""
    
    def _cmd_info(self, args: str = "") -> str:
        """System info"""
        return ("Device: Raspberry Pi Zero W\n"
                "Display: 320x480 ST7796S\n"
                "Touch: FT6336U\n"
                "Memory: ~256MB\n"
                "Python: 3.x")
    
    def _cmd_time(self, args: str = "") -> str:
        """Show time"""
        import datetime
        return f"Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    def _cmd_echo(self, args: str = "") -> str:
        """Echo command"""
        return args if args else ""
    
    def _cmd_version(self, args: str = "") -> str:
        """Version info"""
        return "Pi Phone OS v1.0"
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle taps"""
        # Back button
        if 10 <= x < 60 and self.height - 45 <= y < self.height - 5:
            from ui import AppID
            return AppID.HOME
        
        return None
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Handle touch - focus input"""
        if y > self.height - 60:
            # Input area
            pass
    
    def update(self) -> None:
        """Update cursor blink"""
        self.cursor_time += 0.05
        if self.cursor_time > 1.0:
            self.cursor_time = 0
        self.cursor_visible = self.cursor_time < 0.5
    
    def process_command(self, cmd: str) -> None:
        """Process a command"""
        self.history.append(f"> {cmd}")
        
        if not cmd.strip():
            return
        
        # Parse command
        parts = cmd.strip().split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        
        if command in self.commands:
            result = self.commands[command](args)
            if result:
                self.history.append(result)
        else:
            self.history.append(f"Unknown command: {command}")
        
        self.history.append("")
        
        # Keep history size reasonable
        if len(self.history) > 100:
            self.history = self.history[-50:]
    
    def render(self) -> Image.Image:
        """Render terminal"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(20, 20, 25))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Title bar
        draw.rectangle([(0, 0), (self.width, 50)], fill=(30, 30, 40))
        draw.text((10, 10), "Terminal", fill=(100, 200, 100), font=self.font_title)
        
        # Back button
        draw.rectangle([(self.width - 60, 10), (self.width - 10, 40)], outline=(100, 100, 120), width=2)
        draw.text((self.width - 35, 25), "Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Separator
        draw.line([(0, 50), (self.width, 50)], fill=(50, 50, 60), width=1)
        
        # Output area
        output_y = 60
        line_height = 16
        visible_lines = (self.height - 100) // line_height
        
        # Calculate scroll
        total_lines = len(self.history)
        max_scroll = max(0, total_lines - visible_lines)
        
        # Render history
        start_idx = max(0, total_lines - visible_lines)
        for i, line in enumerate(self.history[start_idx:]):
            if output_y + line_height > self.height - 50:
                break
            
            # Syntax highlighting
            if line.startswith(">"):
                color = (100, 200, 100)
            elif line.startswith("Unknown"):
                color = (200, 100, 100)
            else:
                color = (180, 180, 200)
            
            draw.text((10, output_y), line, fill=color, font=self.font_small)
            output_y += line_height
        
        # Input area
        draw.rectangle([(0, self.height - 50), (self.width, self.height)], fill=(25, 25, 35))
        draw.line([(0, self.height - 50), (self.width, self.height - 50)], fill=(50, 50, 60), width=1)
        
        # Input text
        draw.text((10, self.height - 40), "> " + self.input_text, fill=(100, 200, 100), font=self.font_default)
        
        # Cursor
        if self.cursor_visible and self.input_text:
            cursor_x = 25 + len(self.input_text) * 10
            draw.line([(cursor_x, self.height - 40), (cursor_x, self.height - 20)], fill=(100, 200, 100), width=2)
        
        return self.framebuffer

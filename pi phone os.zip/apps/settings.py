"""
Settings App - Displays system settings and info
"""

import logging
from typing import Optional
from PIL import Image, ImageDraw

from apps import BaseApp

logger = logging.getLogger(__name__)


class SettingsApp(BaseApp):
    """Settings application"""
    
    def __init__(self, width: int = 320, height: int = 480):
        super().__init__(width, height)
        self.name = "Settings"
        
        # Settings options
        self.settings = [
            ("Brightness", "80%"),
            ("Volume", "70%"),
            ("Rotation", "Portrait"),
            ("Touch", "Enabled"),
            ("Display", "120x480"),
            ("Battery", "Simulated"),
        ]
        
        self.scroll_offset = 0
        self.selected_index = 0
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """Handle tap"""
        # Back button
        if 10 <= x < 60 and 35 <= y < 55:
            from ui import AppID
            return AppID.HOME
        
        return None
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe"""
        # Swipe right to go back
        if x2 - x1 > 50:
            from ui import AppID
            # Return would require different mechanism
            logger.info("Swipe right detected")
    
    def render(self) -> Image.Image:
        """Render settings"""
        self.framebuffer = Image.new('RGB', (self.width, self.height), color=(15, 15, 20))
        draw = ImageDraw.Draw(self.framebuffer)
        
        # Back button
        draw.rectangle([(10, 35), (60, 55)], outline=(100, 100, 120), width=2)
        draw.text((35, 45), "< Back", fill=(180, 180, 200), font=self.font_small, anchor="mm")
        
        # Title
        draw.text((80, 45), "Settings", fill=(200, 200, 200), font=self.font_title)
        
        # Separator
        draw.line([(10, 65), (self.width - 10, 65)], fill=(50, 50, 60), width=1)
        
        # Settings list
        y = 75
        for i, (name, value) in enumerate(self.settings):
            # Highlight selected
            if i == self.selected_index:
                draw.rectangle([(10, y), (self.width - 10, y + 35)], fill=(40, 50, 70))
            
            draw.text((20, y + 5), name, fill=(180, 180, 200), font=self.font_default)
            draw.text((self.width - 30, y + 5), value, fill=(100, 180, 255), font=self.font_small, anchor="rt")
            
            y += 40
        
        # Device info
        y = self.height - 80
        draw.line([(10, y), (self.width - 10, y)], fill=(50, 50, 60), width=1)
        
        draw.text((10, y + 10), "Device: Raspberry Pi Zero", fill=(100, 100, 120), font=self.font_small)
        draw.text((10, y + 30), "Display: 320x480 ST7796S", fill=(100, 100, 120), font=self.font_small)
        draw.text((10, y + 50), "Touch: FT6336U", fill=(100, 100, 120), font=self.font_small)
        
        return self.framebuffer

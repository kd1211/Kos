"""
Base application class - template for all apps
"""

from PIL import Image, ImageDraw, ImageFont
from typing import Optional, Tuple


class BaseApp:
    """Base class for all applications"""
    
    def __init__(self, width: int = 320, height: int = 480):
        """
        Initialize app
        
        Args:
            width: Screen width
            height: Screen height
        """
        self.width = width
        self.height = height
        self.name = "App"
        
        # Create framebuffer
        self.framebuffer = Image.new('RGB', (width, height), color=(15, 15, 20))
        
        # Load fonts
        self._load_fonts()
    
    def _load_fonts(self) -> None:
        """Load fonts"""
        try:
            self.font_title = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
            self.font_large = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
            self.font_default = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
            self.font_small = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
        except:
            self.font_title = ImageFont.load_default()
            self.font_large = ImageFont.load_default()
            self.font_default = ImageFont.load_default()
            self.font_small = ImageFont.load_default()
    
    def on_activate(self) -> None:
        """Called when app is activated/shown"""
        pass
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Handle touch down"""
        pass
    
    def on_touch_up(self, x: int, y: int) -> None:
        """Handle touch up"""
        pass
    
    def on_touch_move(self, x: int, y: int, dx: int, dy: int) -> None:
        """Handle touch move"""
        pass
    
    def on_tap(self, x: int, y: int) -> Optional['AppID']:
        """
        Handle tap event
        
        Returns:
            AppID to navigate to, or None
        """
        return None
    
    def on_swipe(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Handle swipe event"""
        pass
    
    def on_long_press(self, x: int, y: int) -> None:
        """Handle long press"""
        pass
    
    def update(self) -> None:
        """Update app state"""
        pass
    
    def render(self) -> Image.Image:
        """
        Render app to image
        
        Returns:
            PIL Image
        """
        return self.framebuffer
    
    def draw_button(self, img: Image.Image, x: int, y: int, w: int, h: int,
                    text: str, pressed: bool = False) -> None:
        """Draw a simple button"""
        draw = ImageDraw.Draw(img)
        
        bg_color = (50, 50, 60) if not pressed else (70, 70, 90)
        border_color = (100, 100, 120) if not pressed else (150, 150, 180)
        
        # Button background
        draw.rectangle([(x, y), (x + w, y + h)], fill=bg_color, outline=border_color, width=2)
        
        # Button text
        draw.text((x + w//2, y + h//2), text, fill=(200, 200, 200),
                 font=self.font_default, anchor="mm")
    
    def draw_rounded_rect(self, img: Image.Image, bounds: Tuple[int, int, int, int],
                          radius: int = 10, fill: Tuple[int, int, int] = (50, 50, 60),
                          outline: Tuple[int, int, int] = (100, 100, 120)) -> None:
        """Draw rounded rectangle"""
        draw = ImageDraw.Draw(img)
        x1, y1, x2, y2 = bounds
        
        # Draw corners as circles and lines
        # Simplified: just draw regular rectangle with lines
        draw.rectangle(bounds, fill=fill, outline=outline, width=1)

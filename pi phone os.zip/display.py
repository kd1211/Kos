"""
Display driver for ST7796S controller via SPI
Handles framebuffer management and hardware communication
"""

import logging
import time
from typing import Optional

from PIL import Image
import numpy as np

logger = logging.getLogger(__name__)


class Display:
    """SPI display controller for ST7796S"""
    
    # ST7796S Commands
    CMD_SWRESET = 0x01          # Software Reset
    CMD_SLPOUT = 0x11           # Sleep Out
    CMD_DISPOFF = 0x28          # Display Off
    CMD_DISPON = 0x29           # Display On
    CMD_CASET = 0x2A            # Column Address Set
    CMD_RASET = 0x2B            # Row Address Set
    CMD_RAMWR = 0x2C            # RAM Write
    CMD_MADCTL = 0x36           # Memory Access Control
    CMD_PIXFMT = 0x3A           # Pixel Format
    CMD_FRMCTR1 = 0xB1          # Frame Rate Control
    CMD_PWCTR1 = 0xC0           # Power Control 1
    CMD_PWCTR2 = 0xC1           # Power Control 2
    CMD_VMCTR1 = 0xC5           # VCOM Control
    CMD_GMCTRP1 = 0xE0          # Gamma Correction Positive
    CMD_GMCTRN1 = 0xE1          # Gamma Correction Negative
    
    def __init__(self, width: int = 320, height: int = 480, 
                 spi_speed: int = 10000000, demo_mode: bool = False):
        """
        Initialize display
        
        Args:
            width: Display width
            height: Display height
            spi_speed: SPI clock speed in Hz
            demo_mode: If True, run without actual hardware
        """
        self.width = width
        self.height = height
        self.spi_speed = spi_speed
        self.demo_mode = demo_mode
        
        self.spi = None
        self.dc_pin = 25      # GPIO for Data/Command
        self.reset_pin = 27   # GPIO for Reset
        self.cs_pin = 8       # SPI CE0
        
        logger.info(f"Initializing display {width}x{height}")
        
        # Initialize framebuffer
        self.framebuffer = Image.new('RGB', (width, height), color=(0, 0, 0))
        
        if not demo_mode:
            self._init_gpio()
            self._init_spi()
            self._init_display()
        else:
            logger.info("Running in demo mode (no hardware)")
    
    def _init_gpio(self) -> None:
        """Initialize GPIO pins"""
        try:
            import RPi.GPIO as GPIO
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            
            GPIO.setup(self.dc_pin, GPIO.OUT)
            GPIO.setup(self.reset_pin, GPIO.OUT)
            
            logger.info("GPIO initialized")
        except Exception as e:
            logger.error(f"Failed to initialize GPIO: {e}")
            raise
    
    def _init_spi(self) -> None:
        """Initialize SPI interface"""
        try:
            from spidev import SpiDev
            
            self.spi = SpiDev()
            self.spi.open(0, 0)  # Bus 0, Device 0
            self.spi.max_speed_hz = self.spi_speed
            self.spi.mode = 0
            
            logger.info(f"SPI initialized at {self.spi_speed/1e6:.1f} MHz")
        except Exception as e:
            logger.error(f"Failed to initialize SPI: {e}")
            raise
    
    def _init_display(self) -> None:
        """Initialize ST7796S display"""
        try:
            import RPi.GPIO as GPIO
            
            # Hardware reset
            GPIO.output(self.reset_pin, GPIO.HIGH)
            time.sleep(0.1)
            GPIO.output(self.reset_pin, GPIO.LOW)
            time.sleep(0.1)
            GPIO.output(self.reset_pin, GPIO.HIGH)
            time.sleep(0.1)
            
            # Initialize display
            self._cmd(self.CMD_SWRESET)
            time.sleep(0.15)
            
            self._cmd(self.CMD_SLPOUT)
            time.sleep(0.15)
            
            # Set pixel format (18-bit color)
            self._cmd(self.CMD_PIXFMT)
            self._data([0x66])
            
            # Set memory access control (rotation)
            self._cmd(self.CMD_MADCTL)
            self._data([0x48])  # Normal orientation
            
            # Frame rate control
            self._cmd(self.CMD_FRMCTR1)
            self._data([0x00, 0x1B])
            
            # Power control
            self._cmd(self.CMD_PWCTR1)
            self._data([0x09, 0x09])
            
            self._cmd(self.CMD_PWCTR2)
            self._data([0x04])
            
            self._cmd(self.CMD_VMCTR1)
            self._data([0x2F, 0x3B])
            
            # Gamma correction (simplified)
            self._cmd(self.CMD_GMCTRP1)
            self._data([0x00, 0x09, 0x0F, 0x0C, 0x0F, 0x15, 0x38, 0x33,
                       0x50, 0x36, 0x13, 0x13, 0x2E, 0x37])
            
            self._cmd(self.CMD_GMCTRN1)
            self._data([0x00, 0x09, 0x0F, 0x0C, 0x0E, 0x08, 0x30, 0x34,
                       0x47, 0x44, 0x13, 0x13, 0x2C, 0x32])
            
            # Turn on display
            self._cmd(self.CMD_DISPON)
            time.sleep(0.1)
            
            logger.info("Display initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize display: {e}")
            raise
    
    def _cmd(self, cmd: int) -> None:
        """Send command byte"""
        if not self.spi:
            return
        
        try:
            import RPi.GPIO as GPIO
            GPIO.output(self.dc_pin, GPIO.LOW)  # DC=0 for command
            self.spi.writebytes([cmd])
        except Exception as e:
            logger.error(f"Failed to send command: {e}")
    
    def _data(self, data: list) -> None:
        """Send data bytes"""
        if not self.spi:
            return
        
        try:
            import RPi.GPIO as GPIO
            GPIO.output(self.dc_pin, GPIO.HIGH)  # DC=1 for data
            self.spi.writebytes(data)
        except Exception as e:
            logger.error(f"Failed to send data: {e}")
    
    def _set_window(self, x: int, y: int, w: int, h: int) -> None:
        """Set window/region for drawing"""
        # Column address
        self._cmd(self.CMD_CASET)
        self._data([(x >> 8) & 0xFF, x & 0xFF,
                   ((x + w - 1) >> 8) & 0xFF, (x + w - 1) & 0xFF])
        
        # Row address
        self._cmd(self.CMD_RASET)
        self._data([(y >> 8) & 0xFF, y & 0xFF,
                   ((y + h - 1) >> 8) & 0xFF, (y + h - 1) & 0xFF])
    
    def show_image(self, image: Image.Image) -> None:
        """
        Display image on screen
        
        Args:
            image: PIL Image object (RGB)
        """
        # Ensure correct size
        if image.size != (self.width, self.height):
            image = image.resize((self.width, self.height), Image.Resampling.LANCZOS)
        
        # Convert to RGB if needed
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        self.framebuffer = image
        
        if self.demo_mode or not self.spi:
            return
        
        try:
            # Convert image to 18-bit RGB (3 bytes per 2 pixels)
            image_data = np.array(image, dtype=np.uint8)
            
            # Set full window
            self._set_window(0, 0, self.width, self.height)
            
            # Prepare data - convert RGB to 18-bit format
            h, w = image_data.shape[:2]
            pixels = []
            
            for row in image_data:
                for pixel in row:
                    r, g, b = pixel[0], pixel[1], pixel[2]
                    # 18-bit color: 6 bits per channel
                    r6 = (r >> 2) & 0x3F
                    g6 = (g >> 2) & 0x3F
                    b6 = (b >> 2) & 0x3F
                    
                    # Pack into 3 bytes
                    byte1 = (r6 << 2) | ((g6 >> 4) & 0x03)
                    byte2 = ((g6 & 0x0F) << 4) | ((b6 >> 2) & 0x0F)
                    byte3 = (b6 << 6) | 0x00
                    
                    pixels.extend([byte1, byte2, byte3])
            
            # Write to display
            self._cmd(self.CMD_RAMWR)
            self._data(pixels)
        
        except Exception as e:
            logger.error(f"Failed to display image: {e}")
    
    def cleanup(self) -> None:
        """Clean up hardware resources"""
        try:
            if self.spi:
                self.spi.close()
            logger.info("Display cleanup complete")
        except Exception as e:
            logger.error(f"Error cleaning up display: {e}")

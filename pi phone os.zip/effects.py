"""
Advanced Features Module - Animations, Notifications, and Effects
Add enhanced visual effects and system notifications to Pi Phone OS
"""

import logging
import time
import math
from typing import Optional, Tuple, List, Callable
from PIL import Image, ImageDraw
from enum import Enum

logger = logging.getLogger(__name__)


class AnimationType(Enum):
    """Animation types"""
    FADE_IN = "fade_in"
    FADE_OUT = "fade_out"
    SLIDE_LEFT = "slide_left"
    SLIDE_RIGHT = "slide_right"
    SLIDE_UP = "slide_up"
    SLIDE_DOWN = "slide_down"
    SCALE = "scale"
    BOUNCE = "bounce"
    ROTATE = "rotate"


class Animation:
    """Base animation class"""
    
    def __init__(self, duration: float = 0.5, anim_type: AnimationType = AnimationType.FADE_IN,
                 on_complete: Optional[Callable] = None):
        """
        Initialize animation
        
        Args:
            duration: Animation duration in seconds
            anim_type: Type of animation
            on_complete: Callback when animation finishes
        """
        self.duration = duration
        self.anim_type = anim_type
        self.on_complete = on_complete
        self.start_time = time.time()
        self.finished = False
    
    def get_progress(self) -> float:
        """Get animation progress (0.0 to 1.0)"""
        elapsed = time.time() - self.start_time
        progress = min(1.0, elapsed / self.duration)
        
        if progress >= 1.0:
            self.finished = True
            if self.on_complete:
                self.on_complete()
        
        return progress
    
    def get_eased_progress(self) -> float:
        """Get eased progress with ease-out cubic"""
        progress = self.get_progress()
        # Ease-out cubic
        return 1 - (1 - progress) ** 3
    
    def apply_to_image(self, img: Image.Image, width: int, height: int) -> Image.Image:
        """Apply animation to image"""
        progress = self.get_eased_progress()
        
        if self.anim_type == AnimationType.FADE_IN:
            return self._fade_in(img, progress)
        elif self.anim_type == AnimationType.FADE_OUT:
            return self._fade_out(img, progress)
        elif self.anim_type == AnimationType.SLIDE_LEFT:
            return self._slide_left(img, width, progress)
        elif self.anim_type == AnimationType.SLIDE_RIGHT:
            return self._slide_right(img, width, progress)
        elif self.anim_type == AnimationType.SLIDE_UP:
            return self._slide_up(img, height, progress)
        elif self.anim_type == AnimationType.SLIDE_DOWN:
            return self._slide_down(img, height, progress)
        elif self.anim_type == AnimationType.SCALE:
            return self._scale(img, width, height, progress)
        elif self.anim_type == AnimationType.BOUNCE:
            return self._bounce(img, height, progress)
        
        return img
    
    def _fade_in(self, img: Image.Image, progress: float) -> Image.Image:
        """Fade in animation"""
        alpha = int(255 * progress)
        img.putalpha(alpha)
        return img
    
    def _fade_out(self, img: Image.Image, progress: float) -> Image.Image:
        """Fade out animation"""
        alpha = int(255 * (1 - progress))
        img.putalpha(alpha)
        return img
    
    def _slide_left(self, img: Image.Image, width: int, progress: float) -> Image.Image:
        """Slide from right to left"""
        offset = int(width * (1 - progress))
        new_img = Image.new('RGBA', (width, img.height), (0, 0, 0, 0))
        new_img.paste(img, (offset, 0), img if img.mode == 'RGBA' else None)
        return new_img
    
    def _slide_right(self, img: Image.Image, width: int, progress: float) -> Image.Image:
        """Slide from left to right"""
        offset = int(-width * (1 - progress))
        new_img = Image.new('RGBA', (width, img.height), (0, 0, 0, 0))
        new_img.paste(img, (offset, 0), img if img.mode == 'RGBA' else None)
        return new_img
    
    def _slide_up(self, img: Image.Image, height: int, progress: float) -> Image.Image:
        """Slide from bottom to top"""
        offset = int(height * (1 - progress))
        new_img = Image.new('RGBA', (img.width, height), (0, 0, 0, 0))
        new_img.paste(img, (0, offset), img if img.mode == 'RGBA' else None)
        return new_img
    
    def _slide_down(self, img: Image.Image, height: int, progress: float) -> Image.Image:
        """Slide from top to bottom"""
        offset = int(-height * (1 - progress))
        new_img = Image.new('RGBA', (img.width, height), (0, 0, 0, 0))
        new_img.paste(img, (0, offset), img if img.mode == 'RGBA' else None)
        return new_img
    
    def _scale(self, img: Image.Image, width: int, height: int, progress: float) -> Image.Image:
        """Scale animation"""
        scale = progress
        new_w = int(width * scale)
        new_h = int(height * scale)
        
        if new_w <= 0 or new_h <= 0:
            return img
        
        scaled = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
        new_img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        
        x = (width - new_w) // 2
        y = (height - new_h) // 2
        new_img.paste(scaled, (x, y), scaled if scaled.mode == 'RGBA' else None)
        
        return new_img
    
    def _bounce(self, img: Image.Image, height: int, progress: float) -> Image.Image:
        """Bounce animation"""
        # Bounce ease
        if progress < 0.5:
            bounce = 4 * progress * progress * (1 - progress)
        else:
            bounce = 1 - (-2 * progress + 2) ** 2 / 2
        
        offset = int(height * bounce * 0.2)
        new_img = Image.new('RGBA', (img.width, height), (0, 0, 0, 0))
        new_img.paste(img, (0, offset), img if img.mode == 'RGBA' else None)
        return new_img


class Notification:
    """System notification"""
    
    def __init__(self, title: str, message: str, duration: float = 2.0,
                 notification_type: str = "info"):
        """
        Create notification
        
        Args:
            title: Notification title
            message: Notification message
            duration: Display duration in seconds
            notification_type: Type (info, success, warning, error)
        """
        self.title = title
        self.message = message
        self.duration = duration
        self.type = notification_type
        self.created_time = time.time()
        self.dismissed = False
    
    def is_expired(self) -> bool:
        """Check if notification should be hidden"""
        return time.time() - self.created_time > self.duration or self.dismissed
    
    def dismiss(self) -> None:
        """Manually dismiss notification"""
        self.dismissed = True
    
    def get_color(self) -> Tuple[int, int, int]:
        """Get color based on type"""
        colors = {
            "info": (100, 180, 255),      # Blue
            "success": (100, 200, 100),    # Green
            "warning": (200, 200, 50),     # Yellow
            "error": (200, 100, 100),      # Red
        }
        return colors.get(self.type, (100, 180, 255))


class NotificationCenter:
    """Manage system notifications"""
    
    def __init__(self):
        self.notifications: List[Notification] = []
    
    def add(self, title: str, message: str, duration: float = 2.0,
            notification_type: str = "info") -> None:
        """Add notification"""
        notif = Notification(title, message, duration, notification_type)
        self.notifications.append(notif)
        logger.info(f"Notification: {title} - {message}")
    
    def remove_expired(self) -> None:
        """Remove expired notifications"""
        self.notifications = [n for n in self.notifications if not n.is_expired()]
    
    def clear(self) -> None:
        """Clear all notifications"""
        self.notifications.clear()
    
    def render(self, draw: ImageDraw.ImageDraw, width: int, height: int,
               font: ImageFont.FreeTypeFont) -> None:
        """Render notifications on screen"""
        self.remove_expired()
        
        # Draw notifications at bottom
        y = height - 20
        for notif in reversed(self.notifications):
            if y < 0:
                break
            
            color = notif.get_color()
            text = f"● {notif.title}: {notif.message}"
            
            # Draw notification background
            draw.rectangle([(5, y - 15), (width - 5, y + 5)],
                          fill=(30, 30, 40), outline=color, width=1)
            
            # Draw text
            draw.text((10, y - 5), text, fill=color, font=font, anchor="lm")
            
            y -= 25


class AnimationManager:
    """Manage active animations"""
    
    def __init__(self):
        self.animations: List[Animation] = []
    
    def add(self, animation: Animation) -> None:
        """Add animation"""
        self.animations.append(animation)
    
    def update(self) -> None:
        """Update all animations"""
        # Remove finished animations
        self.animations = [a for a in self.animations if not a.finished]
    
    def has_active(self) -> bool:
        """Check if any animations are active"""
        return len(self.animations) > 0


class TransitionEffect:
    """Smooth screen transition effects"""
    
    def __init__(self, width: int = 320, height: int = 480):
        self.width = width
        self.height = height
        self.transition_type = None
        self.progress = 0.0
        self.duration = 0.3  # 300ms transition
        self.start_time = None
    
    def start_transition(self, transition_type: str = "fade") -> None:
        """Start a transition"""
        self.transition_type = transition_type
        self.start_time = time.time()
    
    def is_active(self) -> bool:
        """Check if transition is active"""
        if not self.start_time:
            return False
        
        elapsed = time.time() - self.start_time
        self.progress = min(1.0, elapsed / self.duration)
        
        return self.progress < 1.0
    
    def apply(self, current: Image.Image, next_frame: Image.Image) -> Image.Image:
        """Apply transition between two frames"""
        if not self.is_active():
            return next_frame
        
        if self.transition_type == "fade":
            return self._fade_transition(current, next_frame)
        elif self.transition_type == "slide_left":
            return self._slide_transition(current, next_frame, "left")
        elif self.transition_type == "slide_right":
            return self._slide_transition(current, next_frame, "right")
        
        return next_frame
    
    def _fade_transition(self, current: Image.Image, next_frame: Image.Image) -> Image.Image:
        """Fade between frames"""
        # Blend images based on progress
        current_alpha = int(255 * (1 - self.progress))
        next_alpha = int(255 * self.progress)
        
        result = current.copy()
        result.putalpha(current_alpha)
        
        next_with_alpha = next_frame.copy()
        if next_with_alpha.mode != 'RGBA':
            next_with_alpha = next_with_alpha.convert('RGBA')
        next_with_alpha.putalpha(next_alpha)
        
        if result.mode != 'RGBA':
            result = result.convert('RGBA')
        
        result.alpha_composite(next_with_alpha)
        return result.convert('RGB')
    
    def _slide_transition(self, current: Image.Image, next_frame: Image.Image,
                         direction: str) -> Image.Image:
        """Slide transition"""
        offset = int(self.width * self.progress)
        
        result = Image.new('RGB', (self.width, self.height))
        
        if direction == "left":
            # Slide current left, next comes from right
            result.paste(current, (-offset, 0))
            result.paste(next_frame, (self.width - offset, 0))
        else:
            # Slide current right, next comes from left
            result.paste(current, (offset, 0))
            result.paste(next_frame, (-self.width + offset, 0))
        
        return result


class ProgressBar:
    """Animated progress bar"""
    
    def __init__(self, width: int = 200, height: int = 10):
        self.width = width
        self.height = height
        self.progress = 0.0
        self.target_progress = 0.0
    
    def set_progress(self, value: float) -> None:
        """Set target progress (0.0 to 1.0)"""
        self.target_progress = max(0.0, min(1.0, value))
    
    def update(self, delta_time: float = 0.016) -> None:
        """Update progress smoothly"""
        # Smooth animation to target
        diff = self.target_progress - self.progress
        self.progress += diff * 0.1  # Smooth factor
    
    def draw(self, draw: ImageDraw.ImageDraw, x: int, y: int,
             color: Tuple[int, int, int] = (100, 180, 255)) -> None:
        """Draw progress bar"""
        # Background
        draw.rectangle([(x, y), (x + self.width, y + self.height)],
                      fill=(50, 50, 60), outline=(100, 100, 120))
        
        # Progress fill
        fill_width = int(self.width * self.progress)
        if fill_width > 0:
            draw.rectangle([(x + 1, y + 1), (x + fill_width, y + self.height - 1)],
                          fill=color)


class ParticleEffect:
    """Simple particle effect system"""
    
    class Particle:
        def __init__(self, x: float, y: float, vx: float, vy: float,
                     color: Tuple[int, int, int], lifetime: float):
            self.x = x
            self.y = y
            self.vx = vx
            self.vy = vy
            self.color = color
            self.lifetime = lifetime
            self.age = 0.0
        
        def update(self, delta_time: float) -> None:
            self.x += self.vx * delta_time
            self.y += self.vy * delta_time
            self.age += delta_time
        
        def is_alive(self) -> bool:
            return self.age < self.lifetime
        
        def get_alpha(self) -> float:
            return 1.0 - (self.age / self.lifetime)
    
    def __init__(self):
        self.particles: List[ParticleEffect.Particle] = []
    
    def emit(self, x: float, y: float, count: int, color: Tuple[int, int, int],
             speed: float = 100, lifetime: float = 0.5) -> None:
        """Emit particles"""
        import random
        import math
        
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            vx = speed * math.cos(angle)
            vy = speed * math.sin(angle)
            
            particle = ParticleEffect.Particle(x, y, vx, vy, color, lifetime)
            self.particles.append(particle)
    
    def update(self, delta_time: float) -> None:
        """Update all particles"""
        for particle in self.particles:
            particle.update(delta_time)
        
        # Remove dead particles
        self.particles = [p for p in self.particles if p.is_alive()]
    
    def draw(self, draw: ImageDraw.ImageDraw, width: int, height: int) -> None:
        """Draw all particles"""
        for particle in self.particles:
            x, y = int(particle.x), int(particle.y)
            
            # Only draw if on screen
            if 0 <= x < width and 0 <= y < height:
                alpha = int(255 * particle.get_alpha())
                color = tuple(int(c * particle.get_alpha()) for c in particle.color)
                
                # Draw small circle
                draw.ellipse([(x - 2, y - 2), (x + 2, y + 2)], fill=color)

"""
Configuration module for Pi Phone OS
"""

# Display Configuration
DISPLAY_WIDTH = 320
DISPLAY_HEIGHT = 480
DISPLAY_SPI_SPEED = 10000000  # 10 MHz
DISPLAY_SPI_BUS = 0
DISPLAY_SPI_DEVICE = 0

# GPIO Pins (BCM numbering)
GPIO_DC = 25        # Data/Command
GPIO_RST = 27       # Reset
GPIO_CS = 8         # Chip Select (SPI)

# I2C Configuration
I2C_BUS = 1
TOUCH_I2C_ADDR = 0x38

# UI Configuration
UI_TARGET_FPS = 15
UI_THEME = "dark"  # or "light"

# Colors (RGB)
COLOR_BG_DARK = (15, 15, 20)
COLOR_BG_LIGHT = (240, 240, 245)
COLOR_TEXT_DARK = (180, 180, 200)
COLOR_TEXT_LIGHT = (50, 50, 60)
COLOR_ACCENT = (100, 180, 255)
COLOR_SUCCESS = (100, 200, 100)
COLOR_WARNING = (200, 200, 50)
COLOR_ERROR = (200, 100, 100)
COLOR_BORDER = (100, 100, 120)

# Touch Configuration
TOUCH_DEBOUNCE_MS = 50
TOUCH_TAP_THRESHOLD = 30  # pixels
TOUCH_TAP_TIME_MAX = 0.3  # seconds
TOUCH_SWIPE_THRESHOLD = 30  # pixels
TOUCH_SWIPE_TIME_MAX = 0.5  # seconds
TOUCH_LONG_PRESS_TIME = 0.5  # seconds

# App Configuration
APP_ICONS_PER_ROW = 3
APP_ICON_SIZE = 70
APP_ICON_SPACING = 20

# Folder Paths
FOLDER_PICTURES = "~/Pictures"
FOLDER_MUSIC = "~/Music"
FOLDER_DOCUMENTS = "~/Documents"

# Debug/Demo Mode
DEMO_MODE = False  # Set True to run without hardware
DEBUG_LOGGING = False  # Set True for verbose logging
PROFILE_PERFORMANCE = False  # Set True to log FPS

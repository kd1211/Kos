"""
On-Screen Keyboard - Touch-based text input system
"""

import logging
from typing import Optional, List, Tuple
from PIL import Image, ImageDraw

logger = logging.getLogger(__name__)


class Key:
    """Single keyboard key"""
    
    def __init__(self, x: int, y: int, w: int, h: int, char: str,
                 shift_char: Optional[str] = None, special: bool = False):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.char = char
        self.shift_char = shift_char or char
        self.special = special  # Is special key (backspace, enter, etc)
        self.pressed = False
    
    def contains(self, x: int, y: int) -> bool:
        """Check if point is inside key"""
        return (self.x <= x < self.x + self.w and
                self.y <= y < self.y + self.h)
    
    def draw(self, draw: ImageDraw.ImageDraw, font, shift_active: bool = False) -> None:
        """Draw key"""
        # Background
        bg_color = (60, 60, 70) if not self.pressed else (80, 100, 120)
        border_color = (120, 120, 140) if not self.pressed else (150, 180, 220)
        
        draw.rectangle([(self.x, self.y), (self.x + self.w, self.y + self.h)],
                      fill=bg_color, outline=border_color, width=1)
        
        # Text
        display_char = self.shift_char if shift_active else self.char
        
        if self.special:
            text_color = (150, 150, 200)
        else:
            text_color = (200, 200, 220)
        
        draw.text((self.x + self.w // 2, self.y + self.h // 2),
                 display_char, fill=text_color, font=font, anchor="mm")


class Keyboard:
    """On-screen QWERTY keyboard"""
    
    def __init__(self, width: int = 320, height: int = 200):
        self.width = width
        self.height = height
        self.keys: List[Key] = []
        self.shift_active = False
        self.input_text = ""
        
        self._create_layout()
    
    def _create_layout(self) -> None:
        """Create keyboard layout"""
        key_w = 28
        key_h = 32
        key_gap = 4
        start_x = 5
        start_y = 5
        
        # Row 1: QWERTY
        row1 = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P']
        for i, char in enumerate(row1):
            x = start_x + i * (key_w + key_gap)
            y = start_y
            self.keys.append(Key(x, y, key_w, key_h, char.lower(), char.upper()))
        
        # Row 2: ASDFGH...
        row2 = ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L']
        offset = (key_w + key_gap) // 2
        for i, char in enumerate(row2):
            x = start_x + offset + i * (key_w + key_gap)
            y = start_y + (key_h + key_gap)
            self.keys.append(Key(x, y, key_w, key_h, char.lower(), char.upper()))
        
        # Row 3: ZXCV...
        row3 = ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
        offset = (key_w + key_gap)
        for i, char in enumerate(row3):
            x = start_x + offset + i * (key_w + key_gap)
            y = start_y + 2 * (key_h + key_gap)
            self.keys.append(Key(x, y, key_w, key_h, char.lower(), char.upper()))
        
        # Row 4: Modifiers and numbers
        
        # Shift (left side)
        self.shift_key = Key(start_x, start_y + 3 * (key_h + key_gap),
                            key_w + 10, key_h, "⇧", special=True)
        self.keys.append(self.shift_key)
        
        # Space
        space_x = start_x + (key_w + key_gap) * 2
        self.space_key = Key(space_x, start_y + 3 * (key_h + key_gap),
                            self.width - space_x - start_x - (key_w + 10) - key_gap,
                            key_h, " ", special=True)
        self.keys.append(self.space_key)
        
        # Backspace (right side)
        self.backspace_key = Key(self.width - key_w - start_x,
                                start_y + 3 * (key_h + key_gap),
                                key_w, key_h, "⌫", special=True)
        self.keys.append(self.backspace_key)
        
        # Numbers row (above letters)
        numbers = '1234567890'
        for i, char in enumerate(numbers):
            x = start_x + i * (key_w + key_gap)
            y = -key_h - key_gap
            self.keys.append(Key(x, y, key_w, key_h, char))
    
    def on_tap(self, x: int, y: int) -> Optional[str]:
        """Handle key tap, return character"""
        for key in self.keys:
            if key.contains(x, y):
                # Special keys
                if key == self.shift_key:
                    self.shift_active = not self.shift_active
                    return None
                
                elif key == self.backspace_key:
                    if self.input_text:
                        self.input_text = self.input_text[:-1]
                    return "BACKSPACE"
                
                elif key == self.space_key:
                    self.input_text += " "
                    return " "
                
                # Regular keys
                else:
                    char = key.shift_char if self.shift_active else key.char
                    self.input_text += char
                    
                    # Auto-disable shift after typing
                    if self.shift_active:
                        self.shift_active = False
                    
                    return char
        
        return None
    
    def on_touch_down(self, x: int, y: int) -> None:
        """Handle touch down for key press visual"""
        for key in self.keys:
            if key.contains(x, y):
                key.pressed = True
                break
    
    def on_touch_up(self) -> None:
        """Release all keys"""
        for key in self.keys:
            key.pressed = False
    
    def render(self, draw: ImageDraw.ImageDraw, font) -> None:
        """Render keyboard"""
        for key in self.keys:
            key.draw(draw, font, self.shift_active)


class TextInputField:
    """Text input field with cursor"""
    
    def __init__(self, x: int, y: int, w: int, h: int, 
                 placeholder: str = "Enter text..."):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.placeholder = placeholder
        
        self.text = ""
        self.cursor_pos = 0
        self.cursor_visible = True
        self.cursor_blink_time = 0
        
        self.keyboard = Keyboard(w, 150)
        self.keyboard_visible = False
    
    def contains(self, x: int, y: int) -> bool:
        """Check if point is inside input field"""
        return (self.x <= x < self.x + self.w and
                self.y <= y < self.y + self.h)
    
    def on_tap(self, x: int, y: int) -> None:
        """Handle tap in input field"""
        if self.contains(x, y):
            self.keyboard_visible = not self.keyboard_visible
    
    def on_keyboard_tap(self, x: int, y: int) -> None:
        """Handle keyboard tap"""
        if self.keyboard_visible:
            result = self.keyboard.on_tap(x, y)
            if result == "BACKSPACE":
                if self.cursor_pos > 0:
                    self.text = self.text[:self.cursor_pos - 1] + self.text[self.cursor_pos:]
                    self.cursor_pos -= 1
            elif result:
                self.text = self.text[:self.cursor_pos] + result + self.text[self.cursor_pos:]
                self.cursor_pos += 1
    
    def update(self) -> None:
        """Update cursor blink"""
        self.cursor_blink_time += 0.05
        if self.cursor_blink_time > 1.0:
            self.cursor_blink_time = 0
        self.cursor_visible = self.cursor_blink_time < 0.5
    
    def draw(self, draw: ImageDraw.ImageDraw, font, font_small) -> None:
        """Draw input field and keyboard"""
        # Input field background
        draw.rectangle([(self.x, self.y), (self.x + self.w, self.y + self.h)],
                      fill=(30, 30, 40), outline=(100, 150, 200), width=2)
        
        # Text
        display_text = self.text if self.text else self.placeholder
        text_color = (100, 100, 120) if not self.text else (200, 200, 220)
        
        draw.text((self.x + 10, self.y + self.h // 2), display_text,
                 fill=text_color, font=font, anchor="lm")
        
        # Cursor
        if self.cursor_visible and self.text:
            cursor_x = self.x + 10 + len(self.text[:self.cursor_pos]) * 8
            draw.line([(cursor_x, self.y + 5), (cursor_x, self.y + self.h - 5)],
                     fill=(150, 200, 255), width=2)
        
        # Keyboard (if visible)
        if self.keyboard_visible:
            # Keyboard background
            kb_y = self.y + self.h + 10
            draw.rectangle([(self.x, kb_y), (self.x + self.w, kb_y + 150)],
                          fill=(20, 20, 25), outline=(100, 100, 120), width=2)
            
            # Draw keyboard
            kb_draw = ImageDraw.Draw(Image.new('RGB', (self.w, 150)))
            self.keyboard.render(kb_draw, font_small)


class KeyboardManager:
    """Manage multiple keyboard instances"""
    
    def __init__(self):
        self.keyboards: List[TextInputField] = []
        self.active_field: Optional[TextInputField] = None
    
    def add_field(self, field: TextInputField) -> None:
        """Add input field"""
        self.keyboards.append(field)
    
    def on_tap(self, x: int, y: int) -> None:
        """Handle tap"""
        # Check input fields first
        for field in self.keyboards:
            if field.contains(x, y):
                self.active_field = field
                field.on_tap(x, y)
                return
        
        # Check active keyboard
        if self.active_field and self.active_field.keyboard_visible:
            self.active_field.on_keyboard_tap(x, y)
    
    def update(self) -> None:
        """Update all fields"""
        for field in self.keyboards:
            field.update()
    
    def draw(self, draw: ImageDraw.ImageDraw, font, font_small) -> None:
        """Draw all fields"""
        for field in self.keyboards:
            field.draw(draw, font, font_small)

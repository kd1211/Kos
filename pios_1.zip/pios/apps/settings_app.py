"""
Settings -- a small set of sections:
  Display        - backlight brightness, auto-sleep (screen timeout)
  Sound          - master volume, sound on/off, tap-click feedback
  Theme          - pick from several full-OS color palettes, live preview
  Wi-Fi & BT     - toggle Wi-Fi / Bluetooth radios
  Security       - PIN lock enable/disable + change PIN (numeric keypad)
  Date/Time      - 12h vs 24h clock
  Installed Apps - manage apps installed from the App Store / .phoneapp files
  Developer      - developer mode toggle (status-bar DEV tag + extra info)
  About          - version info + reset everything to defaults

Every control here writes straight through ui.theme (persisted to
~/.pios_settings.json), so other apps/screens read the same live values
immediately -- no reboot needed to see a new theme or hear the new
volume. The PIN itself is enforced by the OS lock screen in
ui/framework.py, not by this app.
"""

import os
from ui import theme, sound
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_MD, FONT_SM, FONT_LG, ACCENT
from apps.app_store_app import _load_registry, _save_registry, INSTALL_DIR

TOP = STATUS_BAR_H + 20
ROW_H = 46
ROW_GAP = 8

MENU_ITEMS = [
    ("display", "\U0001F506", "Display"),
    ("sound", "\U0001F50A", "Sound"),
    ("theme", "\U0001F3A8", "Theme"),
    ("network", "\U0001F4F6", "Wi-Fi & Bluetooth"),
    ("security", "\U0001F512", "Security"),
    ("datetime", "\U0001F550", "Date & Time"),
    ("apps", "\U0001F4E6", "Installed Apps"),
    ("developer", "\U0001F6E0", "Developer"),
    ("about", "\u2139", "About"),
]

SLEEP_CHOICES = [(0, "Off"), (30, "30s"), (60, "1m"), (120, "2m"), (300, "5m")]

NUMPAD_LABELS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "\u232B"]


class SettingsApp(App):
    name = "Settings"
    icon = "\u2699"

    def on_open(self):
        self.section = "menu"
        self._pin_draft = ""
        self._pin_stage = None     # "setpin" | "verify"
        self._pin_pending = None   # "disable" | "change"
        self._pin_error = None
        self._build_menu()

    # -- navigation -----------------------------------------------------
    def _goto(self, section):
        def handler():
            self.section = section
            {
                "menu": self._build_menu,
                "display": self._build_display,
                "sound": self._build_sound,
                "theme": self._build_theme,
                "network": self._build_network,
                "security": self._build_security,
                "datetime": self._build_datetime,
                "apps": self._build_apps,
                "developer": self._build_developer,
                "about": self._build_about,
            }[section]()
        return handler

    def _back_button(self):
        return Button(16, SCREEN_H - 60, 90, 42, "Back", self._goto("menu"), font=FONT_SM)

    def _home_button(self, x):
        return Button(x, SCREEN_H - 60, 90, 42, "Home", self.os.go_home, font=FONT_SM)

    # -- menu -------------------------------------------------------------
    def _build_menu(self):
        self.buttons = []
        y = TOP + 30
        row_h = 44
        for key, icon, label in MENU_ITEMS:
            self.buttons.append(
                Button(20, y, SCREEN_W - 40, row_h, f"{icon}  {label}",
                       self._goto(key), font=FONT_SM))
            y += row_h + 6
        self.buttons.append(
            Button(SCREEN_W // 2 - 60, SCREEN_H - 46, 120, 40,
                   "Home", self.os.go_home, font=FONT_SM))

    # -- display ------------------------------------------------------
    def _build_display(self):
        self.buttons = [
            Button(30, TOP + 130, 70, 55, "-10", self._adjust_brightness(-10), font=FONT_MD),
            Button(SCREEN_W - 100, TOP + 130, 70, 55, "+10", self._adjust_brightness(10), font=FONT_MD),
        ]
        y = TOP + 230
        n = len(SLEEP_CHOICES)
        margin = 10
        cell_w = (SCREEN_W - margin * (n + 1)) // n
        for i, (secs, label) in enumerate(SLEEP_CHOICES):
            x = margin + i * (cell_w + margin)
            self.buttons.append(
                Button(x, y, cell_w, 44, label, self._set_sleep_timeout(secs), font=FONT_SM))
        self.buttons.append(
            Button(SCREEN_W // 2 - 90, y + 70, 180, 44,
                   "Sleep now", self._sleep_now, font=FONT_SM))
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _adjust_brightness(self, delta):
        def handler():
            b = max(10, min(100, theme.get("brightness") + delta))
            theme.set("brightness", b)
            try:
                self.os.lcd.set_backlight(b)
            except Exception:
                pass
        return handler

    def _set_sleep_timeout(self, secs):
        def handler():
            theme.set("sleep_timeout", secs)
        return handler

    def _sleep_now(self):
        self.os.enter_sleep(theme.get("brightness"))

    # -- sound ------------------------------------------------------------
    def _build_sound(self):
        self.buttons = [
            Button(30, TOP + 130, 70, 55, "-10", self._adjust_volume(-10), font=FONT_MD),
            Button(SCREEN_W - 100, TOP + 130, 70, 55, "+10", self._adjust_volume(10), font=FONT_MD),
            Button(SCREEN_W // 2 - 140, TOP + 220, 280, 46,
                   self._sound_label(), self._toggle_sound, font=FONT_SM),
            Button(SCREEN_W // 2 - 140, TOP + 276, 280, 46,
                   self._click_label(), self._toggle_click, font=FONT_SM),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _sound_label(self):
        return f"Sound: {'On' if theme.get('sound_enabled') else 'Off'}"

    def _click_label(self):
        return f"Tap sounds: {'On' if theme.get('click_sound') else 'Off'}"

    def _adjust_volume(self, delta):
        def handler():
            v = max(0, min(100, theme.get("volume") + delta))
            theme.set("volume", v)
            sound.refresh_volume()
            sound.click()
        return handler

    def _toggle_sound(self):
        theme.set("sound_enabled", not theme.get("sound_enabled"))
        self._build_sound()

    def _toggle_click(self):
        theme.set("click_sound", not theme.get("click_sound"))
        self._build_sound()
        sound.click()

    # -- theme ------------------------------------------------------------
    def _build_theme(self):
        self.buttons = []
        names = theme.PRESET_NAMES
        y = TOP + 60
        for i, name in enumerate(names):
            self.buttons.append(
                Button(20, y, SCREEN_W - 40, 44, name, self._set_theme(name), font=FONT_SM))
            y += 50
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _set_theme(self, name):
        def handler():
            theme.set("theme", name)
        return handler

    # -- Wi-Fi & Bluetooth --------------------------------------------------
    def _build_network(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 140, TOP + 90, 280, 50,
                   self._wifi_label(), self._toggle_wifi, font=FONT_MD),
            Button(SCREEN_W // 2 - 140, TOP + 150, 280, 50,
                   self._bt_label(), self._toggle_bt, font=FONT_MD),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _wifi_label(self):
        return f"Wi-Fi: {'On' if theme.get('wifi_enabled') else 'Off'}"

    def _bt_label(self):
        return f"Bluetooth: {'On' if theme.get('bluetooth_enabled') else 'Off'}"

    def _toggle_wifi(self):
        theme.set("wifi_enabled", not theme.get("wifi_enabled"))
        self._build_network()

    def _toggle_bt(self):
        theme.set("bluetooth_enabled", not theme.get("bluetooth_enabled"))
        self._build_network()

    # -- Security / PIN lock -------------------------------------------------
    def _build_security(self):
        self.buttons = []
        pin_on = theme.get("pin_enabled")
        y = TOP + 60
        label = "Disable PIN Lock" if pin_on else "Enable PIN Lock"
        self.buttons.append(Button(20, y, SCREEN_W - 40, 46, label, self._toggle_pin_lock, font=FONT_SM))
        if pin_on:
            self.buttons.append(
                Button(20, y + 56, SCREEN_W - 40, 46, "Change PIN", self._start_change_pin, font=FONT_SM))
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _toggle_pin_lock(self):
        if theme.get("pin_enabled"):
            self._start_verify("disable")
        else:
            if theme.get("pin_code"):
                theme.set("pin_enabled", True)
                self._build_security()
            else:
                self._start_setpin("enable")

    def _start_change_pin(self):
        self._start_verify("change")

    # -- verify existing PIN before disabling/changing -----------------------
    def _start_verify(self, pending):
        self.section = "security_verify"
        self._pin_draft = ""
        self._pin_error = None
        self._pin_pending = pending
        self._build_pin_screen()

    def _build_pin_screen(self):
        """Shared numeric-keypad layout for both verify and set-pin screens."""
        self.buttons = []
        cols, rows = 3, 4
        bw, bh = 78, 50
        gap = 10
        grid_w = cols * bw + (cols - 1) * gap
        x0 = (SCREEN_W - grid_w) // 2
        y0 = TOP + 140
        for i, lab in enumerate(NUMPAD_LABELS):
            r, c = divmod(i, cols)
            x = x0 + c * (bw + gap)
            y = y0 + r * (bh + gap)
            self.buttons.append(Button(x, y, bw, bh, lab, self._pin_key(lab), font=FONT_MD))
        self.buttons.append(Button(16, SCREEN_H - 50, 90, 38, "Cancel", self._cancel_pin_flow, font=FONT_SM))

    def _pin_key(self, lab):
        def handler():
            if lab == "C":
                self._pin_draft = ""
            elif lab == "\u232B":
                self._pin_draft = self._pin_draft[:-1]
            elif len(self._pin_draft) < 4:
                self._pin_draft += lab
                if len(self._pin_draft) == 4:
                    self._pin_submit()
        return handler

    def _pin_submit(self):
        if self.section == "security_verify":
            if self._pin_draft == theme.get("pin_code"):
                pending = self._pin_pending
                self._pin_error = None
                if pending == "disable":
                    theme.set("pin_enabled", False)
                    self.section = "security"
                    self._build_security()
                else:  # change
                    self._start_setpin("change")
            else:
                self._pin_error = "Incorrect PIN"
                self._pin_draft = ""
        else:  # security_setpin
            theme.set("pin_code", self._pin_draft)
            theme.set("pin_enabled", True)
            self.section = "security"
            self._build_security()

    def _start_setpin(self, pending):
        self.section = "security_setpin"
        self._pin_draft = ""
        self._pin_error = None
        self._pin_pending = pending
        self._build_pin_screen()

    def _cancel_pin_flow(self):
        self.section = "security"
        self._pin_draft = ""
        self._pin_error = None
        self._build_security()

    # -- date & time --------------------------------------------------
    def _build_datetime(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 140, TOP + 100, 280, 50,
                   self._clock_label(), self._toggle_clock_format, font=FONT_MD),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _clock_label(self):
        return "24-hour clock" if theme.get("clock_24h") else "12-hour clock"

    def _toggle_clock_format(self):
        theme.set("clock_24h", not theme.get("clock_24h"))
        self._build_datetime()

    # -- installed apps -------------------------------------------------------
    def _build_apps(self):
        self.buttons = []
        self._registry = _load_registry()
        y = TOP + 44
        row_h = 48
        for i, entry in enumerate(self._registry):
            yy = y + i * row_h
            if yy > SCREEN_H - 120:
                break
            self.buttons.append(
                Button(SCREEN_W - 110, yy, 90, row_h - 8, "Uninstall",
                       (lambda e=entry: self._uninstall(e)), font=FONT_SM))
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _uninstall(self, entry):
        app_name = entry.get("app_name")
        file_name = entry.get("file")
        try:
            filepath = os.path.join(INSTALL_DIR, file_name)
            if os.path.exists(filepath):
                os.remove(filepath)
        except Exception:
            pass
        registry = [e for e in _load_registry() if e.get("file") != file_name]
        _save_registry(registry)
        if app_name in self.os.apps:
            del self.os.apps[app_name]
        self.os.folder_members.discard(app_name)
        self._build_apps()

    # -- developer mode ---------------------------------------------------
    def _build_developer(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 140, TOP + 110, 280, 50,
                   self._dev_label(), self._toggle_dev, font=FONT_MD),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _dev_label(self):
        return f"Developer Mode: {'On' if theme.get('developer_mode') else 'Off'}"

    def _toggle_dev(self):
        theme.set("developer_mode", not theme.get("developer_mode"))
        self._build_developer()

    # -- about ------------------------------------------------------------
    def _build_about(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 100, SCREEN_H - 140, 200, 44,
                   "Reset all settings", self._reset, font=FONT_SM),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _reset(self):
        theme.reset()
        self._build_about()

    # -- drawing ------------------------------------------------------------
    def draw(self, draw, canvas):
        titles = {"menu": "Settings", "display": "Display", "sound": "Sound",
                  "theme": "Theme", "network": "Wi-Fi & Bluetooth",
                  "security": "Security", "security_verify": "Enter Current PIN",
                  "security_setpin": "Set New PIN", "datetime": "Date & Time",
                  "apps": "Installed Apps", "developer": "Developer",
                  "about": "About"}
        draw.text((SCREEN_W // 2, TOP), titles.get(self.section, "Settings"),
                   font=FONT_LG, fill=theme.fg_color(), anchor="mm")

        if self.section == "display":
            self._draw_display(draw)
        elif self.section == "sound":
            self._draw_sound(draw)
        elif self.section == "theme":
            self._draw_theme(draw)
        elif self.section == "security_verify" or self.section == "security_setpin":
            self._draw_pin_screen(draw)
        elif self.section == "apps":
            self._draw_apps(draw)
        elif self.section == "about":
            self._draw_about(draw)

        for b in self.buttons:
            b.draw(draw)

    def _draw_display(self, draw):
        b = theme.get("brightness")
        draw.text((SCREEN_W // 2, TOP + 40), "Backlight", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        bar_x0, bar_x1 = 30, SCREEN_W - 30
        bar_y0, bar_y1 = TOP + 70, TOP + 100
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x1, bar_y1], radius=10, fill=theme.card_color())
        fill_w = int((bar_x1 - bar_x0) * b / 100)
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x0 + fill_w, bar_y1],
                                radius=10, fill=theme.accent_color())
        draw.text((SCREEN_W // 2, TOP + 157), f"{b}%", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")

        draw.text((SCREEN_W // 2, TOP + 200), "Auto-sleep after", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        current = theme.get("sleep_timeout")
        for btn, (secs, label) in zip(self.buttons[2:2 + len(SLEEP_CHOICES)], SLEEP_CHOICES):
            btn.bg = theme.accent_color() if secs == current else theme.card_color()

    def _draw_sound(self, draw):
        v = theme.get("volume")
        draw.text((SCREEN_W // 2, TOP + 40), "Volume", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        bar_x0, bar_x1 = 30, SCREEN_W - 30
        bar_y0, bar_y1 = TOP + 70, TOP + 100
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x1, bar_y1], radius=10, fill=theme.card_color())
        fill_w = int((bar_x1 - bar_x0) * v / 100)
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x0 + fill_w, bar_y1],
                                radius=10, fill=theme.accent_color())
        draw.text((SCREEN_W // 2, TOP + 157), f"{v}%", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        # keep the on/off toggle labels current
        self.buttons[2].label = self._sound_label()
        self.buttons[3].label = self._click_label()

    def _draw_theme(self, draw):
        current = theme.get("theme")
        for btn, name in zip(self.buttons, theme.PRESET_NAMES):
            palette = theme.PRESETS[name]
            swatch_x = btn.x + btn.w - 34
            draw.ellipse([swatch_x, btn.y + 12, swatch_x + 20, btn.y + 32],
                         fill=palette["accent"])
            btn.bg = theme.accent_color() if name == current else theme.card_color()

    def _draw_pin_screen(self, draw):
        n = len(self._pin_draft)
        dot_gap = 34
        x0 = SCREEN_W // 2 - dot_gap * 3 // 2
        cy = TOP + 60
        for i in range(4):
            cx = x0 + i * dot_gap
            filled = i < n
            color = theme.accent_color() if filled else theme.card_color()
            draw.ellipse([cx - 9, cy - 9, cx + 9, cy + 9], fill=color, outline=theme.fg_color())
        if self._pin_error:
            draw.text((SCREEN_W // 2, TOP + 92), self._pin_error, font=FONT_SM,
                       fill=(230, 90, 90), anchor="mm")

    def _draw_apps(self, draw):
        if not self._registry:
            draw.text((SCREEN_W // 2, TOP + 90), "No apps installed yet\n(try the App Store)",
                       font=FONT_SM, fill=(150, 150, 160), anchor="mm", align="center")
            return
        y = TOP + 44
        row_h = 48
        for i, entry in enumerate(self._registry):
            yy = y + i * row_h
            if yy > SCREEN_H - 120:
                break
            draw.text((20, yy + (row_h - 8) // 2), entry.get("app_name", "?"), font=FONT_SM,
                       fill=theme.fg_color(), anchor="lm")

    def _draw_about(self, draw):
        lines = [
            "PiOS", "",
            "A tiny touchscreen OS for the",
            "Raspberry Pi + Waveshare 3.5\"",
            "LCD and UPS HAT (C).", "",
            f"Theme: {theme.get('theme')}",
            f"Sound: {'On' if theme.get('sound_enabled') else 'Off'}",
        ]
        y = TOP + 50
        for line in lines:
            draw.text((SCREEN_W // 2, y), line, font=FONT_SM,
                      fill=theme.fg_color(), anchor="mm")
            y += 24

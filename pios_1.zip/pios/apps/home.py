from ui.framework import App, build_grid, SCREEN_W, STATUS_BAR_H, FONT_LG


class Home(App):
    name = "Home"
    icon = "\u2302"

    def on_open(self):
        names = [n for n in self.os.apps
                 if n != "Home" and n not in self.os.folder_members]
        self.buttons = build_grid(
            names, lambda n: self.os.apps[n].icon,
            lambda n: self.os.open_app(n))

    def draw(self, draw, canvas):
        draw.text((SCREEN_W // 2, STATUS_BAR_H + 20), "PiOS", font=FONT_LG,
                   fill=(255, 255, 255), anchor="mm")
        for b in self.buttons:
            b.draw(draw)

#!/usr/bin/env python3
"""PhoneOS touchscreen calibration wizard.

Taps 3 non-collinear on-screen targets, records the RAW (uncalibrated)
tap position for each, and solves for the affine transform that maps
raw touch coordinates to true screen coordinates. See core/touch.py.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import pygame
from core import config, touch, screen

W, H = config.SCREEN_W, config.SCREEN_H
TARGETS = [
    (40, 70),
    (W - 40, H // 2),
    (W // 2, H - 70),
]


class Calibration:
    def __init__(self):
        pygame.init()
        self.screen = screen.init_display("Calibrate Touch")
        self.font = pygame.font.Font(None, 20)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.running = True

        self.step = 0
        self.raw_points = []
        self.done = False
        self.error = None

    def draw_target(self, pos):
        x, y = pos
        pygame.draw.circle(self.screen, config.ACCENT_COLOR, (x, y), 18, width=2)
        pygame.draw.line(self.screen, config.ACCENT_COLOR, (x - 12, y), (x + 12, y), 2)
        pygame.draw.line(self.screen, config.ACCENT_COLOR, (x, y - 12), (x, y + 12), 2)

    def draw(self):
        self.screen.fill(config.BG_COLOR)
        if self.done:
            msg = "Calibration saved!" if not self.error else f"Failed: {self.error}"
            t = self.font.render(msg, True, config.FG_COLOR)
            self.screen.blit(t, t.get_rect(center=(W // 2, H // 2 - 20)))
            h = self.font_small.render("Tap anywhere to exit", True, (150, 150, 160))
            self.screen.blit(h, h.get_rect(center=(W // 2, H // 2 + 20)))
            return

        t = self.font.render(f"Tap target {self.step + 1} of {len(TARGETS)}", True, config.FG_COLOR)
        self.screen.blit(t, (16, 30))
        h = self.font_small.render("Tap precisely on the crosshair center", True, (150, 150, 160))
        self.screen.blit(h, (16, 56))
        self.draw_target(TARGETS[self.step])

    def handle_tap(self, raw_pos):
        if self.done:
            self.running = False
            return
        self.raw_points.append(raw_pos)
        self.step += 1
        if self.step >= len(TARGETS):
            try:
                coeffs = touch.compute_affine(self.raw_points, TARGETS)
                touch.save_calibration(coeffs)
            except ValueError as e:
                self.error = str(e)
            self.done = True

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    # Intentionally raw: calibrating IS computing the
                    # correction, so we must not apply it here.
                    self.handle_tap(touch.raw_pos(event))
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            self.draw()
            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    Calibration().run()

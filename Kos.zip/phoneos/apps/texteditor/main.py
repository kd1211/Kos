#!/usr/bin/env python3
"""PhoneOS Text Editor.

Usage: main.py [path/to/file.txt]
If no path is given, opens a blank untitled document; Save prompts for
a filename in /phoneos/user/.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import pygame
from core import config, touch, screen
from core.keyboard import OnScreenKeyboard

W, H = config.SCREEN_W, config.SCREEN_H
LINE_H = 18


class TextEditor:
    def __init__(self, path=None):
        pygame.init()
        self.screen = screen.init_display("Text Editor")
        self.font = pygame.font.Font(None, 18)
        self.clock = pygame.time.Clock()
        self.running = True

        self.path = path
        self.text = ""
        self.dirty = False
        if path and os.path.isfile(path):
            try:
                with open(path, "r", errors="replace") as f:
                    self.text = f.read()
            except OSError:
                self.text = ""

        self.kb = OnScreenKeyboard(W, H)
        self.show_kb = True
        self.saving_as = False
        self.filename_input = os.path.basename(path) if path else ""
        self.status = ""

    def title(self):
        name = os.path.basename(self.path) if self.path else "untitled.txt"
        return name + (" *" if self.dirty else "")

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(self.title()[:28], True, config.FG_COLOR)
        self.screen.blit(t, (40, 8))
        self.save_rect = pygame.Rect(W - 60, 0, 60, 36)
        s = self.font.render("Save", True, config.ACCENT_COLOR)
        self.screen.blit(s, (W - 54, 8))

    def draw_body(self):
        avail_h = self.kb.top - 40 if self.show_kb else H - 40
        visible_lines = max(1, avail_h // LINE_H)
        lines = self.text.split("\n")[-visible_lines:]
        y = 40
        for line in lines:
            t = self.font.render(line[:52], True, config.FG_COLOR)
            self.screen.blit(t, (6, y))
            y += LINE_H
        if self.status:
            st = self.font.render(self.status, True, (150, 220, 150))
            self.screen.blit(st, (6, H - 20 if not self.show_kb else self.kb.top - 20))

    def draw_save_as(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header()
        box = pygame.Rect(10, 44, W - 20, 34)
        pygame.draw.rect(self.screen, (24, 24, 30), box, border_radius=6)
        t = self.font.render(self.filename_input or "filename.txt", True, config.FG_COLOR)
        self.screen.blit(t, (box.x + 8, box.y + 6))
        hint = self.font.render("Enter filename, tap enter to save", True, (150, 150, 160))
        self.screen.blit(hint, (10, 86))
        self.kb.draw(self.screen)

    def save(self):
        if not self.path:
            self.saving_as = True
            return
        try:
            with open(self.path, "w") as f:
                f.write(self.text)
            self.dirty = False
            self.status = "Saved"
        except OSError as e:
            self.status = f"Save failed: {e}"

    def finish_save_as(self):
        name = self.filename_input.strip()
        if not name:
            return
        if not any(name.endswith(ext) for ext in (".txt", ".md", ".json", ".py", ".log")):
            name += ".txt"
        self.path = os.path.join(config.USER_DIR, name)
        os.makedirs(config.USER_DIR, exist_ok=True)
        self.saving_as = False
        self.save()

    def handle_kb_result(self, result):
        if result is None or result == "SHIFT":
            return
        if self.saving_as:
            if result == "SPACE":
                self.filename_input += " "
            elif result == "BACKSPACE":
                self.filename_input = self.filename_input[:-1]
            elif result == "ENTER":
                self.finish_save_as()
            else:
                self.filename_input += result
            return
        if result == "SPACE":
            self.text += " "
        elif result == "BACKSPACE":
            self.text = self.text[:-1]
        elif result == "ENTER":
            self.text += "\n"
        else:
            self.text += result
        self.dirty = True
        self.status = ""

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.saving_as:
                        if self.back_rect.collidepoint(pos):
                            self.saving_as = False
                        else:
                            self.handle_kb_result(self.kb.handle_tap(pos))
                    else:
                        if self.back_rect.collidepoint(pos):
                            self.running = False
                        elif self.save_rect.collidepoint(pos):
                            self.save()
                        else:
                            self.handle_kb_result(self.kb.handle_tap(pos))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key == pygame.K_RETURN:
                        self.handle_kb_result("ENTER")
                    elif event.key == pygame.K_BACKSPACE:
                        self.handle_kb_result("BACKSPACE")
                    elif event.unicode:
                        self.handle_kb_result(event.unicode)

            if self.saving_as:
                self.draw_save_as()
            else:
                self.screen.fill(config.BG_COLOR)
                self.draw_header()
                self.draw_body()
                if self.show_kb:
                    self.kb.draw(self.screen)

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    arg_path = sys.argv[1] if len(sys.argv) > 1 else None
    TextEditor(arg_path).run()

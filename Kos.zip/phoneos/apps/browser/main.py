#!/usr/bin/env python3
"""PhoneOS Browser.

A lightweight browser: fetches pages over HTTP(S) and renders them as
scrollable text with tappable links. No CSS/JS/images/layout -- a real
HTML5 engine isn't realistic on a Pi Zero, so this gives the "basic
HTML5 support" the spec asks for in the only form that's honest about
the hardware: readable text and working links.
"""
import sys
import os
import json
import threading
import urllib.request
import urllib.error
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import pygame
from core import config, htmlrender, touch, screen
from core.keyboard import OnScreenKeyboard

W, H = config.SCREEN_W, config.SCREEN_H
LINE_H = 18
TIMEOUT = 10
USER_AGENT = "PhoneOS-Browser/1.0"
BOOKMARKS_FILE = os.path.join(config.SYSTEM_DIR, "bookmarks.json")
URL_SYMBOLS = "./:-_~?=&#"


def load_bookmarks():
    if not os.path.isfile(BOOKMARKS_FILE):
        return []
    try:
        with open(BOOKMARKS_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def save_bookmarks(bookmarks):
    os.makedirs(config.SYSTEM_DIR, exist_ok=True)
    with open(BOOKMARKS_FILE, "w") as f:
        json.dump(bookmarks, f, indent=2)


class Tab:
    def __init__(self, url=None):
        self.url = url
        self.blocks = []
        self.title = "New Tab"
        self.scroll = 0
        self.history = []
        self.forward_stack = []
        self.loading = False
        self.error = None


class Browser:
    def __init__(self):
        pygame.init()
        self.screen = screen.init_display("Browser")
        self.font = pygame.font.Font(None, 18)
        self.font_small = pygame.font.Font(None, 15)
        self.font_head = pygame.font.Font(None, 22)
        self.clock = pygame.time.Clock()
        self.running = True

        self.tabs = [Tab()]
        self.active_tab = 0
        self.mode = "page"  # page | address | bookmarks | tabs
        self.address_input = ""
        self.kb = OnScreenKeyboard(W, H, extra_row=URL_SYMBOLS)
        self.bookmarks = load_bookmarks()
        self.status = ""

    @property
    def tab(self):
        return self.tabs[self.active_tab]

    # -------------------------------------------------------------- net
    def navigate(self, url, record_history=True):
        if not url:
            return
        if "://" not in url:
            url = "https://" + url
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ("http", "https"):
            self.status = "Only http/https URLs are supported"
            return

        tab = self.tab
        if record_history and tab.url:
            tab.history.append(tab.url)
            tab.forward_stack.clear()
        tab.url = url
        tab.loading = True
        tab.error = None
        self.mode = "page"

        def worker():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                    content_type = resp.headers.get("Content-Type", "")
                    data = resp.read(2_000_000)  # cap for Pi Zero memory
                if "text/html" in content_type or content_type == "":
                    raw = data.decode("utf-8", errors="replace")
                    tab.blocks = htmlrender.extract_blocks(raw, url)
                    tab.title = htmlrender.extract_title(raw) or url
                else:
                    self._save_download(url, data)
                    tab.blocks = [{"text": f"Downloaded to /phoneos/downloads", "href": None, "heading": False}]
                    tab.title = url
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as e:
                tab.error = str(e)
                tab.blocks = []
            finally:
                tab.loading = False
                tab.scroll = 0

        threading.Thread(target=worker, daemon=True).start()

    def _save_download(self, url, data):
        os.makedirs(config.DOWNLOADS_DIR, exist_ok=True)
        name = os.path.basename(urllib.parse.urlparse(url).path) or "download"
        with open(os.path.join(config.DOWNLOADS_DIR, name), "wb") as f:
            f.write(data)

    def go_back(self):
        tab = self.tab
        if tab.history:
            tab.forward_stack.append(tab.url)
            prev = tab.history.pop()
            self.navigate(prev, record_history=False)

    def go_forward(self):
        tab = self.tab
        if tab.forward_stack:
            nxt = tab.forward_stack.pop()
            tab.history.append(tab.url)
            self.navigate(nxt, record_history=False)

    # ------------------------------------------------------------- draw
    def draw_toolbar(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        self.back_rect = pygame.Rect(0, 0, 30, 36)
        self.fwd_rect = pygame.Rect(30, 0, 30, 36)
        self.screen.blit(self.font.render("<", True, config.FG_COLOR), (8, 8))
        self.screen.blit(self.font.render(">", True, config.FG_COLOR), (38, 8))

        self.addr_rect = pygame.Rect(64, 4, W - 64 - 66, 28)
        pygame.draw.rect(self.screen, (26, 26, 32), self.addr_rect, border_radius=6)
        label = self.tab.url or "Enter address..."
        t = self.font_small.render(label[:34], True, config.FG_COLOR)
        self.screen.blit(t, (self.addr_rect.x + 6, self.addr_rect.y + 7))

        self.bookmark_rect = pygame.Rect(W - 66, 0, 33, 36)
        self.tabs_rect = pygame.Rect(W - 33, 0, 33, 36)
        star = "*" if any(b["url"] == self.tab.url for b in self.bookmarks) else "+"
        self.screen.blit(self.font.render(star, True, config.ACCENT_COLOR), (W - 58, 8))
        self.screen.blit(self.font_small.render(f"{len(self.tabs)}", True, config.ACCENT_COLOR), (W - 26, 10))

    def draw_page(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_toolbar()
        tab = self.tab
        y = 40 - tab.scroll
        self.link_rects = []
        if tab.loading:
            t = self.font.render("Loading...", True, (150, 150, 160))
            self.screen.blit(t, (10, 50))
            return
        if tab.error:
            t = self.font.render(f"Error: {tab.error}", True, (220, 100, 100))
            self.screen.blit(t, (10, 50))
            return
        for block in tab.blocks:
            color = (255, 255, 255) if block["heading"] else config.FG_COLOR
            if block["href"]:
                color = (110, 170, 255)
            font = self.font_head if block["heading"] else self.font
            wrapped = self._wrap(block["text"], font, W - 16)
            for line in wrapped:
                if 40 <= y <= H:
                    surf = font.render(line, True, color)
                    self.screen.blit(surf, (8, y))
                    if block["href"]:
                        self.link_rects.append((pygame.Rect(8, y, surf.get_width(), LINE_H), block["href"]))
                y += LINE_H if not block["heading"] else LINE_H + 4
        self.max_scroll = max(0, y + tab.scroll - H)

    def _wrap(self, text, font, max_w):
        words = text.split(" ")
        lines, cur = [], ""
        for w in words:
            trial = (cur + " " + w).strip()
            if font.size(trial)[0] <= max_w:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines or [""]

    def draw_address_bar(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_toolbar()
        box = pygame.Rect(6, 44, W - 12, 32)
        pygame.draw.rect(self.screen, (26, 26, 32), box, border_radius=6)
        t = self.font.render(self.address_input or "https://", True, config.FG_COLOR)
        self.screen.blit(t, (box.x + 6, box.y + 6))
        self.kb.draw(self.screen)

    def draw_bookmarks(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Bookmarks")
        self.bm_rects = []
        y = 44
        for bm in self.bookmarks:
            rect = pygame.Rect(6, y, W - 12, 36)
            pygame.draw.rect(self.screen, (24, 24, 30), rect, border_radius=6)
            t = self.font_small.render(bm["url"][:40], True, config.FG_COLOR)
            self.screen.blit(t, (rect.x + 8, rect.y + 10))
            self.bm_rects.append((rect, bm["url"]))
            y += 40

    def draw_tabs_view(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Tabs")
        self.tab_rects = []
        y = 44
        for i, t in enumerate(self.tabs):
            rect = pygame.Rect(6, y, W - 50, 36)
            pygame.draw.rect(self.screen, (24, 24, 30), rect, border_radius=6)
            label = t.url or "New Tab"
            surf = self.font_small.render(label[:38], True, config.FG_COLOR)
            self.screen.blit(surf, (rect.x + 8, rect.y + 10))
            close_rect = pygame.Rect(W - 40, y, 34, 36)
            pygame.draw.rect(self.screen, (60, 30, 30), close_rect, border_radius=6)
            self.screen.blit(self.font_small.render("x", True, (255, 150, 150)), (close_rect.x + 12, close_rect.y + 10))
            self.tab_rects.append((rect, close_rect, i))
            y += 40
        self.new_tab_rect = pygame.Rect(6, y, W - 12, 36)
        pygame.draw.rect(self.screen, (30, 50, 70), self.new_tab_rect, border_radius=6)
        self.screen.blit(self.font.render("+ New Tab", True, config.ACCENT_COLOR), (14, y + 8))
        y += 44
        self.bookmarks_btn_rect = pygame.Rect(6, y, W - 12, 36)
        pygame.draw.rect(self.screen, (40, 40, 48), self.bookmarks_btn_rect, border_radius=6)
        self.screen.blit(self.font.render(f"Bookmarks ({len(self.bookmarks)})", True, config.FG_COLOR), (14, y + 8))

    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_to_page_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 8))

    # ------------------------------------------------------------ input
    def handle_page_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            self.go_back()
        elif self.fwd_rect.collidepoint(pos):
            self.go_forward()
        elif self.addr_rect.collidepoint(pos):
            self.address_input = self.tab.url or ""
            self.mode = "address"
        elif self.bookmark_rect.collidepoint(pos):
            if self.tab.url:
                if any(b["url"] == self.tab.url for b in self.bookmarks):
                    self.bookmarks = [b for b in self.bookmarks if b["url"] != self.tab.url]
                else:
                    self.bookmarks.append({"url": self.tab.url, "title": self.tab.title})
                save_bookmarks(self.bookmarks)
        elif self.tabs_rect.collidepoint(pos):
            self.mode = "tabs"
        else:
            for rect, href in getattr(self, "link_rects", []):
                if rect.collidepoint(pos):
                    self.navigate(href)
                    return

    def handle_address_kb(self, result):
        if result is None or result == "SHIFT":
            return
        if result == "SPACE":
            pass
        elif result == "BACKSPACE":
            self.address_input = self.address_input[:-1]
        elif result == "ENTER":
            self.navigate(self.address_input)
        else:
            self.address_input += result

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.mode == "page":
                        self.handle_page_tap(pos)
                    elif self.mode == "address":
                        if self.back_rect.collidepoint(pos) or self.fwd_rect.collidepoint(pos):
                            self.mode = "page"
                        else:
                            self.handle_address_kb(self.kb.handle_tap(pos))
                    elif self.mode == "bookmarks":
                        if self.back_to_page_rect.collidepoint(pos):
                            self.mode = "page"
                        else:
                            for rect, url in self.bm_rects:
                                if rect.collidepoint(pos):
                                    self.navigate(url)
                                    break
                    elif self.mode == "tabs":
                        if self.back_to_page_rect.collidepoint(pos):
                            self.mode = "page"
                        elif self.new_tab_rect.collidepoint(pos):
                            self.tabs.append(Tab())
                            self.active_tab = len(self.tabs) - 1
                            self.mode = "address"
                            self.address_input = ""
                        elif self.bookmarks_btn_rect.collidepoint(pos):
                            self.mode = "bookmarks"
                        else:
                            for rect, close_rect, i in self.tab_rects:
                                if close_rect.collidepoint(pos):
                                    if len(self.tabs) > 1:
                                        self.tabs.pop(i)
                                        self.active_tab = min(self.active_tab, len(self.tabs) - 1)
                                    break
                                if rect.collidepoint(pos):
                                    self.active_tab = i
                                    self.mode = "page"
                                    break
                elif event.type == pygame.MOUSEWHEEL and self.mode == "page":
                    self.tab.scroll = max(0, min(getattr(self, "max_scroll", 0), self.tab.scroll - event.y * 30))
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.mode != "page":
                        self.mode = "page"
                    else:
                        self.running = False

            if self.mode == "page":
                self.draw_page()
            elif self.mode == "address":
                self.draw_address_bar()
            elif self.mode == "bookmarks":
                self.draw_bookmarks()
            elif self.mode == "tabs":
                self.draw_tabs_view()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    b = Browser()
    if len(sys.argv) > 1:
        b.navigate(sys.argv[1])
    b.run()

#!/usr/bin/env python3
"""PhoneOS Paint. Draw with your finger/mouse, save to Gallery."""
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import pygame
from core import config, touch, screen, dialog
from core.toast import Toast

W, H = config.SCREEN_W, config.SCREEN_H
HEADER_H = 36
COLOR_ROW_H = 34
TOOL_ROW_H = 40
CANVAS_TOP = HEADER_H + COLOR_ROW_H + TOOL_ROW_H

COLORS = [
    (20, 20, 24), (255, 255, 255), (220, 60, 60), (240, 140, 40),
    (240, 210, 60), (70, 180, 90), (60, 130, 220), (150, 80, 200),
]
BRUSH_SIZES = [3, 8, 16]
PICTURES_DIR = os.path.join(config.USER_DIR, "pictures")


class Paint:
    def __init__(self):
        pygame.init()
        self.screen = screen.init_display("Paint")
        self.font = pygame.font.Font(None, 20)
        self.font_small = pygame.font.Font(None, 15)
        self.clock = pygame.time.Clock()
        self.running = True
        self.toast = Toast()

        self.canvas = pygame.Surface((W, H - CANVAS_TOP))
        self.canvas.fill((255, 255, 255))
        self.undo_buffer = None

        self.current_color = COLORS[0]
        self.brush_size = BRUSH_SIZES[1]
        self.erasing = False
        self.drawing = False
        self.last_pos = None

        self._build_ui()

    def _build_ui(self):
        self.color_rects = []
        swatch_w = W // len(COLORS)
        for i, color in enumerate(COLORS):
            rect = pygame.Rect(i * swatch_w, HEADER_H, swatch_w, COLOR_ROW_H)
            self.color_rects.append((rect, color))

        tool_y = HEADER_H + COLOR_ROW_H
        labels = ["S", "M", "L", "Erase", "Undo", "Clear", "Save"]
        tool_w = W // len(labels)
        self.tool_rects = []
        for i, label in enumerate(labels):
            rect = pygame.Rect(i * tool_w, tool_y, tool_w, TOOL_ROW_H)
            self.tool_rects.append((rect, label))

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, HEADER_H))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font_small.render("Paint", True, config.FG_COLOR)
        self.screen.blit(t, (44, 10))

    def draw_color_row(self):
        for rect, color in self.color_rects:
            pygame.draw.rect(self.screen, color, rect)
            if not self.erasing and color == self.current_color:
                pygame.draw.rect(self.screen, config.ACCENT_COLOR, rect, width=3)
        pygame.draw.line(self.screen, (10, 10, 12), (0, HEADER_H + COLOR_ROW_H), (W, HEADER_H + COLOR_ROW_H), 1)

    def draw_tool_row(self):
        for rect, label in self.tool_rects:
            active = (
                (label == "S" and self.brush_size == BRUSH_SIZES[0] and not self.erasing)
                or (label == "M" and self.brush_size == BRUSH_SIZES[1] and not self.erasing)
                or (label == "L" and self.brush_size == BRUSH_SIZES[2] and not self.erasing)
                or (label == "Erase" and self.erasing)
            )
            bg = (55, 55, 65) if active else (35, 35, 42)
            pygame.draw.rect(self.screen, bg, rect.inflate(-2, -2), border_radius=6)
            if label in ("S", "M", "L"):
                radius = {"S": 3, "M": 6, "L": 9}[label]
                pygame.draw.circle(self.screen, config.FG_COLOR, rect.center, radius)
            else:
                t = self.font_small.render(label, True, config.FG_COLOR)
                self.screen.blit(t, t.get_rect(center=rect.center))

    def draw_canvas(self):
        self.screen.blit(self.canvas, (0, CANVAS_TOP))

    def _save_undo_snapshot(self):
        self.undo_buffer = self.canvas.copy()

    def _stroke(self, pos):
        x, y = pos[0], pos[1] - CANVAS_TOP
        color = (255, 255, 255) if self.erasing else self.current_color
        if self.last_pos is not None:
            pygame.draw.line(self.canvas, color, self.last_pos, (x, y), self.brush_size * 2)
        pygame.draw.circle(self.canvas, color, (x, y), self.brush_size)
        self.last_pos = (x, y)

    def handle_tool_tap(self, label):
        if label == "S":
            self.brush_size, self.erasing = BRUSH_SIZES[0], False
        elif label == "M":
            self.brush_size, self.erasing = BRUSH_SIZES[1], False
        elif label == "L":
            self.brush_size, self.erasing = BRUSH_SIZES[2], False
        elif label == "Erase":
            self.erasing = True
        elif label == "Undo":
            if self.undo_buffer is not None:
                self.canvas = self.undo_buffer
                self.undo_buffer = None
        elif label == "Clear":
            if dialog.confirm(self.screen, "Clear canvas?", "This can't be undone.", confirm_label="Clear"):
                self._save_undo_snapshot()
                self.canvas.fill((255, 255, 255))
        elif label == "Save":
            self._save()

    def _save(self):
        os.makedirs(PICTURES_DIR, exist_ok=True)
        filename = f"paint_{time.strftime('%Y%m%d_%H%M%S')}.png"
        path = os.path.join(PICTURES_DIR, filename)
        try:
            pygame.image.save(self.canvas, path)
            self.toast.show(f"Saved to Gallery: {filename}")
        except (pygame.error, OSError) as e:
            self.toast.show(f"Save failed: {e}", color=(255, 140, 140))

    def handle_tap_down(self, pos):
        if self.back_rect.collidepoint(pos):
            self.running = False
            return
        for rect, color in self.color_rects:
            if rect.collidepoint(pos):
                self.current_color = color
                self.erasing = False
                return
        for rect, label in self.tool_rects:
            if rect.collidepoint(pos):
                self.handle_tool_tap(label)
                return
        if pos[1] >= CANVAS_TOP:
            self._save_undo_snapshot()
            self.drawing = True
            self.last_pos = None
            self._stroke(pos)

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    self.handle_tap_down(touch.get_pos(event))
                elif event.type in (pygame.MOUSEMOTION, pygame.FINGERMOTION):
                    if self.drawing:
                        self._stroke(touch.get_pos(event))
                elif event.type in (pygame.MOUSEBUTTONUP, pygame.FINGERUP):
                    self.drawing = False
                    self.last_pos = None
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            self.screen.fill(config.BG_COLOR)
            self.draw_header()
            self.draw_color_row()
            self.draw_tool_row()
            self.draw_canvas()
            self.toast.draw(self.screen, self.font_small)

            pygame.display.flip()
            self.clock.tick(60)
        pygame.quit()


if __name__ == "__main__":
    Paint().run()

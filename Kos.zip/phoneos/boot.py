#!/usr/bin/env python3
"""PhoneOS entry point. Run this on boot (see phoneos.service)."""
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

REQUIRED_DIRS = [
    "core", "system", "apps", "packages", "cache",
    "downloads", "themes", "wallpapers", "user", "logs",
]


def ensure_dirs():
    for d in REQUIRED_DIRS:
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)


def main():
    ensure_dirs()
    from core import settings, display
    try:
        display.set_brightness_percent(settings.load().get("brightness", 100))
    except Exception:  # noqa: BLE001 - brightness is a nice-to-have, never block boot
        pass
    from core import launcher
    launcher.main()


if __name__ == "__main__":
    main()

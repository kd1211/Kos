#!/usr/bin/env python3
"""PhoneOS Launcher.

Boots into a touch-friendly home screen. Apps run as separate processes;
the launcher tears down its own display before starting one and only
draws again once it exits, guaranteeing a single foreground app.
"""
import os
import sys
import time
import subprocess
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame

from core import config, app_manager, battery, netstatus, settings, touch, lock, imaging, screen
from core.toast import Toast
from core.numpad import NumPad

logging.basicConfig(
    filename=os.path.join(config.LOGS_DIR, "launcher.log")
    if os.path.isdir(config.LOGS_DIR)
    else None,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("phoneos.launcher")


class Launcher:
    def __init__(self):
        os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
        pygame.init()
        pygame.mouse.set_visible(False)
        self.settings = settings.load()
        self._init_display()
        self.clock = pygame.time.Clock()
        self.font_small = pygame.font.Font(None, 18)
        self.font_med = pygame.font.Font(None, 22)
        self.font_large = pygame.font.Font(None, 30)

        self.apps = app_manager.load_db()
        self.page = 0
        self.page_count = max(1, -(-len(self.apps) // config.APPS_PER_PAGE))

        self._last_status_poll = 0
        self._battery = battery.read()
        self._wifi = netstatus.wifi_status()
        self._bt = netstatus.bluetooth_status()

        self._icon_cache = {}
        self.running = True

        self.toast = Toast(duration=3.0)
        self._ripples = []  # list of (x, y, start_time)
        self._last_input_time = time.time()
        self._sleeping = False
        self._low_battery_warned = False

        self.numpad = NumPad(config.SCREEN_W, config.SCREEN_H)
        self._pin_input = ""
        self._pin_error = False
        self._locked = lock.is_enabled()

    def _init_display(self):
        self.screen = screen.init_display("PhoneOS")

    # ---------------------------------------------------------- rendering
    def _get_icon(self, app):
        if app["id"] in self._icon_cache:
            return self._icon_cache[app["id"]]
        surf = None
        if app.get("icon"):
            surf = imaging.load(app["icon"], size=(config.ICON_SIZE, config.ICON_SIZE), fit="contain")
        if surf is None:
            surf = pygame.Surface((config.ICON_SIZE, config.ICON_SIZE))
            surf.fill(config.ACCENT_COLOR)
            label = self.font_large.render(app["name"][:1].upper(), True, (255, 255, 255))
            rect = label.get_rect(center=(config.ICON_SIZE // 2, config.ICON_SIZE // 2))
            surf.blit(label, rect)
        self._icon_cache[app["id"]] = surf
        return surf

    def _draw_statusbar(self):
        bar = pygame.Rect(0, 0, config.SCREEN_W, config.STATUSBAR_H)
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, bar)

        time_str = time.strftime("%H:%M")
        t_surf = self.font_small.render(time_str, True, config.FG_COLOR)
        self.screen.blit(t_surf, (8, 6))

        connected, ssid = self._wifi
        wifi_color = config.ACCENT_COLOR if connected else (90, 90, 90)
        wifi_label = "WiFi" if connected else "--"
        w_surf = self.font_small.render(wifi_label, True, wifi_color)
        self.screen.blit(w_surf, (config.SCREEN_W - 140, 6))

        bt_color = config.ACCENT_COLOR if self._bt else (90, 90, 90)
        bt_surf = self.font_small.render("BT", True, bt_color)
        self.screen.blit(bt_surf, (config.SCREEN_W - 90, 6))

        pct = self._battery["percent"]
        pct_str = f"{pct}%" if pct >= 0 else "?"
        if self._battery["charging"]:
            pct_str += " +"
        b_surf = self.font_small.render(pct_str, True, config.FG_COLOR)
        self.screen.blit(b_surf, (config.SCREEN_W - 48, 6))

    def _icon_rects(self):
        """Yield (rect, app) for icons on the current page."""
        start = self.page * config.APPS_PER_PAGE
        page_apps = self.apps[start:start + config.APPS_PER_PAGE]

        margin_x = 20
        margin_y = 20
        cell_w = (config.SCREEN_W - 2 * margin_x) // config.COLS
        cell_h = 100

        top = config.STATUSBAR_H + margin_y
        for i, app in enumerate(page_apps):
            col = i % config.COLS
            row = i // config.COLS
            cx = margin_x + col * cell_w + cell_w // 2
            cy = top + row * cell_h + config.ICON_SIZE // 2
            rect = pygame.Rect(0, 0, config.ICON_SIZE, config.ICON_SIZE)
            rect.center = (cx, cy)
            yield rect, app, (cx, cy)

    def _draw_lock_screen(self):
        self.screen.fill((10, 10, 14))
        t_surf = self.font_large.render(time.strftime("%H:%M"), True, config.FG_COLOR)
        self.screen.blit(t_surf, t_surf.get_rect(center=(config.SCREEN_W // 2, 70)))

        label = self.font_small.render("Enter PIN", True, (150, 150, 160))
        self.screen.blit(label, label.get_rect(center=(config.SCREEN_W // 2, 110)))

        dot_color = (220, 90, 90) if self._pin_error else config.ACCENT_COLOR
        total_w = max(1, len(self._pin_input)) * 22
        start_x = config.SCREEN_W // 2 - (len(self._pin_input) * 22) // 2 if self._pin_input else config.SCREEN_W // 2
        for i in range(len(self._pin_input)):
            pygame.draw.circle(self.screen, dot_color, (start_x + i * 22 + 11, 150), 7)

        self.numpad.draw(self.screen)

    def _handle_lock_tap(self, pos):
        key = self.numpad.handle_tap(pos)
        if key is None:
            return
        if key == "DEL":
            self._pin_input = self._pin_input[:-1]
            self._pin_error = False
        elif key == "OK":
            if lock.verify_pin(self._pin_input):
                self._locked = False
                self._pin_input = ""
                self._pin_error = False
                self._last_input_time = time.time()
            else:
                self._pin_error = True
                self._pin_input = ""
        else:  # digit
            if len(self._pin_input) < lock.MAX_PIN_LEN:
                self._pin_input += key
                self._pin_error = False

    def _draw_ripples(self):
        now = time.time()
        alive = []
        for x, y, start in self._ripples:
            age = now - start
            if age > 0.35:
                continue
            alive.append((x, y, start))
            radius = int(8 + age * 90)
            alpha = max(0, int(160 * (1 - age / 0.35)))
            surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (255, 255, 255, alpha), (radius, radius), radius, width=3)
            self.screen.blit(surf, (x - radius, y - radius))
        self._ripples = alive

    def _draw_sleep(self):
        self.screen.fill((0, 0, 0))
        t_surf = self.font_small.render(time.strftime("%H:%M"), True, (90, 90, 90))
        self.screen.blit(t_surf, t_surf.get_rect(center=(config.SCREEN_W // 2, config.SCREEN_H // 2)))

    def _check_battery_warning(self):
        pct = self._battery["percent"]
        if pct < 0:
            return
        if pct <= 15 and not self._battery["charging"]:
            if not self._low_battery_warned:
                self.toast.show(f"Battery low: {pct}%", color=(255, 150, 90))
                self._low_battery_warned = True
        elif pct > 25 or self._battery["charging"]:
            self._low_battery_warned = False

    def _draw_home(self):
        self.screen.fill(config.BG_COLOR)
        for rect, app, (cx, cy) in self._icon_rects():
            icon = self._get_icon(app)
            self.screen.blit(icon, rect)
            label = self.font_small.render(app["name"], True, config.FG_COLOR)
            lrect = label.get_rect(center=(cx, cy + config.ICON_SIZE // 2 + 12))
            self.screen.blit(label, lrect)

        if self.page_count > 1:
            dots = ""
            for i in range(self.page_count):
                dots += "●" if i == self.page else "○"
            d_surf = self.font_small.render(dots, True, config.FG_COLOR)
            drect = d_surf.get_rect(midbottom=(config.SCREEN_W // 2, config.SCREEN_H - 8))
            self.screen.blit(d_surf, drect)

        self._draw_statusbar()
        self._draw_ripples()
        self.toast.draw(self.screen, self.font_small)

    # ------------------------------------------------------------- events
    def _poll_status(self):
        now = time.time()
        if now - self._last_status_poll > 5:
            self._battery = battery.read()
            self._wifi = netstatus.wifi_status()
            self._bt = netstatus.bluetooth_status()
            self._last_status_poll = now
            self._check_battery_warning()

    def _handle_tap(self, pos):
        for rect, app, _ in self._icon_rects():
            if rect.collidepoint(pos):
                self.launch_app(app)
                return
        # swipe zones: left/right thirds of screen tap to change page
        if self.page_count > 1:
            if pos[0] < config.SCREEN_W // 4:
                self.page = (self.page - 1) % self.page_count
            elif pos[0] > config.SCREEN_W - config.SCREEN_W // 4:
                self.page = (self.page + 1) % self.page_count

    def launch_app(self, app):
        log.info("Launching %s", app["id"])
        pygame.display.quit()
        pygame.mouse.set_visible(True)
        try:
            env = os.environ.copy()
            subprocess.run([sys.executable, app["entry"]], cwd=app["path"], env=env)
        except Exception as e:  # noqa: BLE001
            log.error("App %s crashed: %s", app["id"], e)
        pygame.display.init()
        pygame.mouse.set_visible(False)
        self._init_display()
        # apps may have changed settings/apps list
        self.settings = settings.load()
        self._last_input_time = time.time()
        self._sleeping = False

    def run(self):
        while self.running:
            woke_this_frame = False
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    self._last_input_time = time.time()
                    if self._locked:
                        self._handle_lock_tap(pos)
                    elif self._sleeping:
                        self._sleeping = False
                        woke_this_frame = True
                        if lock.is_enabled() and lock.lock_on_wake_enabled():
                            self._locked = True
                    else:
                        self._ripples.append((pos[0], pos[1], time.time()))
                        self._handle_tap(pos)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if not self._locked:
                        self.running = False

            timeout = self.settings.get("screen_timeout_sec", 60)
            if not woke_this_frame and timeout and not self._sleeping and not self._locked:
                if time.time() - self._last_input_time > timeout:
                    self._sleeping = True

            self._poll_status()
            if self._locked:
                self._draw_lock_screen()
            elif self._sleeping:
                self._draw_sleep()
            else:
                self._draw_home()
            pygame.display.flip()
            self.clock.tick(config.FPS)

        pygame.quit()


def main():
    os.makedirs(config.LOGS_DIR, exist_ok=True) if os.path.isdir(config.ROOT) else None
    app_manager.rebuild_db()
    Launcher().run()


if __name__ == "__main__":
    main()

"""Robust pygame display initialization.

Different setups need different SDL video drivers: KMS/DRM without full
EGL support, an SSH session competing with an active getty for DRM
master, older Raspberry Pi OS with only legacy fbdev, or a plain
desktop dev environment. Rather than assume one and crash (as a bare
pygame.display.set_mode() call does), try several in order and use
whichever actually works. Every app should get its screen via
init_display() instead of calling pygame.display.set_mode() itself.
"""
import os
import logging

import pygame

from core import config

log = logging.getLogger("phoneos.screen")

# "" means "leave SDL_VIDEODRIVER as whatever it already is (or let SDL
# auto-detect if unset)" -- always tried first so an explicit correct
# setting (e.g. from phoneos.service) is respected before we override it.
_DRIVER_FALLBACKS = ["", "fbcon", "kmsdrm", "x11", "wayland", "dummy"]

# Once a driver is found to work in this process, later calls (e.g. an
# app relaunching the display after another app handed control back)
# go straight to it instead of re-probing every option.
_working_driver = None


def init_display(caption="PhoneOS"):
    """Initializes pygame video (if needed) and returns a working
    display Surface at config.SCREEN_W x config.SCREEN_H."""
    global _working_driver
    if not pygame.get_init():
        pygame.init()

    drivers = [_working_driver] if _working_driver is not None else _DRIVER_FALLBACKS
    last_error = None
    for driver in drivers:
        try:
            if driver:
                os.environ["SDL_VIDEODRIVER"] = driver
            pygame.display.quit()
            pygame.display.init()
            screen = pygame.display.set_mode((config.SCREEN_W, config.SCREEN_H))
            pygame.display.set_caption(caption)
            if driver != _working_driver:
                log.info("Display using SDL driver: %s", driver or "(default)")
            _working_driver = driver
            return screen
        except pygame.error as e:
            last_error = e
            log.warning("SDL video driver %r failed: %s", driver or "(default)", e)

    # Every fallback including "dummy" failed -- something is very wrong
    # (dummy has no real hardware dependency and essentially always works).
    log.critical("No working SDL video driver found: %s", last_error)
    raise last_error


def quit_display():
    pygame.display.quit()

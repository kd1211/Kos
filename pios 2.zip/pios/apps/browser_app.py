import re
import textwrap
from html.parser import HTMLParser
from ui.framework import App, Button, Keyboard, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_SM, FONT_MD, FONT_LG, CARD_COLOR, ACCENT, FG_COLOR

BOOKMARKS = [
    ("Example.com", "https://example.com"),
    ("Anthropic", "https://www.anthropic.com"),
    ("Wikipedia (random)", "https://en.wikipedia.org/wiki/Special:Random"),
    ("Hacker News", "https://news.ycombinator.com"),
]

LINES_PER_PAGE = 15
CHARS_PER_LINE = 38
KEYBOARD_H = 188
MAX_URL_LEN = 60


class _TextExtractor(HTMLParser):
    """Very small HTML-to-text stripper: skips script/style, keeps the rest."""

    def __init__(self):
        super().__init__()
        self.chunks = []
        self._skip = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip = True

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._skip = False

    def handle_data(self, data):
        if not self._skip:
            text = data.strip()
            if text:
                self.chunks.append(text)

    def get_text(self):
        return "\n".join(self.chunks)


class BrowserApp(App):
    name = "Browser"
    icon = "\U0001F310"

    def on_open(self):
        self.state = "bookmarks"
        self.pages = []
        self.page_index = 0
        self.current_title = None
        self.status = None
        self.keyboard = None
        self.draft_url = ""
        self._build_bookmark_buttons()

    def _build_bookmark_buttons(self):
        self.buttons = []
        top = STATUS_BAR_H + 60
        for i, (title, url) in enumerate(BOOKMARKS):
            y = top + i * 46
            self.buttons.append(
                Button(16, y, SCREEN_W - 32, 40, title, self._open_url(title, url), font=FONT_SM))
        top += len(BOOKMARKS) * 46 + 6
        self.buttons.append(
            Button(16, top, SCREEN_W - 32, 40, "Type a URL...", self._start_typing, font=FONT_SM))
        self.buttons.append(
            Button(SCREEN_W // 2 - 60, SCREEN_H - 56, 120, 42,
                   "Home", self.os.go_home, font=FONT_MD))

    def _open_url(self, title, url):
        def handler():
            self._fetch(title, url)
        return handler

    # -- typing a custom URL --------------------------------------------
    def _start_typing(self):
        self.state = "type"
        self.draft_url = "https://"
        self.keyboard = Keyboard(4, SCREEN_H - KEYBOARD_H, SCREEN_W - 8, KEYBOARD_H - 4)
        self.buttons = [
            Button(16, STATUS_BAR_H + 92, 90, 34, "Cancel", self._cancel_typing, font=FONT_SM),
            Button(SCREEN_W - 106, STATUS_BAR_H + 92, 90, 34, "Go", self._go_to_draft, font=FONT_SM),
        ]

    def _cancel_typing(self):
        self.state = "bookmarks"
        self._build_bookmark_buttons()

    def _go_to_draft(self):
        url = self.draft_url.strip()
        if url and url != "https://":
            self._fetch(url, url)
        else:
            self.state = "bookmarks"
            self._build_bookmark_buttons()

    def _on_key(self, val):
        if val == "BACKSPACE":
            self.draft_url = self.draft_url[:-1]
        elif val == "ENTER":
            self._go_to_draft()
        elif len(self.draft_url) < MAX_URL_LEN:
            self.draft_url += val

    def on_tap(self, x, y):
        if self.state == "type" and self.keyboard.on_tap(x, y, self._on_key):
            return True
        return super().on_tap(x, y)

    def _fetch(self, title, url):
        try:
            import requests
        except ImportError:
            self.status = "The 'requests' package isn't installed"
            return

        try:
            resp = requests.get(url, timeout=8, headers={"User-Agent": "PiOS/1.0"})
            resp.raise_for_status()
            extractor = _TextExtractor()
            extractor.feed(resp.text)
            text = extractor.get_text()
            text = re.sub(r"\n{2,}", "\n", text)

            wrapped = []
            for line in text.splitlines():
                wrapped.extend(textwrap.wrap(line, CHARS_PER_LINE) or [""])

            self.pages = [wrapped[i:i + LINES_PER_PAGE]
                          for i in range(0, len(wrapped), LINES_PER_PAGE)] or [[]]
            self.page_index = 0
            self.current_title = title
            self.state = "page"
            self._build_page_buttons()
        except Exception as e:
            self.status = f"Couldn't load page: {e}"

    def _build_page_buttons(self):
        footer_y = SCREEN_H - 46
        self.buttons = [
            Button(10, footer_y, 80, 36, "Bookmarks", self._back_to_bookmarks, font=FONT_SM),
            Button(96, footer_y, 60, 36, "Prev", self._prev_page, font=FONT_SM),
            Button(160, footer_y, 60, 36, "Next", self._next_page, font=FONT_SM),
            Button(226, footer_y, 84, 36, "Home", self.os.go_home, font=FONT_SM),
        ]

    def _back_to_bookmarks(self):
        self.state = "bookmarks"
        self._build_bookmark_buttons()

    def _prev_page(self):
        if self.page_index > 0:
            self.page_index -= 1

    def _next_page(self):
        if self.page_index < len(self.pages) - 1:
            self.page_index += 1

    def draw(self, draw, canvas):
        if self.state == "type":
            draw.text((SCREEN_W // 2, STATUS_BAR_H + 18), "Go to URL", font=FONT_MD,
                       fill=(255, 255, 255), anchor="mm")
            draw.rounded_rectangle([16, STATUS_BAR_H + 38, SCREEN_W - 16, STATUS_BAR_H + 78],
                                    radius=10, fill=CARD_COLOR)
            draw.text((24, STATUS_BAR_H + 58), self.draft_url, font=FONT_SM,
                       fill=FG_COLOR, anchor="lm")
            for b in self.buttons:
                b.draw(draw)
            self.keyboard.draw(draw)
            return

        if self.state == "bookmarks":
            draw.text((SCREEN_W // 2, STATUS_BAR_H + 26), "Bookmarks", font=FONT_LG,
                       fill=(255, 255, 255), anchor="mm")
            if self.status:
                draw.text((SCREEN_W // 2, STATUS_BAR_H + 44), self.status, font=FONT_SM,
                           fill=(230, 90, 90), anchor="mm")
            for b in self.buttons:
                b.draw(draw)
            return

        draw.text((SCREEN_W // 2, STATUS_BAR_H + 14), self.current_title or "", font=FONT_MD,
                   fill=(255, 255, 255), anchor="mm")

        y = STATUS_BAR_H + 36
        for line in self.pages[self.page_index]:
            draw.text((14, y), line, font=FONT_SM, fill=(220, 220, 230), anchor="lm")
            y += 21

        draw.text((SCREEN_W // 2, SCREEN_H - 66),
                   f"Page {self.page_index + 1}/{len(self.pages)}", font=FONT_SM,
                   fill=(150, 150, 160), anchor="mm")

        for b in self.buttons:
            b.draw(draw)

"""
Settings -- now a small set of sections instead of a single screen:
  Display   - backlight brightness, auto-sleep (screen timeout)
  Sound     - master volume, sound on/off, tap-click feedback
  Theme     - pick from several full-OS color palettes, live preview
  Date/Time - 12h vs 24h clock
  About     - version info + reset everything to defaults

Every control here writes straight through ui.theme (persisted to
~/.pios_settings.json), so other apps/screens read the same live values
immediately -- no reboot needed to see a new theme or hear the new
volume.
"""

from ui import theme, sound
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_MD, FONT_SM, FONT_LG

TOP = STATUS_BAR_H + 20
ROW_H = 54
ROW_GAP = 10

MENU_ITEMS = [
    ("display", "\U0001F506", "Display"),
    ("sound", "\U0001F50A", "Sound"),
    ("theme", "\U0001F3A8", "Theme"),
    ("datetime", "\U0001F550", "Date & Time"),
    ("about", "\u2139", "About"),
]

SLEEP_CHOICES = [(0, "Off"), (30, "30s"), (60, "1m"), (120, "2m"), (300, "5m")]


class SettingsApp(App):
    name = "Settings"
    icon = "\u2699"

    def on_open(self):
        self.section = "menu"
        self._build_menu()

    # -- navigation -----------------------------------------------------
    def _goto(self, section):
        def handler():
            self.section = section
            {
                "menu": self._build_menu,
                "display": self._build_display,
                "sound": self._build_sound,
                "theme": self._build_theme,
                "datetime": self._build_datetime,
                "about": self._build_about,
            }[section]()
        return handler

    def _back_button(self):
        return Button(16, SCREEN_H - 60, 90, 42, "Back", self._goto("menu"), font=FONT_SM)

    def _home_button(self, x):
        return Button(x, SCREEN_H - 60, 90, 42, "Home", self.os.go_home, font=FONT_SM)

    # -- menu -------------------------------------------------------------
    def _build_menu(self):
        self.buttons = []
        y = TOP + 46
        for key, icon, label in MENU_ITEMS:
            self.buttons.append(
                Button(20, y, SCREEN_W - 40, ROW_H, f"{icon}  {label}",
                       self._goto(key), font=FONT_MD))
            y += ROW_H + ROW_GAP
        self.buttons.append(
            Button(SCREEN_W // 2 - 60, SCREEN_H - 60, 120, 42,
                   "Home", self.os.go_home, font=FONT_SM))

    # -- display ------------------------------------------------------
    def _build_display(self):
        self.buttons = [
            Button(30, TOP + 130, 70, 55, "-10", self._adjust_brightness(-10), font=FONT_MD),
            Button(SCREEN_W - 100, TOP + 130, 70, 55, "+10", self._adjust_brightness(10), font=FONT_MD),
        ]
        y = TOP + 230
        n = len(SLEEP_CHOICES)
        margin = 10
        cell_w = (SCREEN_W - margin * (n + 1)) // n
        for i, (secs, label) in enumerate(SLEEP_CHOICES):
            x = margin + i * (cell_w + margin)
            self.buttons.append(
                Button(x, y, cell_w, 44, label, self._set_sleep_timeout(secs), font=FONT_SM))
        self.buttons.append(
            Button(SCREEN_W // 2 - 90, y + 70, 180, 44,
                   "Sleep now", self._sleep_now, font=FONT_SM))
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _adjust_brightness(self, delta):
        def handler():
            b = max(10, min(100, theme.get("brightness") + delta))
            theme.set("brightness", b)
            try:
                self.os.lcd.set_backlight(b)
            except Exception:
                pass
        return handler

    def _set_sleep_timeout(self, secs):
        def handler():
            theme.set("sleep_timeout", secs)
        return handler

    def _sleep_now(self):
        self.os.enter_sleep(theme.get("brightness"))

    # -- sound ------------------------------------------------------------
    def _build_sound(self):
        self.buttons = [
            Button(30, TOP + 130, 70, 55, "-10", self._adjust_volume(-10), font=FONT_MD),
            Button(SCREEN_W - 100, TOP + 130, 70, 55, "+10", self._adjust_volume(10), font=FONT_MD),
            Button(SCREEN_W // 2 - 140, TOP + 220, 280, 46,
                   self._sound_label(), self._toggle_sound, font=FONT_SM),
            Button(SCREEN_W // 2 - 140, TOP + 276, 280, 46,
                   self._click_label(), self._toggle_click, font=FONT_SM),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _sound_label(self):
        return f"Sound: {'On' if theme.get('sound_enabled') else 'Off'}"

    def _click_label(self):
        return f"Tap sounds: {'On' if theme.get('click_sound') else 'Off'}"

    def _adjust_volume(self, delta):
        def handler():
            v = max(0, min(100, theme.get("volume") + delta))
            theme.set("volume", v)
            sound.refresh_volume()
            sound.click()
        return handler

    def _toggle_sound(self):
        theme.set("sound_enabled", not theme.get("sound_enabled"))
        self._build_sound()

    def _toggle_click(self):
        theme.set("click_sound", not theme.get("click_sound"))
        self._build_sound()
        sound.click()

    # -- theme ------------------------------------------------------------
    def _build_theme(self):
        self.buttons = []
        names = theme.PRESET_NAMES
        y = TOP + 60
        for i, name in enumerate(names):
            self.buttons.append(
                Button(20, y, SCREEN_W - 40, 44, name, self._set_theme(name), font=FONT_SM))
            y += 50
        self.buttons.append(self._back_button())
        self.buttons.append(self._home_button(SCREEN_W - 106))

    def _set_theme(self, name):
        def handler():
            theme.set("theme", name)
        return handler

    # -- date & time --------------------------------------------------
    def _build_datetime(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 140, TOP + 100, 280, 50,
                   self._clock_label(), self._toggle_clock_format, font=FONT_MD),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _clock_label(self):
        return "24-hour clock" if theme.get("clock_24h") else "12-hour clock"

    def _toggle_clock_format(self):
        theme.set("clock_24h", not theme.get("clock_24h"))
        self._build_datetime()

    # -- about ------------------------------------------------------------
    def _build_about(self):
        self.buttons = [
            Button(SCREEN_W // 2 - 100, SCREEN_H - 140, 200, 44,
                   "Reset all settings", self._reset, font=FONT_SM),
            self._back_button(),
            self._home_button(SCREEN_W - 106),
        ]

    def _reset(self):
        theme.reset()
        self._build_about()

    # -- drawing ------------------------------------------------------------
    def draw(self, draw, canvas):
        titles = {"menu": "Settings", "display": "Display", "sound": "Sound",
                  "theme": "Theme", "datetime": "Date & Time", "about": "About"}
        draw.text((SCREEN_W // 2, TOP), titles[self.section], font=FONT_LG,
                  fill=theme.fg_color(), anchor="mm")

        if self.section == "display":
            self._draw_display(draw)
        elif self.section == "sound":
            self._draw_sound(draw)
        elif self.section == "theme":
            self._draw_theme(draw)
        elif self.section == "about":
            self._draw_about(draw)

        for b in self.buttons:
            b.draw(draw)

    def _draw_display(self, draw):
        b = theme.get("brightness")
        draw.text((SCREEN_W // 2, TOP + 40), "Backlight", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        bar_x0, bar_x1 = 30, SCREEN_W - 30
        bar_y0, bar_y1 = TOP + 70, TOP + 100
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x1, bar_y1], radius=10, fill=theme.card_color())
        fill_w = int((bar_x1 - bar_x0) * b / 100)
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x0 + fill_w, bar_y1],
                                radius=10, fill=theme.accent_color())
        draw.text((SCREEN_W // 2, TOP + 157), f"{b}%", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")

        draw.text((SCREEN_W // 2, TOP + 200), "Auto-sleep after", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        current = theme.get("sleep_timeout")
        for btn, (secs, label) in zip(self.buttons[2:2 + len(SLEEP_CHOICES)], SLEEP_CHOICES):
            btn.bg = theme.accent_color() if secs == current else theme.card_color()

    def _draw_sound(self, draw):
        v = theme.get("volume")
        draw.text((SCREEN_W // 2, TOP + 40), "Volume", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        bar_x0, bar_x1 = 30, SCREEN_W - 30
        bar_y0, bar_y1 = TOP + 70, TOP + 100
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x1, bar_y1], radius=10, fill=theme.card_color())
        fill_w = int((bar_x1 - bar_x0) * v / 100)
        draw.rounded_rectangle([bar_x0, bar_y0, bar_x0 + fill_w, bar_y1],
                                radius=10, fill=theme.accent_color())
        draw.text((SCREEN_W // 2, TOP + 157), f"{v}%", font=FONT_MD,
                   fill=theme.fg_color(), anchor="mm")
        # keep the on/off toggle labels current
        self.buttons[2].label = self._sound_label()
        self.buttons[3].label = self._click_label()

    def _draw_theme(self, draw):
        current = theme.get("theme")
        for btn, name in zip(self.buttons, theme.PRESET_NAMES):
            palette = theme.PRESETS[name]
            swatch_x = btn.x + btn.w - 34
            draw.ellipse([swatch_x, btn.y + 12, swatch_x + 20, btn.y + 32],
                         fill=palette["accent"])
            btn.bg = theme.accent_color() if name == current else theme.card_color()

    def _draw_about(self, draw):
        lines = [
            "PiOS", "",
            "A tiny touchscreen OS for the",
            "Raspberry Pi + Waveshare 3.5\"",
            "LCD and UPS HAT (C).", "",
            f"Theme: {theme.get('theme')}",
            f"Sound: {'On' if theme.get('sound_enabled') else 'Off'}",
        ]
        y = TOP + 50
        for line in lines:
            draw.text((SCREEN_W // 2, y), line, font=FONT_SM,
                      fill=theme.fg_color(), anchor="mm")
            y += 24

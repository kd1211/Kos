import os
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_SM, FONT_MD, CARD_COLOR, ACCENT

START_DIR = os.path.expanduser("~")
ROW_H = 40
PAGE_SIZE = 7


def _human_size(n):
    for unit in ["B", "KB", "MB", "GB"]:
        if n < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024
    return f"{n:.0f}TB"


class FileBrowserApp(App):
    name = "FileBrowser"
    icon = "\U0001F4C2"

    def on_open(self):
        self.path = START_DIR
        self.page = 0
        self.selected_info = None
        self._load_dir()

    def _load_dir(self):
        entries = []
        try:
            for name in sorted(os.listdir(self.path)):
                full = os.path.join(self.path, name)
                is_dir = os.path.isdir(full)
                size = 0 if is_dir else (os.path.getsize(full) if os.path.exists(full) else 0)
                entries.append((name, is_dir, size))
            entries.sort(key=lambda e: (not e[1], e[0].lower()))
            self.error = None
        except Exception as e:
            entries = []
            self.error = str(e)
        self.entries = entries
        self._build_buttons()

    def _build_buttons(self):
        top = STATUS_BAR_H + 60
        self.buttons = []
        start = self.page * PAGE_SIZE
        page_entries = self.entries[start:start + PAGE_SIZE]

        for i, (name, is_dir, size) in enumerate(page_entries):
            y = top + i * ROW_H
            label = name if is_dir else f"{name} ({_human_size(size)})"
            self.buttons.append(
                Button(16, y, SCREEN_W - 32, ROW_H - 6, label,
                       self._select(start + i), font=FONT_SM))

        footer_y = top + len(page_entries) * ROW_H + 10
        total_pages = max(1, (len(self.entries) + PAGE_SIZE - 1) // PAGE_SIZE)

        self.buttons.append(Button(10, footer_y, 70, 36, "Up", self._go_up, font=FONT_SM))
        self.buttons.append(Button(88, footer_y, 60, 36, "Prev", self._prev_page, font=FONT_SM))
        self.buttons.append(Button(152, footer_y, 60, 36, "Next", self._next_page, font=FONT_SM))
        self.buttons.append(Button(220, footer_y, 90, 36, "Home", self.os.go_home, font=FONT_SM))
        self._total_pages = total_pages

    def _select(self, idx):
        def handler():
            name, is_dir, size = self.entries[idx]
            if is_dir:
                self.path = os.path.join(self.path, name)
                self.page = 0
                self._load_dir()
            else:
                self.selected_info = f"{name} - {_human_size(size)}"
        return handler

    def _go_up(self):
        parent = os.path.dirname(self.path.rstrip("/"))
        if parent:
            self.path = parent
            self.page = 0
            self.selected_info = None
            self._load_dir()

    def _prev_page(self):
        if self.page > 0:
            self.page -= 1
            self._build_buttons()

    def _next_page(self):
        if (self.page + 1) * PAGE_SIZE < len(self.entries):
            self.page += 1
            self._build_buttons()

    def draw(self, draw, canvas):
        top = STATUS_BAR_H + 14
        display_path = self.path
        if len(display_path) > 34:
            display_path = "..." + display_path[-31:]
        draw.text((SCREEN_W // 2, top), display_path, font=FONT_SM,
                   fill=(210, 210, 220), anchor="mm")

        if self.selected_info:
            draw.text((SCREEN_W // 2, top + 22), self.selected_info, font=FONT_SM,
                       fill=ACCENT, anchor="mm")

        if self.error:
            draw.text((SCREEN_W // 2, STATUS_BAR_H + 120), f"Can't open:\n{self.error}",
                       font=FONT_SM, fill=(230, 90, 90), anchor="mm", align="center")
        elif not self.entries:
            draw.text((SCREEN_W // 2, STATUS_BAR_H + 120), "Empty folder",
                       font=FONT_SM, fill=(150, 150, 160), anchor="mm")

        for b in self.buttons:
            b.draw(draw)

        draw.text((SCREEN_W // 2, SCREEN_H - 8),
                   f"Page {self.page + 1}/{self._total_pages}", font=FONT_SM,
                   fill=(140, 140, 150), anchor="mm")

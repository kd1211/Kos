# PhoneOS

Lightweight phone-style OS for Raspberry Pi Zero / Zero 2 W.

## Install on the Pi

1. Flash Raspberry Pi OS Lite, boot it, SSH in (or use a keyboard).
2. Copy this whole `phoneos/` folder onto the Pi, e.g.:
   scp -r phoneos pi@<ip>:~/phoneos
3. On the Pi:
   cd ~/phoneos
   sudo bash install.sh
   sudo reboot

The installer enables I2C/SPI, installs pygame + deps, copies everything
to /phoneos, registers the built-in apps, and sets up a systemd service
(phoneos.service) that boots straight into the launcher.

## Test on a desktop first (recommended)

You can run the launcher on your dev machine before touching the Pi:

    pip install pygame
    PYTHONPATH=. python3 boot.py

It runs in a normal window at 320x480. Tap = left click.

## Built-in apps

- **Settings** — Wi-Fi/Bluetooth status, battery detail, storage, installed
  apps, developer mode, About, and a link into System Updater.
- **Files** — browse/copy/move/delete/paste, install `.phoneapp` packages,
  opens text files in Text Editor and images in Gallery.
- **Terminal** — shell commands + on-screen keyboard.
- **Clock** — digital clock + date.
- **Calculator** — 4-function calculator.
- **App Store** — browse/install/update/remove apps from configured GitHub
  repos (default: kd1211/Kos-App-Store). See core/store.py for the repo
  layout (`index.json` + `apps/` + `icons/` + `banners/`).
- **Text Editor** — open/edit/save text files. Launched standalone or by
  Files with a path argument.
- **Gallery** — thumbnail grid + fullscreen swipe viewer for images in
  /phoneos/user and /phoneos/wallpapers, or a single image path.
- **Browser** — fetches http/https pages and renders them as scrollable
  text with tappable links (see "Browser limitations" below). Tabs,
  bookmarks, downloads for non-HTML content.
- **Messages** — peer-to-peer chat + file transfer over the local Wi-Fi
  network. No server, no accounts: devices discover each other via UDP
  broadcast (see core/p2p.py).
- **System Updater** — checks a GitHub repo's `version.json`, downloads
  and applies OS updates, automatically backs up and rolls back on any
  failure. Default repo: kd1211/Kos. See "Publishing an OS update" below.

## Browser limitations

There's no realistic path to a full HTML5/CSS/JS engine on a Pi Zero, so
the Browser is a lightweight text+links renderer (see core/htmlrender.py):
it strips scripts/styles and shows readable text with working links.
No images, no CSS layout, no JS-driven pages (single-page apps built
entirely in JS will show blank or near-blank).

## Publishing an OS update

At the root of your `Kos` repo (or whichever repo you point System
Updater at), commit:

    version.json   ->  {"version": "0.2.0", "package": "phoneos.zip"}
    phoneos.zip    ->  a zip of this phoneos/ folder's contents

System Updater fetches version.json, compares against `/phoneos/VERSION`,
and if newer, downloads phoneos.zip and replaces `core/` and any system
apps it contains, leaving user/, downloads/, cache/, logs/, wallpapers/,
themes/, and third-party apps untouched. Any failure mid-apply restores
the automatic backup.

## Adding your own app

Create `/phoneos/apps/<yourapp>/manifest.json`:

    {
      "id": "com.you.yourapp",
      "name": "Your App",
      "version": "1.0.0",
      "entry": "main.py",
      "icon": "icon.png",
      "type": "user"
    }

Add `main.py` (any pygame app, 320x480, reads config.SCREEN_W/H) and an
optional `icon.png`. It shows up on the home screen after a rescan
(automatic on next boot, or call `core.app_manager.rebuild_db()`).

## Adding apps to the App Store

Drop a `.phoneapp` zip (containing manifest.json + main.py + assets) into
`apps/` in your Kos-App-Store repo, add an entry to `index.json`, push.

## Not yet built

Touchscreen calibration UI, brightness control, group chats.

## Games

- **Snake** — on-screen D-pad (or arrow keys/WASD), speeds up as you eat,
  high score saved.
- **2048** — swipe (drag) or arrow keys, standard merge rules.
- **Breakout** — drag to move the paddle, tap to launch the ball, 3 lives.

All three persist a high score to /phoneos/user/game_scores.json via
core/gamescores.py.

## Security (PIN lock)

Settings → Security lets you set a 4-8 digit PIN (core/lock.py stores
only a salted SHA-256 hash, never the PIN itself). When set, the phone
locks whenever the screen wakes from idle sleep (toggle "Lock on Wake"
to turn that off while keeping the PIN saved). "Remove PIN" requires
re-entering the current PIN first.

## Images (Pillow)

Gallery and app icon loading go through core/imaging.py, which uses
Pillow (PIL) for broader format support and much better resize quality
(LANCZOS) than pygame's native scaler, with cover/contain/stretch
fitting modes. Falls back to pygame's own loader automatically if
Pillow isn't installed, so nothing breaks if `python3-pil` is missing.

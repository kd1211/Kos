"""A small reusable on-screen QWERTY keyboard for touch text entry.
Returns discrete events from handle_tap() so callers can manage their
own input buffer: a single printable char, or one of
'BACKSPACE', 'ENTER', 'SHIFT', 'SPACE'.
"""
import pygame

ROWS = [
    "1234567890",
    "qwertyuiop",
    "asdfghjkl",
    "zxcvbnm",
]
KEY_H = 34


class OnScreenKeyboard:
    def __init__(self, screen_w, screen_h, font=None, extra_row=None):
        self.w = screen_w
        self.h = screen_h
        self.font = font or pygame.font.Font(None, 18)
        self.shift = False
        self.rows = list(ROWS) + ([extra_row] if extra_row else [])
        self._build()

    def _build(self):
        self.keys = []
        self.top = self.h - (len(self.rows) + 1) * KEY_H - 4
        for r, row in enumerate(self.rows):
            n = len(row)
            key_w = self.w // (n + 1)
            offset = (self.w - n * key_w) // 2
            for i, ch in enumerate(row):
                rect = pygame.Rect(offset + i * key_w, self.top + r * KEY_H, key_w - 2, KEY_H - 2)
                self.keys.append((rect, ch))
        y = self.top + len(self.rows) * KEY_H
        self.key_space = pygame.Rect(60, y, self.w - 220, KEY_H - 2)
        self.key_back = pygame.Rect(self.w - 155, y, 70, KEY_H - 2)
        self.key_enter = pygame.Rect(self.w - 80, y, 70, KEY_H - 2)
        self.key_shift = pygame.Rect(4, y, 50, KEY_H - 2)

    @property
    def height(self):
        return self.h - self.top

    def draw(self, screen, bg_color=(18, 18, 22), fg_color=(230, 230, 230), accent=(70, 140, 255)):
        pygame.draw.rect(screen, bg_color, (0, self.top - 2, self.w, self.h - self.top + 2))
        for rect, ch in self.keys:
            pygame.draw.rect(screen, (40, 40, 48), rect, border_radius=4)
            disp = ch.upper() if self.shift else ch
            t = self.font.render(disp, True, fg_color)
            screen.blit(t, t.get_rect(center=rect.center))
        for rect, label in [
            (self.key_space, "space"), (self.key_back, "back"),
            (self.key_enter, "enter"), (self.key_shift, "shift"),
        ]:
            pygame.draw.rect(screen, (40, 40, 48), rect, border_radius=4)
            t = self.font.render(label, True, accent)
            screen.blit(t, t.get_rect(center=rect.center))

    def handle_tap(self, pos):
        """Return a printable char, one of the control strings, or None."""
        for rect, ch in self.keys:
            if rect.collidepoint(pos):
                return ch.upper() if self.shift else ch
        if self.key_space.collidepoint(pos):
            return "SPACE"
        if self.key_back.collidepoint(pos):
            return "BACKSPACE"
        if self.key_enter.collidepoint(pos):
            return "ENTER"
        if self.key_shift.collidepoint(pos):
            self.shift = not self.shift
            return "SHIFT"
        return None

"""Touchscreen calibration.

Most touch controllers (including capacitive ones) report coordinates
close enough to the panel's true pixel grid that no correction is
needed, but bezel/mounting skew, axis inversion, or a slightly
mismatched digitizer range are all common enough on hobbyist HATs that
the spec calls for calibration support. This implements the standard
3-point affine calibration: tap 3 known, non-collinear on-screen
targets, and solve exactly for the 6 affine coefficients that map raw
touch coordinates to true screen coordinates.

    screen_x = a*raw_x + b*raw_y + c
    screen_y = d*raw_x + e*raw_y + f

All apps should read touch positions via get_pos(event) rather than
event.pos / event.x,y directly, so calibration applies everywhere.
"""
import json
import os

import pygame

from core import config

CALIBRATION_FILE = os.path.join(config.USER_DIR, "calibration.json")
IDENTITY = {"a": 1.0, "b": 0.0, "c": 0.0, "d": 0.0, "e": 1.0, "f": 0.0}

_cached = None


def load_calibration():
    global _cached
    if _cached is not None:
        return _cached
    if os.path.isfile(CALIBRATION_FILE):
        try:
            with open(CALIBRATION_FILE, "r") as f:
                data = json.load(f)
            if all(k in data for k in IDENTITY):
                _cached = data
                return _cached
        except (json.JSONDecodeError, OSError):
            pass
    _cached = dict(IDENTITY)
    return _cached


def save_calibration(coeffs):
    global _cached
    os.makedirs(config.USER_DIR, exist_ok=True)
    with open(CALIBRATION_FILE, "w") as f:
        json.dump(coeffs, f, indent=2)
    _cached = dict(coeffs)


def reset_calibration():
    save_calibration(dict(IDENTITY))


def _det3(m):
    return (
        m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
    )


def _solve3(matrix, vec):
    """Solve a 3x3 linear system via Cramer's rule."""
    d = _det3(matrix)
    if abs(d) < 1e-9:
        raise ValueError("calibration points are collinear or degenerate")
    result = []
    for col in range(3):
        m = [row[:] for row in matrix]
        for r in range(3):
            m[r][col] = vec[r]
        result.append(_det3(m) / d)
    return tuple(result)


def compute_affine(raw_points, screen_points):
    """raw_points/screen_points: 3 (x, y) tuples each. Returns a coeffs dict."""
    if len(raw_points) != 3 or len(screen_points) != 3:
        raise ValueError("exactly 3 calibration points are required")
    m = [[rx, ry, 1.0] for rx, ry in raw_points]
    a, b, c = _solve3(m, [sx for sx, sy in screen_points])
    d, e, f = _solve3(m, [sy for sx, sy in screen_points])
    return {"a": a, "b": b, "c": c, "d": d, "e": e, "f": f}


def apply(raw_pos, coeffs=None):
    coeffs = coeffs or load_calibration()
    rx, ry = raw_pos
    x = coeffs["a"] * rx + coeffs["b"] * ry + coeffs["c"]
    y = coeffs["d"] * rx + coeffs["e"] * ry + coeffs["f"]
    x = max(0, min(config.SCREEN_W - 1, int(x)))
    y = max(0, min(config.SCREEN_H - 1, int(y)))
    return (x, y)


def raw_pos(event):
    """Extract the raw, uncalibrated position from a pygame input event.
    Works for mouse events (event.pos) and any finger event -- down, up,
    or motion -- which all report normalized event.x/event.y."""
    if hasattr(event, "x") and hasattr(event, "y") and not hasattr(event, "pos"):
        return (event.x * config.SCREEN_W, event.y * config.SCREEN_H)
    return event.pos


def get_pos(event):
    """Extract and calibrate a touch/click position from a pygame event.
    This is what every app should call instead of handling event.pos /
    event.x,y itself."""
    return apply(raw_pos(event))

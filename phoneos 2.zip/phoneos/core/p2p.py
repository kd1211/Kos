"""Peer-to-peer messaging backend for PhoneOS Messages.

Discovery: each device broadcasts a small UDP announcement every few
seconds on DISCOVERY_PORT and listens for the same from others.
Messaging/files: a TCP listener accepts connections; each message is a
single JSON line (the "meta") optionally followed by raw file bytes.

This only needs devices to be on the same Wi-Fi/LAN broadcast domain --
no internet, no accounts, no server.
"""
import json
import os
import socket
import threading
import time
import uuid
import logging

from core import config

log = logging.getLogger("phoneos.p2p")

DISCOVERY_PORT = 42420
MESSAGE_PORT = 42421
ANNOUNCE_INTERVAL = 3
PEER_TIMEOUT = 15

DEVICE_ID_FILE = os.path.join(config.SYSTEM_DIR, "device_id.txt")
MESSAGES_DIR = os.path.join(config.USER_DIR, "messages")
RECEIVED_FILES_DIR = os.path.join(config.DOWNLOADS_DIR, "received")


def get_device_id():
    if os.path.isfile(DEVICE_ID_FILE):
        with open(DEVICE_ID_FILE, "r") as f:
            return f.read().strip()
    os.makedirs(config.SYSTEM_DIR, exist_ok=True)
    new_id = uuid.uuid4().hex[:12]
    with open(DEVICE_ID_FILE, "w") as f:
        f.write(new_id)
    return new_id


def get_device_name():
    return socket.gethostname() or "PhoneOS Device"


def _conv_path(peer_id):
    os.makedirs(MESSAGES_DIR, exist_ok=True)
    return os.path.join(MESSAGES_DIR, f"{peer_id}.json")


def load_conversation(peer_id):
    path = _conv_path(peer_id)
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def append_conversation(peer_id, entry):
    conv = load_conversation(peer_id)
    conv.append(entry)
    with open(_conv_path(peer_id), "w") as f:
        json.dump(conv[-500:], f)


class P2PService:
    def __init__(self, on_message=None):
        self.id = get_device_id()
        self.name = get_device_name()
        self.peers = {}  # id -> {name, ip, port, last_seen}
        self.on_message = on_message  # callback(peer_id, entry)
        self._running = False
        self._lock = threading.Lock()

    def start(self):
        self._running = True
        threading.Thread(target=self._announce_loop, daemon=True).start()
        threading.Thread(target=self._discovery_listener, daemon=True).start()
        threading.Thread(target=self._message_listener, daemon=True).start()
        threading.Thread(target=self._prune_loop, daemon=True).start()

    def stop(self):
        self._running = False

    # -------------------------------------------------------- discovery
    def _announce_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        payload = json.dumps({
            "id": self.id, "name": self.name, "port": MESSAGE_PORT,
        }).encode()
        while self._running:
            try:
                sock.sendto(payload, ("255.255.255.255", DISCOVERY_PORT))
            except OSError as e:
                log.debug("announce failed: %s", e)
            time.sleep(ANNOUNCE_INTERVAL)

    def _discovery_listener(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", DISCOVERY_PORT))
        except OSError as e:
            log.error("Could not bind discovery port: %s", e)
            return
        sock.settimeout(1.0)
        while self._running:
            try:
                data, addr = sock.recvfrom(2048)
                info = json.loads(data.decode())
                if info.get("id") == self.id:
                    continue
                with self._lock:
                    self.peers[info["id"]] = {
                        "name": info.get("name", "Unknown"),
                        "ip": addr[0],
                        "port": info.get("port", MESSAGE_PORT),
                        "last_seen": time.time(),
                    }
            except socket.timeout:
                continue
            except (OSError, json.JSONDecodeError, KeyError) as e:
                log.debug("discovery listener error: %s", e)

    def _prune_loop(self):
        while self._running:
            time.sleep(5)
            now = time.time()
            with self._lock:
                stale = [pid for pid, p in self.peers.items() if now - p["last_seen"] > PEER_TIMEOUT]
                for pid in stale:
                    del self.peers[pid]

    def get_peers(self):
        with self._lock:
            return dict(self.peers)

    # -------------------------------------------------------- messaging
    def _message_listener(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", MESSAGE_PORT))
            sock.listen(5)
        except OSError as e:
            log.error("Could not bind message port: %s", e)
            return
        sock.settimeout(1.0)
        while self._running:
            try:
                conn, addr = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                continue
            threading.Thread(target=self._handle_conn, args=(conn,), daemon=True).start()

    def _handle_conn(self, conn):
        try:
            f = conn.makefile("rb")
            line = f.readline()
            if not line:
                return
            meta = json.loads(line.decode())
            peer_id = meta.get("from_id", "unknown")
            entry = {
                "from_id": peer_id,
                "from_name": meta.get("from_name", "Unknown"),
                "ts": meta.get("ts", time.time()),
                "direction": "in",
            }
            if meta["type"] == "text":
                entry["type"] = "text"
                entry["text"] = meta.get("text", "")
            elif meta["type"] == "file":
                size = meta.get("size", 0)
                filename = os.path.basename(meta.get("filename", "file"))
                os.makedirs(RECEIVED_FILES_DIR, exist_ok=True)
                dest = os.path.join(RECEIVED_FILES_DIR, filename)
                remaining = size
                with open(dest, "wb") as out:
                    while remaining > 0:
                        chunk = f.read(min(8192, remaining))
                        if not chunk:
                            break
                        out.write(chunk)
                        remaining -= len(chunk)
                entry["type"] = "file"
                entry["filename"] = filename
                entry["path"] = dest
            else:
                return
            append_conversation(peer_id, entry)
            if self.on_message:
                self.on_message(peer_id, entry)
        except (OSError, json.JSONDecodeError, KeyError) as e:
            log.warning("message handling failed: %s", e)
        finally:
            conn.close()

    def send_text(self, peer_id, text):
        peer = self.peers.get(peer_id)
        if not peer:
            return False
        meta = {
            "type": "text", "from_id": self.id, "from_name": self.name,
            "text": text, "ts": time.time(),
        }
        ok = self._send(peer, meta)
        if ok:
            append_conversation(peer_id, {**meta, "direction": "out"})
        return ok

    def send_file(self, peer_id, filepath):
        peer = self.peers.get(peer_id)
        if not peer or not os.path.isfile(filepath):
            return False
        size = os.path.getsize(filepath)
        meta = {
            "type": "file", "from_id": self.id, "from_name": self.name,
            "filename": os.path.basename(filepath), "size": size, "ts": time.time(),
        }
        ok = self._send(peer, meta, filepath=filepath)
        if ok:
            append_conversation(peer_id, {**meta, "direction": "out", "path": filepath})
        return ok

    def _send(self, peer, meta, filepath=None):
        try:
            with socket.create_connection((peer["ip"], peer["port"]), timeout=10) as conn:
                conn.sendall(json.dumps(meta).encode() + b"\n")
                if filepath:
                    with open(filepath, "rb") as f:
                        while True:
                            chunk = f.read(8192)
                            if not chunk:
                                break
                            conn.sendall(chunk)
            return True
        except OSError as e:
            log.warning("send failed: %s", e)
            return False

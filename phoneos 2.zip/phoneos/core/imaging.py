"""Image loading via Pillow (PIL) instead of relying only on pygame's
built-in image module. Pillow gives broader format support (WebP, more
GIF/BMP/ICO variants) and much better resize quality (LANCZOS) than
pygame's own scaler. Falls back to pygame's loader if Pillow isn't
installed or fails to open a given file, so nothing regresses.
"""
import logging

import pygame

log = logging.getLogger("phoneos.imaging")

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    log.info("Pillow not installed; falling back to pygame's image loader")


def _pil_to_surface(img):
    img = img.convert("RGBA")
    return pygame.image.frombuffer(img.tobytes(), img.size, "RGBA").convert_alpha()


def _resize(img, size, fit):
    target_w, target_h = size
    if fit == "stretch":
        return img.resize((target_w, target_h), Image.LANCZOS)

    src_w, src_h = img.size
    scale_fit = min(target_w / src_w, target_h / src_h)
    scale_cover = max(target_w / src_w, target_h / src_h)
    scale = scale_fit if fit == "contain" else scale_cover
    new_w, new_h = max(1, round(src_w * scale)), max(1, round(src_h * scale))
    img = img.resize((new_w, new_h), Image.LANCZOS)

    if fit == "cover":
        left = (new_w - target_w) // 2
        top = (new_h - target_h) // 2
        img = img.crop((left, top, left + target_w, top + target_h))
    return img


def load(path, size=None, fit="cover"):
    """Load an image file as a pygame Surface, optionally resized.

    fit:
      'cover'   -> preserve aspect ratio, crop to exactly fill `size`
      'contain' -> preserve aspect ratio, fit within `size`, no crop/distortion
      'stretch' -> resize to exactly `size`, ignoring aspect ratio

    Returns None if the image can't be loaded by either backend.
    """
    if PIL_AVAILABLE:
        try:
            img = Image.open(path)
            img.load()
            if size:
                img = _resize(img, size, fit)
            return _pil_to_surface(img)
        except Exception as e:  # noqa: BLE001 - fall back to pygame below
            log.debug("PIL failed to load %s (%s), falling back to pygame", path, e)

    try:
        surf = pygame.image.load(path)
        surf = surf.convert_alpha()
        if size:
            surf = pygame.transform.smoothscale(surf, size)
        return surf
    except (pygame.error, OSError) as e:
        log.warning("Could not load image %s: %s", path, e)
        return None

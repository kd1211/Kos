"""2048 game logic, kept free of pygame so it can be unit tested and
reused by the UI without duplication.

Board is a 4x4 list of lists, 0 = empty.
"""
import random

SIZE = 4


def new_board():
    board = [[0] * SIZE for _ in range(SIZE)]
    add_random_tile(board)
    add_random_tile(board)
    return board


def add_random_tile(board):
    empties = [(r, c) for r in range(SIZE) for c in range(SIZE) if board[r][c] == 0]
    if not empties:
        return False
    r, c = random.choice(empties)
    board[r][c] = 4 if random.random() < 0.1 else 2
    return True


def _compress_and_merge(row):
    """Slide a single row left, merging equal adjacent tiles once each.
    Returns (new_row, score_gained, moved)."""
    nums = [v for v in row if v != 0]
    merged = []
    score = 0
    i = 0
    while i < len(nums):
        if i + 1 < len(nums) and nums[i] == nums[i + 1]:
            merged.append(nums[i] * 2)
            score += nums[i] * 2
            i += 2
        else:
            merged.append(nums[i])
            i += 1
    merged += [0] * (SIZE - len(merged))
    moved = merged != row
    return merged, score, moved


def _transpose(board):
    return [list(row) for row in zip(*board)]


def _reverse_rows(board):
    return [list(reversed(row)) for row in board]


def move(board, direction):
    """direction: 'left', 'right', 'up', 'down'.
    Returns (new_board, score_gained, moved: bool)."""
    b = [row[:] for row in board]

    if direction == "up":
        b = _transpose(b)
    elif direction == "down":
        b = _transpose(b)
        b = _reverse_rows(b)
    elif direction == "right":
        b = _reverse_rows(b)
    elif direction != "left":
        raise ValueError(f"invalid direction: {direction}")

    total_score = 0
    any_moved = False
    new_rows = []
    for row in b:
        new_row, score, moved = _compress_and_merge(row)
        new_rows.append(new_row)
        total_score += score
        any_moved = any_moved or moved
    b = new_rows

    if direction == "up":
        b = _transpose(b)
    elif direction == "down":
        b = _reverse_rows(b)
        b = _transpose(b)
    elif direction == "right":
        b = _reverse_rows(b)

    return b, total_score, any_moved


def has_moves(board):
    for r in range(SIZE):
        for c in range(SIZE):
            if board[r][c] == 0:
                return True
            if c + 1 < SIZE and board[r][c] == board[r][c + 1]:
                return True
            if r + 1 < SIZE and board[r][c] == board[r + 1][c]:
                return True
    return False


def has_won(board):
    return any(board[r][c] >= 2048 for r in range(SIZE) for c in range(SIZE))

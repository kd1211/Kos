"""A small reusable numeric keypad for entering PINs. Mirrors the shape
of core/keyboard.py's OnScreenKeyboard so callers use it the same way.
"""
import pygame

KEY_H = 56
LAYOUT = [
    ["1", "2", "3"],
    ["4", "5", "6"],
    ["7", "8", "9"],
    ["DEL", "0", "OK"],
]


class NumPad:
    def __init__(self, screen_w, screen_h, font=None, bottom_margin=20):
        self.w = screen_w
        self.h = screen_h
        self.font = font or pygame.font.Font(None, 28)
        self.bottom_margin = bottom_margin
        self._build()

    def _build(self):
        rows = len(LAYOUT)
        cols = len(LAYOUT[0])
        self.top = self.h - rows * KEY_H - self.bottom_margin
        key_w = self.w // cols
        self.keys = []
        for r, row in enumerate(LAYOUT):
            for c, label in enumerate(row):
                rect = pygame.Rect(c * key_w + 4, self.top + r * KEY_H + 4, key_w - 8, KEY_H - 8)
                self.keys.append((rect, label))

    def draw(self, screen, bg=None):
        for rect, label in self.keys:
            color = (60, 40, 40) if label == "DEL" else (40, 70, 50) if label == "OK" else (40, 40, 48)
            pygame.draw.rect(screen, color, rect, border_radius=8)
            t = self.font.render(label, True, (230, 230, 230))
            screen.blit(t, t.get_rect(center=rect.center))

    def handle_tap(self, pos):
        """Returns a digit string, 'DEL', 'OK', or None."""
        for rect, label in self.keys:
            if rect.collidepoint(pos):
                return label
        return None

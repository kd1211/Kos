"""Device PIN lock.

Stores a salted SHA-256 hash of the PIN, never the PIN itself, at
/phoneos/system/lock.json:

    {"enabled": true, "lock_on_wake": true, "salt": "<hex>", "hash": "<hex>"}

"enabled" being false just turns the lock off without discarding the
saved PIN, so re-enabling doesn't require setting a new one. "Remove
PIN" (clear()) wipes the hash entirely.
"""
import hashlib
import json
import os
import secrets

from core import config

LOCK_FILE = os.path.join(config.SYSTEM_DIR, "lock.json")
MIN_PIN_LEN = 4
MAX_PIN_LEN = 8


def _load():
    if not os.path.isfile(LOCK_FILE):
        return {"enabled": False, "lock_on_wake": True, "salt": None, "hash": None}
    try:
        with open(LOCK_FILE, "r") as f:
            data = json.load(f)
        data.setdefault("enabled", False)
        data.setdefault("lock_on_wake", True)
        data.setdefault("salt", None)
        data.setdefault("hash", None)
        return data
    except (json.JSONDecodeError, OSError):
        return {"enabled": False, "lock_on_wake": True, "salt": None, "hash": None}


def _save(data):
    os.makedirs(config.SYSTEM_DIR, exist_ok=True)
    with open(LOCK_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _hash_pin(pin, salt):
    return hashlib.sha256((salt + pin).encode()).hexdigest()


def is_pin_set():
    return _load()["hash"] is not None


def is_enabled():
    data = _load()
    return data["enabled"] and data["hash"] is not None


def lock_on_wake_enabled():
    return _load().get("lock_on_wake", True)


def set_lock_on_wake(value):
    data = _load()
    data["lock_on_wake"] = bool(value)
    _save(data)


def set_pin(pin):
    """Sets a new PIN and enables the lock. Returns (ok, error_message)."""
    if not pin.isdigit():
        return False, "PIN must be numbers only"
    if not (MIN_PIN_LEN <= len(pin) <= MAX_PIN_LEN):
        return False, f"PIN must be {MIN_PIN_LEN}-{MAX_PIN_LEN} digits"
    salt = secrets.token_hex(16)
    data = _load()
    data.update({"enabled": True, "salt": salt, "hash": _hash_pin(pin, salt)})
    _save(data)
    return True, ""


def verify_pin(pin):
    data = _load()
    if not data["hash"] or not data["salt"]:
        return False
    return secrets.compare_digest(_hash_pin(pin, data["salt"]), data["hash"])


def set_enabled(value):
    """Turn the lock on/off without discarding the stored PIN. Turning it
    on requires a PIN to already be set."""
    data = _load()
    if value and not data["hash"]:
        return False
    data["enabled"] = bool(value)
    _save(data)
    return True


def clear():
    """Fully removes the stored PIN and disables the lock."""
    _save({"enabled": False, "lock_on_wake": True, "salt": None, "hash": None})

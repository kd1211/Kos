"""A tiny reusable toast/banner notification.

    self.toast = Toast()
    ...
    self.toast.show("Saved")
    ...
    # each frame, after drawing everything else:
    self.toast.draw(self.screen)

Handles its own fade timing so apps don't need per-message timers.
"""
import time
import pygame

from core import config


class Toast:
    def __init__(self, duration=2.0):
        self.duration = duration
        self.message = None
        self.color = (230, 230, 230)
        self._shown_at = 0

    def show(self, message, color=(230, 230, 230)):
        self.message = message
        self.color = color
        self._shown_at = time.time()

    def draw(self, screen, font=None):
        if not self.message:
            return
        elapsed = time.time() - self._shown_at
        if elapsed > self.duration:
            self.message = None
            return
        font = font or pygame.font.Font(None, 18)
        W, H = config.SCREEN_W, config.SCREEN_H
        text = font.render(self.message, True, (255, 255, 255))
        pad_x, pad_y = 14, 8
        box_w = text.get_width() + pad_x * 2
        box_h = text.get_height() + pad_y * 2
        box = pygame.Rect(0, 0, box_w, box_h)
        box.midbottom = (W // 2, H - 46)

        alpha = 255 if elapsed < self.duration - 0.4 else int(255 * (self.duration - elapsed) / 0.4)
        alpha = max(0, min(255, alpha))
        surf = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        pygame.draw.rect(surf, (30, 30, 36, min(230, alpha)), surf.get_rect(), border_radius=8)
        surf.blit(text, (pad_x, pad_y))
        surf.set_alpha(alpha)
        screen.blit(surf, box)

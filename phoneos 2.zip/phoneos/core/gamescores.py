"""Tiny shared high-score store for built-in games.
One JSON file, one key per game, so each game doesn't need its own
storage boilerplate.
"""
import json
import os

from core import config

SCORES_FILE = os.path.join(config.USER_DIR, "game_scores.json")


def _load():
    if not os.path.isfile(SCORES_FILE):
        return {}
    try:
        with open(SCORES_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def get_high_score(game_id):
    return _load().get(game_id, 0)


def submit_score(game_id, score):
    """Saves score if it's a new high score. Returns True if it was."""
    scores = _load()
    if score > scores.get(game_id, 0):
        scores[game_id] = score
        os.makedirs(config.USER_DIR, exist_ok=True)
        with open(SCORES_FILE, "w") as f:
            json.dump(scores, f, indent=2)
        return True
    return False

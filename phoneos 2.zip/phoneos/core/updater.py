"""PhoneOS System Updater backend.

Expects a GitHub repo (default: the OS repo itself) with, at its root:
    version.json   -> {"version": "0.2.0", "package": "phoneos.zip"}
    phoneos.zip     -> a zip of the repo's phoneos/ folder contents

Update strategy: back up core/ + the current system apps, download and
extract the new package to a temp dir, copy its core/ and system apps
over the live ones, then rebuild the app database. User files
(user/, downloads/, cache/, logs/, wallpapers/, themes/, installed
third-party apps, system/installed_apps.json, system/repos.json) are
never touched. Any failure during apply triggers an automatic restore
from the backup.
"""
import json
import os
import shutil
import tempfile
import zipfile
import logging
import time
import urllib.request
import urllib.error

from core import config, app_manager

log = logging.getLogger("phoneos.updater")

TIMEOUT = 10
USER_AGENT = "PhoneOS-Updater/1.0"
VERSION_FILE = os.path.join(config.ROOT, "VERSION")
DEFAULT_REPO = {"owner": "kd1211", "repo": "Kos", "branch": "main"}


def _raw_base(repo):
    return f"https://raw.githubusercontent.com/{repo['owner']}/{repo['repo']}/{repo['branch']}/"


def _get(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read()


def get_local_version():
    if os.path.isfile(VERSION_FILE):
        with open(VERSION_FILE, "r") as f:
            return f.read().strip()
    return "0.0.0"


def _version_tuple(v):
    parts = []
    for p in v.split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def is_newer(remote, local):
    return _version_tuple(remote) > _version_tuple(local)


def check_update(repo=None):
    """Return remote version.json dict, or None on failure."""
    repo = repo or DEFAULT_REPO
    try:
        raw = _get(_raw_base(repo) + "version.json")
        data = json.loads(raw)
        data["_base"] = _raw_base(repo)
        return data
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            json.JSONDecodeError, OSError) as e:
        log.warning("update check failed: %s", e)
        return None


SYSTEM_APP_IDS_PRESERVE_IF_MISSING = True  # don't delete apps the update omits


def apply_update(update_info, progress_cb=None):
    """Download and apply an update. Returns (ok: bool, message: str)."""
    url = update_info["_base"] + update_info["package"]
    tmp_dir = tempfile.mkdtemp(prefix="phoneos_update_")
    zip_path = os.path.join(tmp_dir, "update.zip")
    extract_dir = os.path.join(tmp_dir, "extracted")
    backup_dir = os.path.join(config.CACHE_DIR, f"backup_{int(time.time())}")

    try:
        if progress_cb:
            progress_cb("Downloading...")
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            with open(zip_path, "wb") as f:
                shutil.copyfileobj(resp, f)

        if progress_cb:
            progress_cb("Extracting...")
        os.makedirs(extract_dir, exist_ok=True)
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(extract_dir)

        # tolerate a zip that contains a top-level "phoneos/" folder
        src_root = extract_dir
        entries = os.listdir(extract_dir)
        if len(entries) == 1 and os.path.isdir(os.path.join(extract_dir, entries[0])):
            src_root = os.path.join(extract_dir, entries[0])

        new_core = os.path.join(src_root, "core")
        new_apps = os.path.join(src_root, "apps")
        if not os.path.isdir(new_core):
            return False, "Update package missing core/ -- aborted, nothing changed"

        if progress_cb:
            progress_cb("Backing up current install...")
        os.makedirs(backup_dir, exist_ok=True)
        shutil.copytree(config.CORE_DIR, os.path.join(backup_dir, "core"))
        if os.path.isdir(config.APPS_DIR):
            shutil.copytree(config.APPS_DIR, os.path.join(backup_dir, "apps"))
        if os.path.isfile(VERSION_FILE):
            shutil.copy2(VERSION_FILE, os.path.join(backup_dir, "VERSION"))

        if progress_cb:
            progress_cb("Applying update...")
        try:
            shutil.rmtree(config.CORE_DIR)
            shutil.copytree(new_core, config.CORE_DIR)

            if os.path.isdir(new_apps):
                for app_name in os.listdir(new_apps):
                    src = os.path.join(new_apps, app_name)
                    if not os.path.isdir(src):
                        continue
                    dest = os.path.join(config.APPS_DIR, app_name)
                    if os.path.isdir(dest):
                        shutil.rmtree(dest)
                    shutil.copytree(src, dest)

            for top_file in ("boot.py", "requirements.txt", "install.sh"):
                src = os.path.join(src_root, top_file)
                if os.path.isfile(src):
                    shutil.copy2(src, os.path.join(config.ROOT, top_file))

            with open(VERSION_FILE, "w") as f:
                f.write(update_info["version"])

            app_manager.rebuild_db()
        except Exception as e:  # noqa: BLE001 - roll back on any apply failure
            log.error("Update apply failed, rolling back: %s", e)
            _restore_backup(backup_dir)
            return False, f"Update failed and was rolled back: {e}"

        if progress_cb:
            progress_cb("Done")
        return True, f"Updated to version {update_info['version']}"

    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            zipfile.BadZipFile, OSError) as e:
        return False, f"Update failed: {e}"
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _restore_backup(backup_dir):
    try:
        if os.path.isdir(config.CORE_DIR):
            shutil.rmtree(config.CORE_DIR)
        shutil.copytree(os.path.join(backup_dir, "core"), config.CORE_DIR)
        backup_apps = os.path.join(backup_dir, "apps")
        if os.path.isdir(backup_apps):
            if os.path.isdir(config.APPS_DIR):
                shutil.rmtree(config.APPS_DIR)
            shutil.copytree(backup_apps, config.APPS_DIR)
        backup_version = os.path.join(backup_dir, "VERSION")
        if os.path.isfile(backup_version):
            shutil.copy2(backup_version, VERSION_FILE)
        app_manager.rebuild_db()
    except OSError as e:
        log.critical("ROLLBACK FAILED, system may be in a broken state: %s", e)

"""Display backlight brightness control.

Looks for a standard Linux backlight sysfs interface
(/sys/class/backlight/*/brightness). Whether this exists at all depends
on your exact Waveshare panel and driver -- DSI panels controlled via a
GPIO/PWM line rather than a backlight-class driver won't show up here.
When no backlight device is found, set_brightness() is a harmless no-op
so the rest of PhoneOS (and the desktop dev environment) keeps working.
"""
import glob
import logging
import os

log = logging.getLogger("phoneos.display")

_BACKLIGHT_GLOB = "/sys/class/backlight/*"
_path_cache = None


def _find_backlight():
    global _path_cache
    if _path_cache is not None:
        return _path_cache
    candidates = glob.glob(_BACKLIGHT_GLOB)
    _path_cache = candidates[0] if candidates else ""
    return _path_cache


def is_supported():
    return bool(_find_backlight())


def get_max_brightness():
    path = _find_backlight()
    if not path:
        return None
    try:
        with open(os.path.join(path, "max_brightness"), "r") as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


def get_brightness_percent():
    path = _find_backlight()
    if not path:
        return None
    max_b = get_max_brightness()
    if not max_b:
        return None
    try:
        with open(os.path.join(path, "brightness"), "r") as f:
            cur = int(f.read().strip())
        return round(cur / max_b * 100)
    except (OSError, ValueError):
        return None


def set_brightness_percent(percent):
    """Returns True if applied to real hardware, False if unsupported
    (e.g. running on a dev desktop, or a panel without backlight-class
    control) -- callers should treat False as "not an error"."""
    percent = max(1, min(100, int(percent)))
    path = _find_backlight()
    if not path:
        log.info("No backlight device found; brightness setting stored but not applied")
        return False
    max_b = get_max_brightness()
    if not max_b:
        return False
    value = round(max_b * percent / 100)
    try:
        with open(os.path.join(path, "brightness"), "w") as f:
            f.write(str(value))
        return True
    except OSError as e:
        log.warning("Failed to set brightness: %s", e)
        return False

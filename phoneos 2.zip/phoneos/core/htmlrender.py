"""Extremely small HTML->text+links extractor for the PhoneOS Browser.

This is NOT a real HTML5 rendering engine (no CSS, no JS, no layout,
no images) -- a full engine has no realistic path on a Pi Zero. It
strips tags and turns the page into a flow of readable text blocks,
some of which carry a link href, which is the most "basic HTML5
support" that's honestly deliverable on this hardware.
"""
import html
import urllib.parse
from html.parser import HTMLParser

BLOCK_TAGS = {"p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "br", "tr"}
SKIP_TAGS = {"script", "style", "noscript", "svg", "head"}


class _Extractor(HTMLParser):
    def __init__(self, base_url):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.blocks = []  # list of dicts: text, href, heading
        self._buf = ""
        self._href = None
        self._skip_depth = 0
        self._heading = False

    def _flush(self):
        text = " ".join(self._buf.split())
        if text:
            self.blocks.append({"text": text, "href": self._href, "heading": self._heading})
        self._buf = ""

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_TAGS:
            self._skip_depth += 1
            return
        if tag == "a":
            attrs_d = dict(attrs)
            href = attrs_d.get("href")
            if href:
                self._flush()
                self._href = urllib.parse.urljoin(self.base_url, href)
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self._flush()
            self._heading = True
        elif tag in BLOCK_TAGS:
            self._flush()

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        if tag == "a":
            self._flush()
            self._href = None
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self._flush()
            self._heading = False
        elif tag in BLOCK_TAGS:
            self._flush()

    def handle_data(self, data):
        if self._skip_depth:
            return
        self._buf += data

    def close(self):
        super().close()
        self._flush()


def extract_title(raw_html):
    lower = raw_html.lower()
    start = lower.find("<title")
    if start == -1:
        return None
    start = lower.find(">", start)
    end = lower.find("</title>", start)
    if start == -1 or end == -1:
        return None
    return html.unescape(raw_html[start + 1:end]).strip()


def extract_blocks(raw_html, base_url):
    parser = _Extractor(base_url)
    try:
        parser.feed(raw_html)
        parser.close()
    except Exception:  # noqa: BLE001 - malformed HTML shouldn't crash the browser
        pass
    return parser.blocks

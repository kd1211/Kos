"""A tiny blocking Yes/No confirmation dialog any app can call before a
destructive action (delete, uninstall, overwrite, etc).
"""
import pygame

from core import config, touch


def confirm(screen, title, message, confirm_label="Delete", cancel_label="Cancel"):
    """Runs its own short event loop on top of the caller's screen and
    returns True/False once the user taps a button. The caller's own
    event loop is paused for the duration, which is fine since this is
    meant to be called from inside a tap handler, not the main loop."""
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 20)
    font_small = pygame.font.Font(None, 16)
    W, H = config.SCREEN_W, config.SCREEN_H

    box = pygame.Rect(20, H // 2 - 70, W - 40, 140)
    yes_rect = pygame.Rect(box.x + 20, box.bottom - 46, (box.width - 60) // 2, 36)
    no_rect = pygame.Rect(yes_rect.right + 20, box.bottom - 46, (box.width - 60) // 2, 36)

    dim = pygame.Surface((W, H))
    dim.set_alpha(160)
    dim.fill((0, 0, 0))
    background = screen.copy()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                pos = touch.get_pos(event)
                if yes_rect.collidepoint(pos):
                    return True
                if no_rect.collidepoint(pos):
                    return False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return False

        screen.blit(background, (0, 0))
        screen.blit(dim, (0, 0))
        pygame.draw.rect(screen, (28, 28, 34), box, border_radius=10)
        t = font.render(title, True, (255, 255, 255))
        screen.blit(t, (box.x + 16, box.y + 14))
        for i, line in enumerate(_wrap(message, font_small, box.width - 32)):
            m = font_small.render(line, True, (200, 200, 210))
            screen.blit(m, (box.x + 16, box.y + 44 + i * 18))

        pygame.draw.rect(screen, (200, 70, 70), yes_rect, border_radius=6)
        yt = font_small.render(confirm_label, True, (255, 255, 255))
        screen.blit(yt, yt.get_rect(center=yes_rect.center))

        pygame.draw.rect(screen, (60, 60, 68), no_rect, border_radius=6)
        nt = font_small.render(cancel_label, True, (230, 230, 230))
        screen.blit(nt, nt.get_rect(center=no_rect.center))

        pygame.display.flip()
        clock.tick(20)


def _wrap(text, font, max_w):
    words = text.split(" ")
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if font.size(trial)[0] <= max_w:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines[:3] or [""]

"""Backend for the PhoneOS App Store.

Repo layout expected on GitHub (see spec):
    index.json
    apps/       <- .phoneapp zip packages
    icons/
    banners/

index.json schema:
{
  "apps": [
    {
      "id": "com.example.app",
      "name": "Example",
      "version": "1.0.0",
      "description": "...",
      "category": "Tools",
      "package": "apps/example.phoneapp",
      "icon": "icons/example.png",
      "banner": "banners/example.png"
    }
  ]
}

Paths inside index.json are relative to the repo's raw base URL.
"""
import json
import os
import zipfile
import logging
import urllib.request
import urllib.error

from core import config, app_manager

log = logging.getLogger("phoneos.store")

TIMEOUT = 10
USER_AGENT = "PhoneOS-AppStore/1.0"


def _raw_base(repo):
    return f"https://raw.githubusercontent.com/{repo['owner']}/{repo['repo']}/{repo['branch']}/"


def _get(url, timeout=TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


# --------------------------------------------------------------- repos
def load_repos():
    if not os.path.isfile(config.REPOS_FILE):
        save_repos(config.DEFAULT_REPOS)
        return list(config.DEFAULT_REPOS)
    try:
        with open(config.REPOS_FILE, "r") as f:
            data = json.load(f)
        return data.get("repos", list(config.DEFAULT_REPOS))
    except (json.JSONDecodeError, OSError):
        return list(config.DEFAULT_REPOS)


def save_repos(repos):
    os.makedirs(config.SYSTEM_DIR, exist_ok=True)
    with open(config.REPOS_FILE, "w") as f:
        json.dump({"repos": repos}, f, indent=2)


def add_repo(owner, repo, branch="main"):
    repos = load_repos()
    entry = {"owner": owner, "repo": repo, "branch": branch}
    if entry not in repos:
        repos.append(entry)
        save_repos(repos)
    return repos


def remove_repo(owner, repo):
    repos = [r for r in load_repos() if not (r["owner"] == owner and r["repo"] == repo)]
    save_repos(repos)
    return repos


# --------------------------------------------------------------- index
def fetch_index(repo):
    """Fetch and parse index.json for a single repo. Returns list of app
    dicts (each tagged with '_repo' and absolute '_base' url), or None
    on network/parse failure."""
    base = _raw_base(repo)
    try:
        raw = _get(base + "index.json")
        data = json.loads(raw)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError,
            json.JSONDecodeError, OSError) as e:
        log.warning("Failed to fetch index for %s/%s: %s", repo["owner"], repo["repo"], e)
        return None

    apps = data.get("apps", [])
    for a in apps:
        a["_repo"] = f"{repo['owner']}/{repo['repo']}"
        a["_base"] = base
    return apps


def fetch_all(use_cache_on_failure=True):
    """Fetch indexes for all configured repos, merged into one list.
    Caches the last successful combined result so the store is browsable
    offline / on a flaky Pi Zero Wi-Fi connection."""
    repos = load_repos()
    all_apps = []
    any_success = False
    for repo in repos:
        result = fetch_index(repo)
        if result is not None:
            any_success = True
            all_apps.extend(result)

    if any_success:
        os.makedirs(config.CACHE_DIR, exist_ok=True)
        with open(config.STORE_CACHE_FILE, "w") as f:
            json.dump(all_apps, f)
        return all_apps

    if use_cache_on_failure and os.path.isfile(config.STORE_CACHE_FILE):
        try:
            with open(config.STORE_CACHE_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return []


# ---------------------------------------------------------- update check
def installed_versions():
    """Map of app id -> installed version, from installed_apps.json."""
    return {a["id"]: a["version"] for a in app_manager.load_db()}


def check_updates(store_apps=None):
    """Return list of store app dicts that are newer than what's installed."""
    if store_apps is None:
        store_apps = fetch_all()
    installed = installed_versions()
    updates = []
    for app in store_apps:
        cur = installed.get(app["id"])
        if cur is not None and cur != app["version"]:
            updates.append(app)
    return updates


# -------------------------------------------------------- install/remove
def download_package(app, progress_cb=None):
    """Download an app's .phoneapp package to /phoneos/downloads.
    progress_cb(bytes_done, bytes_total) is called periodically if given.
    Returns the local file path, or None on failure."""
    url = app["_base"] + app["package"]
    os.makedirs(config.DOWNLOADS_DIR, exist_ok=True)
    dest = os.path.join(config.DOWNLOADS_DIR, os.path.basename(app["package"]))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            done = 0
            with open(dest, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if progress_cb:
                        progress_cb(done, total)
        return dest
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as e:
        log.error("Download failed for %s: %s", app.get("id"), e)
        return None


def install_app(app, progress_cb=None):
    """Download and install an app from the store. Returns True on success."""
    local_path = download_package(app, progress_cb=progress_cb)
    if not local_path:
        return False
    try:
        dest_dir = os.path.join(config.APPS_DIR, _slug(app["id"]))
        with zipfile.ZipFile(local_path) as z:
            z.extractall(dest_dir)
    except (zipfile.BadZipFile, OSError) as e:
        log.error("Install failed for %s: %s", app.get("id"), e)
        return False
    finally:
        try:
            os.remove(local_path)
        except OSError:
            pass
    app_manager.rebuild_db()
    return True


def uninstall_app(app_id):
    return app_manager.uninstall_app(app_id)


def _slug(app_id):
    return app_id.replace(".", "_")

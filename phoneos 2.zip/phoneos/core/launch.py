"""Lets a running app temporarily hand off the framebuffer to another
app (e.g. Files opening a file in Text Editor or Gallery), the same way
the launcher hands off to apps. Only one process ever owns the display
at a time.
"""
import os
import sys
import subprocess

import pygame

from core import config


def run_app(entry_path, args=None, cwd=None):
    """Quit our own display, run another app's entry point to completion,
    then reinit our display. Returns the new pygame.Surface for the
    caller to keep using as `self.screen`."""
    args = args or []
    cwd = cwd or os.path.dirname(entry_path)
    pygame.display.quit()
    try:
        subprocess.run([sys.executable, entry_path] + list(args), cwd=cwd)
    finally:
        pygame.display.init()
    return pygame.display.set_mode((config.SCREEN_W, config.SCREEN_H))


def texteditor_path():
    return os.path.join(config.APPS_DIR, "texteditor", "main.py")


def gallery_path():
    return os.path.join(config.APPS_DIR, "gallery", "main.py")

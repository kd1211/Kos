#!/usr/bin/env python3
"""PhoneOS Gallery.

Usage: main.py [path/to/folder_or_image]
Defaults to scanning /phoneos/user and /phoneos/wallpapers for images.
Tap a thumbnail to view fullscreen; tap left/right thirds to page
through; tap the middle third or back to return to the grid.
"""
import sys
import os

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch, imaging

W, H = config.SCREEN_W, config.SCREEN_H
EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif")
THUMB = 90
COLS = 3


def find_images(start=None):
    roots = [start] if start else [config.USER_DIR, config.WALLPAPERS_DIR]
    found = []
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        for dirpath, _, filenames in os.walk(root):
            for name in filenames:
                if name.lower().endswith(EXTS):
                    found.append(os.path.join(dirpath, name))
    return sorted(found)


class Gallery:
    def __init__(self, start_path=None):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Gallery")
        self.font = pygame.font.Font(None, 18)
        self.clock = pygame.time.Clock()
        self.running = True
        self.thumbs = {}

        if start_path and os.path.isfile(start_path):
            self.images = [start_path]
            self.view_index = 0
        else:
            self.images = find_images(start_path)
            self.view_index = None
        self.scroll = 0

    def _thumb(self, path):
        if path in self.thumbs:
            return self.thumbs[path]
        img = imaging.load(path, size=(THUMB, THUMB), fit="cover")
        if img is None:
            img = pygame.Surface((THUMB, THUMB))
            img.fill((40, 40, 48))
        self.thumbs[path] = img
        return img

    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 8))

    def draw_grid(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header(f"Gallery ({len(self.images)})")
        if not self.images:
            msg = self.font.render("No images found", True, (150, 150, 160))
            self.screen.blit(msg, msg.get_rect(center=(W // 2, H // 2)))
            return
        margin = 10
        cell = (W - margin * 2) // COLS
        self.thumb_rects = []
        visible_rows = (H - 40) // cell
        start = self.scroll * COLS
        for i, path in enumerate(self.images[start:start + COLS * visible_rows]):
            r, c = divmod(i, COLS)
            x = margin + c * cell
            y = 40 + r * cell
            thumb = self._thumb(path)
            rect = pygame.Rect(x, y, THUMB, THUMB)
            self.screen.blit(thumb, rect)
            self.thumb_rects.append((rect, start + i))

    def draw_viewer(self):
        self.screen.fill((0, 0, 0))
        path = self.images[self.view_index]
        img = imaging.load(path, size=(W - 10, H - 10), fit="contain")
        if img is not None:
            self.screen.blit(img, img.get_rect(center=(W // 2, H // 2)))
        else:
            t = self.font.render("Can't display image", True, (200, 80, 80))
            self.screen.blit(t, t.get_rect(center=(W // 2, H // 2)))
        name = self.font.render(f"{os.path.basename(path)} ({self.view_index + 1}/{len(self.images)})", True, (230, 230, 230))
        self.screen.blit(name, (8, H - 24))

    def handle_grid_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            self.running = False
            return
        for rect, idx in self.thumb_rects:
            if rect.collidepoint(pos):
                self.view_index = idx
                return

    def handle_viewer_tap(self, pos):
        third = W // 3
        if pos[0] < third:
            self.view_index = (self.view_index - 1) % len(self.images)
        elif pos[0] > 2 * third:
            self.view_index = (self.view_index + 1) % len(self.images)
        else:
            self.view_index = None

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.view_index is None:
                        self.handle_grid_tap(pos)
                    else:
                        self.handle_viewer_tap(pos)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.view_index is not None:
                        self.view_index = None
                    else:
                        self.running = False

            if self.view_index is None:
                self.draw_grid()
            else:
                self.draw_viewer()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else None
    Gallery(arg).run()

#!/usr/bin/env python3
"""PhoneOS 2048. Swipe (drag) in a direction, or use arrow keys."""
import sys

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch, gamescores, game2048_logic as logic

W, H = config.SCREEN_W, config.SCREEN_H
GAME_ID = "com.phoneos.game2048"

BOARD_TOP = 90
BOARD_SIZE = W - 20
CELL = BOARD_SIZE // logic.SIZE
SWIPE_THRESHOLD = 24

TILE_COLORS = {
    0: (60, 60, 68), 2: (90, 90, 100), 4: (100, 100, 130), 8: (200, 140, 80),
    16: (210, 120, 70), 32: (220, 100, 70), 64: (230, 80, 60),
    128: (220, 190, 90), 256: (220, 180, 60), 512: (220, 170, 40),
    1024: (220, 160, 20), 2048: (230, 200, 20),
}


class Game2048:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("2048")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 16)
        self.font_tile = pygame.font.Font(None, 28)
        self.clock = pygame.time.Clock()
        self.running = True
        self.high_score = gamescores.get_high_score(GAME_ID)
        self.drag_start = None
        self.reset()

    def reset(self):
        self.board = logic.new_board()
        self.score = 0
        self.game_over = False
        self.won = False
        self.won_dismissed = False

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        s = self.font_small.render(f"Score: {self.score}   Best: {self.high_score}", True, config.FG_COLOR)
        self.screen.blit(s, (44, 10))

    def draw_board(self):
        origin_x = (W - BOARD_SIZE) // 2
        board_rect = pygame.Rect(origin_x, BOARD_TOP, BOARD_SIZE, BOARD_SIZE)
        pygame.draw.rect(self.screen, (30, 30, 36), board_rect, border_radius=8)
        for r in range(logic.SIZE):
            for c in range(logic.SIZE):
                val = self.board[r][c]
                x = origin_x + c * CELL + 4
                y = BOARD_TOP + r * CELL + 4
                rect = pygame.Rect(x, y, CELL - 8, CELL - 8)
                color = TILE_COLORS.get(val, (240, 60, 40))
                pygame.draw.rect(self.screen, color, rect, border_radius=6)
                if val:
                    text_color = (60, 50, 40) if val <= 4 else (255, 255, 255)
                    t = self.font_tile.render(str(val), True, text_color)
                    self.screen.blit(t, t.get_rect(center=rect.center))

    def draw_footer(self):
        self.restart_rect = pygame.Rect(20, BOARD_TOP + BOARD_SIZE + 20, W - 40, 44)
        pygame.draw.rect(self.screen, (40, 40, 48), self.restart_rect, border_radius=8)
        t = self.font.render("New Game", True, config.ACCENT_COLOR)
        self.screen.blit(t, t.get_rect(center=self.restart_rect.center))

    def draw_overlay(self, title):
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.screen.blit(overlay, (0, 0))
        t = self.font.render(title, True, (255, 255, 255))
        self.screen.blit(t, t.get_rect(center=(W // 2, H // 2 - 40)))
        s = self.font_small.render(f"Score: {self.score}   Best: {self.high_score}", True, (220, 220, 220))
        self.screen.blit(s, s.get_rect(center=(W // 2, H // 2 - 10)))

    def do_move(self, direction):
        if self.game_over:
            return
        new_board, gained, moved = logic.move(self.board, direction)
        if not moved:
            return
        self.board = new_board
        self.score += gained
        logic.add_random_tile(self.board)
        if logic.has_won(self.board) and not self.won_dismissed:
            self.won = True
        if not logic.has_moves(self.board):
            self.game_over = True
            if gamescores.submit_score(GAME_ID, self.score):
                self.high_score = self.score

    def handle_tap(self, pos):
        if self.won:
            self.won_dismissed = True
            self.won = False
            return
        if self.back_rect.collidepoint(pos):
            self.running = False
        elif self.restart_rect.collidepoint(pos):
            self.reset()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    self.drag_start = touch.get_pos(event)
                elif event.type in (pygame.MOUSEBUTTONUP, pygame.FINGERUP):
                    self._end_drag(touch.get_pos(event))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        self.do_move("up")
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.do_move("down")
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        self.do_move("left")
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        self.do_move("right")

            self.screen.fill(config.BG_COLOR)
            self.draw_header()
            self.draw_board()
            self.draw_footer()
            if self.game_over:
                self.draw_overlay("Game Over")
            elif self.won:
                self.draw_overlay("You reached 2048!")

            pygame.display.flip()
            self.clock.tick(30)
        pygame.quit()

    def _end_drag(self, end_pos):
        if self.drag_start is None:
            return
        sx, sy = self.drag_start
        ex, ey = end_pos
        dx, dy = ex - sx, ey - sy
        self.drag_start = None

        if abs(dx) < SWIPE_THRESHOLD and abs(dy) < SWIPE_THRESHOLD:
            # treat as a tap, not a swipe
            self.handle_tap((sx, sy))
            return

        if abs(dx) > abs(dy):
            self.do_move("right" if dx > 0 else "left")
        else:
            self.do_move("down" if dy > 0 else "up")


if __name__ == "__main__":
    Game2048().run()

#!/usr/bin/env python3
"""PhoneOS Messages: P2P chat over Wi-Fi using core/p2p.py."""
import sys
import os

sys.path.insert(0, "/phoneos")
import pygame
from core import config, p2p, touch
from core.keyboard import OnScreenKeyboard

W, H = config.SCREEN_W, config.SCREEN_H


class Messages:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Messages")
        self.font = pygame.font.Font(None, 18)
        self.font_small = pygame.font.Font(None, 15)
        self.clock = pygame.time.Clock()
        self.running = True

        self.new_messages = set()
        self.service = p2p.P2PService(on_message=self._on_message)
        self.service.start()

        self.mode = "peers"  # peers | chat
        self.active_peer = None
        self.input_buf = ""
        self.kb = OnScreenKeyboard(W, H)

    def _on_message(self, peer_id, entry):
        if self.active_peer != peer_id:
            self.new_messages.add(peer_id)

    # ------------------------------------------------------------- draw
    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 8))

    def draw_peers(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header(f"Nearby ({self.service.name})")
        peers = self.service.get_peers()
        self.peer_rects = []
        y = 44
        if not peers:
            t = self.font_small.render("Searching for devices on Wi-Fi...", True, (150, 150, 160))
            self.screen.blit(t, (10, y))
            return
        for pid, info in peers.items():
            rect = pygame.Rect(6, y, W - 12, 44)
            color = (30, 46, 34) if pid in self.new_messages else (24, 24, 30)
            pygame.draw.rect(self.screen, color, rect, border_radius=6)
            t = self.font.render(info["name"], True, config.FG_COLOR)
            self.screen.blit(t, (rect.x + 10, rect.y + 8))
            ip = self.font_small.render(info["ip"], True, (140, 140, 150))
            self.screen.blit(ip, (rect.x + 10, rect.y + 26))
            self.peer_rects.append((rect, pid))
            y += 48

    def draw_chat(self):
        self.screen.fill(config.BG_COLOR)
        peers = self.service.get_peers()
        name = peers.get(self.active_peer, {}).get("name", "Unknown (offline)")
        self.draw_header(name)

        conv = p2p.load_conversation(self.active_peer)
        avail_h = self.kb.top - 40
        lines = []
        for entry in conv:
            prefix = "You: " if entry.get("direction") == "out" else f"{entry.get('from_name', name)}: "
            if entry.get("type") == "file":
                text = prefix + f"[file] {entry.get('filename')}"
            else:
                text = prefix + entry.get("text", "")
            lines.extend(self._wrap(text, W - 16))
        visible = avail_h // 18
        y = 40
        for line in lines[-visible:]:
            t = self.font_small.render(line, True, config.FG_COLOR)
            self.screen.blit(t, (8, y))
            y += 18

        input_box = pygame.Rect(6, self.kb.top - 30, W - 70, 26)
        pygame.draw.rect(self.screen, (24, 24, 30), input_box, border_radius=6)
        t = self.font_small.render(self.input_buf[-40:], True, config.FG_COLOR)
        self.screen.blit(t, (input_box.x + 6, input_box.y + 5))
        self.send_rect = pygame.Rect(W - 60, self.kb.top - 30, 54, 26)
        pygame.draw.rect(self.screen, config.ACCENT_COLOR, self.send_rect, border_radius=6)
        st = self.font_small.render("Send", True, (255, 255, 255))
        self.screen.blit(st, st.get_rect(center=self.send_rect.center))

        self.kb.draw(self.screen)

    def _wrap(self, text, max_w):
        words = text.split(" ")
        lines, cur = [], ""
        for w in words:
            trial = (cur + " " + w).strip()
            if self.font_small.size(trial)[0] <= max_w:
                cur = trial
            else:
                if cur:
                    lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines or [""]

    # ----------------------------------------------------------- input
    def handle_peers_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            self.running = False
            return
        for rect, pid in self.peer_rects:
            if rect.collidepoint(pos):
                self.active_peer = pid
                self.new_messages.discard(pid)
                self.mode = "chat"
                return

    def handle_chat_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            self.mode = "peers"
            return
        if self.send_rect.collidepoint(pos):
            self._send()
            return
        result = self.kb.handle_tap(pos)
        if result is None or result == "SHIFT":
            return
        if result == "SPACE":
            self.input_buf += " "
        elif result == "BACKSPACE":
            self.input_buf = self.input_buf[:-1]
        elif result == "ENTER":
            self._send()
        else:
            self.input_buf += result

    def _send(self):
        if self.input_buf.strip() and self.active_peer:
            self.service.send_text(self.active_peer, self.input_buf.strip())
            self.input_buf = ""

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.mode == "peers":
                        self.handle_peers_tap(pos)
                    else:
                        self.handle_chat_tap(pos)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if self.mode == "chat":
                            self.mode = "peers"
                        else:
                            self.running = False
                    elif self.mode == "chat":
                        if event.key == pygame.K_RETURN:
                            self._send()
                        elif event.key == pygame.K_BACKSPACE:
                            self.input_buf = self.input_buf[:-1]
                        elif event.unicode:
                            self.input_buf += event.unicode

            if self.mode == "peers":
                self.draw_peers()
            else:
                self.draw_chat()

            pygame.display.flip()
            self.clock.tick(15)
        self.service.stop()
        pygame.quit()


if __name__ == "__main__":
    Messages().run()

#!/usr/bin/env python3
"""PhoneOS System Updater app."""
import sys
import threading

sys.path.insert(0, "/phoneos")
import pygame
from core import config, updater, touch

W, H = config.SCREEN_W, config.SCREEN_H


class UpdaterApp:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("System Updater")
        self.font = pygame.font.Font(None, 20)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.running = True

        self.local_version = updater.get_local_version()
        self.remote = None
        self.status = "Checking for updates..."
        self.busy = True
        self.progress_text = ""
        self._check_async()

    def _check_async(self):
        self.busy = True
        self.status = "Checking for updates..."

        def worker():
            info = updater.check_update()
            self.remote = info
            if info is None:
                self.status = "Couldn't reach the update server"
            elif updater.is_newer(info["version"], self.local_version):
                self.status = f"Update available: {info['version']}"
            else:
                self.status = "You're up to date"
            self.busy = False

        threading.Thread(target=worker, daemon=True).start()

    def _install_async(self):
        self.busy = True

        def progress(msg):
            self.progress_text = msg

        def worker():
            ok, msg = updater.apply_update(self.remote, progress_cb=progress)
            self.status = msg
            self.local_version = updater.get_local_version()
            self.busy = False
            self.progress_text = ""

        threading.Thread(target=worker, daemon=True).start()

    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 8))

    def draw(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("System Updater")

        y = 50
        t = self.font.render(f"Current version: {self.local_version}", True, config.FG_COLOR)
        self.screen.blit(t, (16, y))
        y += 36

        s = self.font_small.render(self.status, True, (150, 200, 255))
        self.screen.blit(s, (16, y))
        y += 30

        if self.progress_text:
            p = self.font_small.render(self.progress_text, True, (150, 150, 160))
            self.screen.blit(p, (16, y))
            y += 30

        self.check_rect = pygame.Rect(16, H - 120, W - 32, 44)
        self.install_rect = None
        if not self.busy:
            pygame.draw.rect(self.screen, (40, 40, 48), self.check_rect, border_radius=8)
            ct = self.font.render("Check Again", True, config.ACCENT_COLOR)
            self.screen.blit(ct, ct.get_rect(center=self.check_rect.center))

            if self.remote and updater.is_newer(self.remote["version"], self.local_version):
                self.install_rect = pygame.Rect(16, H - 66, W - 32, 44)
                pygame.draw.rect(self.screen, config.ACCENT_COLOR, self.install_rect, border_radius=8)
                it = self.font.render(f"Install {self.remote['version']}", True, (255, 255, 255))
                self.screen.blit(it, it.get_rect(center=self.install_rect.center))

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.back_rect.collidepoint(pos):
                        self.running = False
                    elif not self.busy and self.check_rect.collidepoint(pos):
                        self._check_async()
                    elif not self.busy and self.install_rect and self.install_rect.collidepoint(pos):
                        self._install_async()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            self.draw()
            pygame.display.flip()
            self.clock.tick(15)
        pygame.quit()


if __name__ == "__main__":
    UpdaterApp().run()

#!/usr/bin/env python3
"""PhoneOS Terminal: runs shell commands via subprocess, with a shared
on-screen keyboard for touch input (a real keyboard also works if
attached via USB/Bluetooth)."""
import sys
import os
import subprocess

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch
from core.keyboard import OnScreenKeyboard

W, H = config.SCREEN_W, config.SCREEN_H


class Terminal:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Terminal")
        self.font = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.lines = ["PhoneOS Terminal", "$ "]
        self.input_buf = ""
        self.cwd = os.path.expanduser("~")
        self.running = True
        self.kb = OnScreenKeyboard(W, H)

    def run_command(self, cmd):
        self.lines[-1] = "$ " + cmd
        if cmd.strip() == "clear":
            self.lines = ["$ "]
            return
        if cmd.strip().startswith("cd"):
            parts = cmd.strip().split(maxsplit=1)
            target = parts[1] if len(parts) > 1 else os.path.expanduser("~")
            target = os.path.join(self.cwd, target) if not target.startswith("/") else target
            if os.path.isdir(target):
                self.cwd = os.path.abspath(target)
            else:
                self.lines.append(f"cd: no such directory: {target}")
            self.lines.append("$ ")
            return
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=self.cwd, capture_output=True,
                text=True, timeout=15,
            )
            out = (result.stdout + result.stderr).strip()
        except subprocess.TimeoutExpired:
            out = "(timed out)"
        except OSError as e:
            out = str(e)
        for line in out.splitlines()[-100:]:
            self.lines.append(line)
        self.lines.append("$ ")

    def draw(self):
        self.screen.fill((8, 8, 10))
        avail_h = self.kb.top - 8
        visible = max(1, avail_h // 16)
        history = self.lines[:-1][-visible:]
        y = 4
        for line in history:
            t = self.font.render(line[:52], True, (120, 230, 120))
            self.screen.blit(t, (4, y))
            y += 16
        cur = self.lines[-1] + self.input_buf
        t = self.font.render(cur[-52:], True, (255, 255, 255))
        self.screen.blit(t, (4, y))

        self.kb.draw(self.screen)

    def handle_key_event(self, result):
        if result is None or result == "SHIFT":
            return
        if result == "SPACE":
            self.input_buf += " "
        elif result == "BACKSPACE":
            self.input_buf = self.input_buf[:-1]
        elif result == "ENTER":
            cmd = self.input_buf
            self.input_buf = ""
            self.run_command(cmd)
        else:
            self.input_buf += result

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    self.handle_key_event(self.kb.handle_tap(pos))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key == pygame.K_RETURN:
                        cmd = self.input_buf
                        self.input_buf = ""
                        self.run_command(cmd)
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_buf = self.input_buf[:-1]
                    elif event.unicode:
                        self.input_buf += event.unicode

            self.draw()
            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    Terminal().run()

#!/usr/bin/env python3
"""PhoneOS App Store.

Fetches index.json from each configured GitHub repo (see core/store.py
for the expected repo layout), lists apps with install/update/uninstall,
and supports adding new repos via an on-screen keyboard.

Network calls run on a background thread so the UI stays responsive on
a Pi Zero over a slow Wi-Fi connection.
"""
import sys
import os
import threading

sys.path.insert(0, "/phoneos")
import pygame
from core import config, store, dialog, touch
from core.keyboard import OnScreenKeyboard

W, H = config.SCREEN_W, config.SCREEN_H
ROW_H = 56
TABS = ["All", "Installed", "Updates"]


class AppStore:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("App Store")
        self.font = pygame.font.Font(None, 20)
        self.font_small = pygame.font.Font(None, 16)
        self.font_big = pygame.font.Font(None, 24)
        self.clock = pygame.time.Clock()
        self.running = True

        self.tab = "All"
        self.scroll = 0
        self.status = "Loading..."
        self.apps = []
        self.updates = []
        self.detail_app = None
        self.installing = None  # (app, progress_str)
        self.adding_repo = False
        self.repo_input = ""
        self.kb = OnScreenKeyboard(W, H, font=self.font_small)

        self._refresh_async()

    # ------------------------------------------------------------ data
    def _refresh_async(self):
        self.status = "Refreshing..."

        def worker():
            apps = store.fetch_all()
            self.apps = apps
            self.updates = store.check_updates(apps)
            self.status = "" if apps else "No apps found (check network / repos)"

        threading.Thread(target=worker, daemon=True).start()

    def _current_list(self):
        installed_ids = set(store.installed_versions().keys())
        if self.tab == "All":
            return self.apps
        if self.tab == "Installed":
            return [a for a in self.apps if a["id"] in installed_ids]
        if self.tab == "Updates":
            return self.updates
        return []

    def _install_async(self, app):
        self.installing = [app, "0%"]

        def progress(done, total):
            pct = int(done / total * 100) if total else 0
            self.installing[1] = f"{pct}%"

        def worker():
            ok = store.install_app(app, progress_cb=progress)
            self.installing = None
            self.status = f"Installed {app['name']}" if ok else f"Install failed: {app['name']}"
            self.updates = store.check_updates(self.apps)

        threading.Thread(target=worker, daemon=True).start()

    def _uninstall(self, app):
        ok = store.uninstall_app(app["id"])
        self.status = f"Removed {app['name']}" if ok else "Uninstall failed"
        self.updates = store.check_updates(self.apps)

    # ---------------------------------------------------------- drawing
    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 6))
        self.refresh_rect = pygame.Rect(W - 40, 0, 40, 36)
        r = self.font.render("↻", True, config.ACCENT_COLOR)
        self.screen.blit(r, (W - 32, 4))

    def draw_tabs(self):
        self.tab_rects = []
        tw = W // len(TABS)
        for i, name in enumerate(TABS):
            rect = pygame.Rect(i * tw, 36, tw, 30)
            color = config.ACCENT_COLOR if name == self.tab else (24, 24, 30)
            pygame.draw.rect(self.screen, color, rect)
            t = self.font_small.render(name, True, (255, 255, 255))
            self.screen.blit(t, t.get_rect(center=rect.center))
            self.tab_rects.append((rect, name))

    def draw_list(self):
        installed = store.installed_versions()
        items = self._current_list()
        self.row_rects = []
        y = 70
        visible = (H - 70) // ROW_H
        for app in items[self.scroll:self.scroll + visible]:
            rect = pygame.Rect(6, y, W - 12, ROW_H - 6)
            pygame.draw.rect(self.screen, (24, 24, 30), rect, border_radius=6)
            name = self.font.render(app["name"][:22], True, config.FG_COLOR)
            self.screen.blit(name, (rect.x + 10, rect.y + 6))
            meta = f"v{app['version']}  ·  {app.get('category', 'App')}"
            m = self.font_small.render(meta, True, (150, 150, 160))
            self.screen.blit(m, (rect.x + 10, rect.y + 28))

            cur_ver = installed.get(app["id"])
            if cur_ver is None:
                label, color = "Install", config.ACCENT_COLOR
            elif cur_ver != app["version"]:
                label, color = "Update", (255, 170, 60)
            else:
                label, color = "Remove", (200, 70, 70)
            btn = pygame.Rect(rect.right - 90, rect.y + 12, 80, 30)
            pygame.draw.rect(self.screen, color, btn, border_radius=6)
            bt = self.font_small.render(label, True, (255, 255, 255))
            self.screen.blit(bt, bt.get_rect(center=btn.center))
            self.row_rects.append((rect, btn, app, label))
            y += ROW_H

        if self.status:
            s = self.font_small.render(self.status, True, (150, 150, 160))
            self.screen.blit(s, (10, H - 20))

    def draw_repo_input(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Add Repo (owner/repo)")
        box = pygame.Rect(10, 50, W - 20, 34)
        pygame.draw.rect(self.screen, (24, 24, 30), box, border_radius=6)
        t = self.font.render(self.repo_input or "owner/repo", True, config.FG_COLOR)
        self.screen.blit(t, (box.x + 8, box.y + 6))
        hint = self.font_small.render("Type then tap enter to add", True, (150, 150, 160))
        self.screen.blit(hint, (10, 92))
        self.kb.draw(self.screen)

    def draw_main(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("App Store")
        self.draw_tabs()
        self.draw_list()
        add_repo_rect = pygame.Rect(W - 130, H - 34, 120, 28)
        pygame.draw.rect(self.screen, (40, 40, 48), add_repo_rect, border_radius=6)
        t = self.font_small.render("+ Add Repo", True, config.ACCENT_COLOR)
        self.screen.blit(t, t.get_rect(center=add_repo_rect.center))
        self.add_repo_rect = add_repo_rect

        if self.installing:
            app, pct = self.installing
            overlay = pygame.Rect(20, H // 2 - 30, W - 40, 60)
            pygame.draw.rect(self.screen, (24, 24, 30), overlay, border_radius=8)
            t = self.font.render(f"Installing {app['name']}... {pct}", True, config.FG_COLOR)
            self.screen.blit(t, t.get_rect(center=overlay.center))

    # ---------------------------------------------------------- events
    def handle_tap(self, pos):
        if self.adding_repo:
            if self.back_rect.collidepoint(pos):
                self.adding_repo = False
                return
            result = self.kb.handle_tap(pos)
            if result in (None, "SHIFT"):
                return
            if result == "SPACE":
                pass  # repo names don't need spaces
            elif result == "BACKSPACE":
                self.repo_input = self.repo_input[:-1]
            elif result == "ENTER":
                if "/" in self.repo_input:
                    owner, repo = self.repo_input.split("/", 1)
                    store.add_repo(owner.strip(), repo.strip())
                    self.adding_repo = False
                    self.repo_input = ""
                    self._refresh_async()
            else:
                self.repo_input += result
            return

        if self.back_rect.collidepoint(pos):
            self.running = False
            return
        if self.refresh_rect.collidepoint(pos):
            self._refresh_async()
            return
        if self.add_repo_rect.collidepoint(pos):
            self.adding_repo = True
            return
        for rect, name in self.tab_rects:
            if rect.collidepoint(pos):
                self.tab = name
                self.scroll = 0
                return
        for rect, btn, app, label in self.row_rects:
            if btn.collidepoint(pos):
                if label in ("Install", "Update"):
                    if not self.installing:
                        self._install_async(app)
                elif label == "Remove":
                    if dialog.confirm(
                        self.screen, "Remove app?",
                        f"Uninstall \"{app['name']}\"? Its files will be deleted.",
                        confirm_label="Remove",
                    ):
                        self._uninstall(app)
                return

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    self.handle_tap(pos)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.adding_repo:
                        self.adding_repo = False
                    else:
                        self.running = False

            if self.adding_repo:
                self.draw_repo_input()
            else:
                self.draw_main()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    AppStore().run()

#!/usr/bin/env python3
"""PhoneOS Settings app. Single-screen list of toggles/pages, tap
back arrow (top-left) or ESC to return to the launcher."""
import sys
import os
import subprocess

sys.path.insert(0, "/phoneos")
import pygame
from core import config, settings, battery, netstatus, app_manager, launch, display, touch, lock
from core.numpad import NumPad

W, H = config.SCREEN_W, config.SCREEN_H


class SettingsApp:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Settings")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.settings = settings.load()
        self.page = "main"
        self.running = True

        self.numpad = NumPad(W, H)
        self.security_flow = None  # None | 'new1' | 'new2' | 'remove'
        self._new_pin_first = None
        self._pin_buffer = ""
        self._security_message = ""
        self._security_error = False

    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)

    def row(self, y, text, value=None):
        rect = pygame.Rect(10, y, W - 20, 40)
        pygame.draw.rect(self.screen, (24, 24, 30), rect, border_radius=6)
        t = self.font.render(text, True, config.FG_COLOR)
        self.screen.blit(t, (rect.x + 10, rect.y + 10))
        if value is not None:
            v = self.font_small.render(str(value), True, config.ACCENT_COLOR)
            self.screen.blit(v, (rect.right - v.get_width() - 10, rect.y + 12))
        return rect

    def draw_main(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Settings")
        y = 46
        self.rows = {}
        wifi_connected, ssid = netstatus.wifi_status()
        self.rows["wifi"] = self.row(y, "Wi-Fi", ssid or ("On" if wifi_connected else "Off"))
        y += 46
        self.rows["bluetooth"] = self.row(y, "Bluetooth", "On" if netstatus.bluetooth_status() else "Off")
        y += 46
        b = battery.read()
        self.rows["battery"] = self.row(y, "Battery", f"{b['percent']}%")
        y += 46
        self.rows["display"] = self.row(y, "Display", f"{self.settings['brightness']}%")
        y += 46
        self.rows["security"] = self.row(y, "Security", "PIN set" if lock.is_pin_set() else "Not set")
        y += 46
        self.rows["storage"] = self.row(y, "Storage", "")
        y += 46
        self.rows["apps"] = self.row(y, "Installed Apps", str(len(app_manager.load_db())))
        y += 46
        self.rows["updates"] = self.row(y, "Updates", "")
        y += 46
        self.rows["developer"] = self.row(y, "Developer Mode", "On" if self.settings["developer_mode"] else "Off")
        y += 46
        self.rows["about"] = self.row(y, "About", "")

    def draw_battery_detail(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Battery")
        b = battery.read()
        lines = [
            f"Percent: {b['percent']}%",
            f"Charging: {'Yes' if b['charging'] else 'No'}",
            f"Voltage: {b['voltage']} V",
            f"Current: {b['current_ma']} mA",
            f"Power: {b['power_w']} W",
            f"Est. runtime: {b['runtime_min']} min" if b["runtime_min"] else "Est. runtime: --",
        ]
        y = 50
        for line in lines:
            t = self.font.render(line, True, config.FG_COLOR)
            self.screen.blit(t, (16, y))
            y += 30

    def draw_about(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("About")
        lines = ["PhoneOS", "Version 0.1.0", "Raspberry Pi Zero build"]
        y = 50
        for line in lines:
            t = self.font.render(line, True, config.FG_COLOR)
            self.screen.blit(t, (16, y))
            y += 30

    def draw_developer(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Developer Mode")
        state = "On" if self.settings["developer_mode"] else "Off"
        self.rows = {"toggle": self.row(50, "Developer Mode", state)}

    TIMEOUT_OPTIONS = [30, 60, 120, 300, 0]  # 0 = never

    def draw_display(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Display")

        y = 50
        bright_rect = pygame.Rect(10, y, W - 20, 50)
        pygame.draw.rect(self.screen, (24, 24, 30), bright_rect, border_radius=6)
        label = self.font.render("Brightness", True, config.FG_COLOR)
        self.screen.blit(label, (bright_rect.x + 10, bright_rect.y + 8))
        val = self.font_small.render(f"{self.settings['brightness']}%", True, config.ACCENT_COLOR)
        self.screen.blit(val, (bright_rect.centerx - 10, bright_rect.y + 28))
        self.minus_rect = pygame.Rect(bright_rect.x + 10, bright_rect.y + 8, 30, 30)
        self.plus_rect = pygame.Rect(bright_rect.right - 40, bright_rect.y + 8, 30, 30)
        pygame.draw.rect(self.screen, (50, 50, 58), self.minus_rect, border_radius=6)
        pygame.draw.rect(self.screen, (50, 50, 58), self.plus_rect, border_radius=6)
        self.screen.blit(self.font.render("-", True, config.FG_COLOR), (self.minus_rect.x + 11, self.minus_rect.y + 3))
        self.screen.blit(self.font.render("+", True, config.FG_COLOR), (self.plus_rect.x + 8, self.plus_rect.y + 3))
        if not display.is_supported():
            note = self.font_small.render("(no backlight device detected on this hardware)", True, (140, 140, 150))
            self.screen.blit(note, (10, bright_rect.bottom + 2))
        y = bright_rect.bottom + 24

        timeout = self.settings.get("screen_timeout_sec", 60)
        timeout_label = "Never" if timeout == 0 else f"{timeout}s"
        self.timeout_rect = self.row(y, "Screen Timeout", timeout_label)
        y += 56

        self.calibrate_rect = pygame.Rect(10, y, W - 20, 44)
        pygame.draw.rect(self.screen, config.ACCENT_COLOR, self.calibrate_rect, border_radius=8)
        ct = self.font.render("Calibrate Touchscreen", True, (255, 255, 255))
        self.screen.blit(ct, ct.get_rect(center=self.calibrate_rect.center))
        y += 56

        self.reset_cal_rect = pygame.Rect(10, y, W - 20, 40)
        pygame.draw.rect(self.screen, (50, 30, 30), self.reset_cal_rect, border_radius=8)
        rt = self.font_small.render("Reset Calibration to Default", True, (255, 160, 160))
        self.screen.blit(rt, rt.get_rect(center=self.reset_cal_rect.center))

    def _adjust_brightness(self, delta):
        self.settings["brightness"] = max(10, min(100, self.settings["brightness"] + delta))
        settings.save(self.settings)
        display.set_brightness_percent(self.settings["brightness"])

    def _cycle_timeout(self):
        current = self.settings.get("screen_timeout_sec", 60)
        options = self.TIMEOUT_OPTIONS
        idx = options.index(current) if current in options else 1
        self.settings["screen_timeout_sec"] = options[(idx + 1) % len(options)]
        settings.save(self.settings)

    # ------------------------------------------------------------ security
    def draw_security(self):
        self.screen.fill(config.BG_COLOR)
        if self.security_flow is not None:
            self.draw_header("Security")
            self.draw_pin_entry_prompt()
            self.numpad.draw(self.screen)
            return

        self.draw_header("Security")
        y = 50
        self.rows = {}
        pin_set = lock.is_pin_set()
        self.rows["set_pin"] = self.row(y, "Change PIN" if pin_set else "Set PIN")
        y += 46
        if pin_set:
            self.rows["remove_pin"] = self.row(y, "Remove PIN")
            y += 46
            self.rows["lock_on_wake"] = self.row(
                y, "Lock on Wake", "On" if lock.lock_on_wake_enabled() else "Off"
            )
            y += 46
        if self._security_message:
            msg = self.font_small.render(
                self._security_message, True,
                (255, 140, 140) if self._security_error else (150, 220, 150),
            )
            self.screen.blit(msg, (16, y + 6))

    def draw_pin_entry_prompt(self):
        prompts = {
            "new1": "Enter a new PIN (4-8 digits)",
            "new2": "Re-enter the new PIN to confirm",
            "remove": "Enter your current PIN to remove it",
        }
        label = self.font_small.render(prompts.get(self.security_flow, ""), True, (150, 150, 160))
        self.screen.blit(label, label.get_rect(center=(W // 2, 60)))

        dot_color = (220, 90, 90) if self._security_error else config.ACCENT_COLOR
        n = len(self._pin_buffer)
        start_x = W // 2 - (n * 22) // 2
        for i in range(n):
            pygame.draw.circle(self.screen, dot_color, (start_x + i * 22 + 11, 96), 7)

    def _start_set_pin(self):
        self.security_flow = "new1"
        self._pin_buffer = ""
        self._new_pin_first = None
        self._security_error = False
        self._security_message = ""

    def _start_remove_pin(self):
        self.security_flow = "remove"
        self._pin_buffer = ""
        self._security_error = False
        self._security_message = ""

    def _handle_security_numpad(self, pos):
        key = self.numpad.handle_tap(pos)
        if key is None:
            return
        if key == "DEL":
            self._pin_buffer = self._pin_buffer[:-1]
            self._security_error = False
            return
        if key == "OK":
            self._submit_pin_entry()
            return
        if len(self._pin_buffer) < lock.MAX_PIN_LEN:
            self._pin_buffer += key
            self._security_error = False

    def _submit_pin_entry(self):
        if self.security_flow == "new1":
            if len(self._pin_buffer) < lock.MIN_PIN_LEN:
                self._security_error = True
                return
            self._new_pin_first = self._pin_buffer
            self._pin_buffer = ""
            self.security_flow = "new2"
        elif self.security_flow == "new2":
            if self._pin_buffer != self._new_pin_first:
                self._security_error = True
                self._pin_buffer = ""
                self.security_flow = "new1"
                self._security_message = "PINs didn't match, try again"
                return
            ok, err = lock.set_pin(self._pin_buffer)
            self.security_flow = None
            self._pin_buffer = ""
            self._security_error = not ok
            self._security_message = "PIN set" if ok else err
        elif self.security_flow == "remove":
            if lock.verify_pin(self._pin_buffer):
                lock.clear()
                self.security_flow = None
                self._pin_buffer = ""
                self._security_message = "PIN removed"
                self._security_error = False
            else:
                self._security_error = True
                self._pin_buffer = ""

    def handle_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            if self.page == "security" and self.security_flow is not None:
                self.security_flow = None
                self._pin_buffer = ""
                self._security_error = False
            elif self.page == "main":
                self.running = False
            else:
                self.page = "main"
            return
        if self.page == "main":
            for key, rect in self.rows.items():
                if rect.collidepoint(pos):
                    if key in ("battery", "about", "developer", "display", "security"):
                        self.page = key
                    elif key == "wifi":
                        subprocess.run(["nmcli", "radio", "wifi"], capture_output=True)
                    elif key == "updates":
                        updater_path = os.path.join(config.APPS_DIR, "updater", "main.py")
                        self.screen = launch.run_app(updater_path)
                    return
        elif self.page == "developer":
            if self.rows["toggle"].collidepoint(pos):
                self.settings["developer_mode"] = not self.settings["developer_mode"]
                settings.save(self.settings)
        elif self.page == "display":
            if self.minus_rect.collidepoint(pos):
                self._adjust_brightness(-10)
            elif self.plus_rect.collidepoint(pos):
                self._adjust_brightness(10)
            elif self.timeout_rect.collidepoint(pos):
                self._cycle_timeout()
            elif self.calibrate_rect.collidepoint(pos):
                cal_path = os.path.join(config.APPS_DIR, "calibration", "main.py")
                self.screen = launch.run_app(cal_path)
            elif self.reset_cal_rect.collidepoint(pos):
                touch.reset_calibration()
        elif self.page == "security":
            if self.security_flow is not None:
                self._handle_security_numpad(pos)
                return
            for key, rect in self.rows.items():
                if rect.collidepoint(pos):
                    if key == "set_pin":
                        self._start_set_pin()
                    elif key == "remove_pin":
                        self._start_remove_pin()
                    elif key == "lock_on_wake":
                        lock.set_lock_on_wake(not lock.lock_on_wake_enabled())
                    return

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    self.handle_tap(touch.get_pos(event))
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            if self.page == "main":
                self.draw_main()
            elif self.page == "battery":
                self.draw_battery_detail()
            elif self.page == "about":
                self.draw_about()
            elif self.page == "developer":
                self.draw_developer()
            elif self.page == "display":
                self.draw_display()
            elif self.page == "security":
                self.draw_security()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    SettingsApp().run()

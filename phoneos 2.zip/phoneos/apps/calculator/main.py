#!/usr/bin/env python3
"""PhoneOS Calculator: touch-button 4-function calculator."""
import sys
import ast
import operator

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch

W, H = config.SCREEN_W, config.SCREEN_H

BUTTONS = [
    ["7", "8", "9", "/"],
    ["4", "5", "6", "*"],
    ["1", "2", "3", "-"],
    ["C", "0", "=", "+"],
]

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.USub: operator.neg}


def safe_eval(expr):
    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
        if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
            return _OPS[type(node.op)](_eval(node.operand))
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("invalid expression")
    return _eval(ast.parse(expr, mode="eval"))


def main():
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Calculator")
    font_disp = pygame.font.Font(None, 48)
    font_btn = pygame.font.Font(None, 32)
    clock = pygame.time.Clock()

    expr = ""
    display = "0"
    running = True

    disp_rect = pygame.Rect(10, 40, W - 20, 70)
    btn_h = 70
    btn_top = 130
    btn_rects = []
    for r, row in enumerate(BUTTONS):
        for c, label in enumerate(row):
            rect = pygame.Rect(10 + c * ((W - 20) // 4), btn_top + r * btn_h, (W - 20) // 4 - 4, btn_h - 4)
            btn_rects.append((rect, label))

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                pos = touch.get_pos(event)
                for rect, label in btn_rects:
                    if rect.collidepoint(pos):
                        if label == "C":
                            expr = ""
                            display = "0"
                        elif label == "=":
                            try:
                                result = safe_eval(expr)
                                display = str(result)
                                expr = display
                            except (ValueError, ZeroDivisionError, SyntaxError):
                                display = "Error"
                                expr = ""
                        else:
                            expr += label
                            display = expr
                        break

        screen.fill(config.BG_COLOR)
        pygame.draw.rect(screen, (24, 24, 30), disp_rect, border_radius=6)
        t = font_disp.render(display[-14:], True, config.FG_COLOR)
        screen.blit(t, t.get_rect(midright=(disp_rect.right - 10, disp_rect.centery)))

        for rect, label in btn_rects:
            color = config.ACCENT_COLOR if label in "/*-+=" else (40, 40, 48)
            pygame.draw.rect(screen, color, rect, border_radius=8)
            bt = font_btn.render(label, True, (255, 255, 255))
            screen.blit(bt, bt.get_rect(center=rect.center))

        pygame.display.flip()
        clock.tick(20)
    pygame.quit()


if __name__ == "__main__":
    main()

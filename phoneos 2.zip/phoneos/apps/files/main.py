#!/usr/bin/env python3
"""PhoneOS Files app: browse, create folders, rename, delete, move/copy
(via a lightweight clipboard), view text files, and install .phoneapp
packages by tapping them."""
import sys
import os
import shutil
import zipfile

sys.path.insert(0, "/phoneos")
import pygame
from core import config, launch, dialog, touch
from core.toast import Toast

W, H = config.SCREEN_W, config.SCREEN_H
ROW_H = 40
VISIBLE_ROWS = (H - 80) // ROW_H
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif")
TEXT_EXTS = (".txt", ".json", ".py", ".md", ".log")


class FilesApp:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Files")
        self.font = pygame.font.Font(None, 20)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.path = config.USER_DIR if os.path.isdir(config.USER_DIR) else os.path.expanduser("~")
        self.scroll = 0
        self.clipboard = None  # (path, mode) mode = 'copy'|'move'
        self.message = ""
        self.toast = Toast()
        self.text_view = None
        self.running = True

    def entries(self):
        try:
            names = sorted(os.listdir(self.path))
        except OSError:
            return []
        dirs = [n for n in names if os.path.isdir(os.path.join(self.path, n))]
        files = [n for n in names if not os.path.isdir(os.path.join(self.path, n))]
        return [(".. (up)", "up")] + [(d, "dir") for d in dirs] + [(f, "file") for f in files]

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        t = self.font_small.render(self.path, True, config.FG_COLOR)
        self.screen.blit(t, (8, 10))

    def draw_list(self):
        items = self.entries()
        self.row_rects = []
        y = 40
        for name, kind in items[self.scroll:self.scroll + VISIBLE_ROWS]:
            rect = pygame.Rect(4, y, W - 8, ROW_H - 4)
            color = (30, 30, 38) if kind != "dir" else (26, 34, 46)
            pygame.draw.rect(self.screen, color, rect, border_radius=4)
            label = ("[DIR] " if kind == "dir" else "") + name
            t = self.font.render(label[:38], True, config.FG_COLOR)
            self.screen.blit(t, (rect.x + 8, rect.y + 8))
            self.row_rects.append((rect, name, kind))
            y += ROW_H

    def draw_footer(self):
        bar = pygame.Rect(0, H - 40, W, 40)
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, bar)
        labels = ["New", "Copy", "Move", "Del", "Paste"]
        self.footer_rects = []
        bw = W // len(labels)
        for i, label in enumerate(labels):
            r = pygame.Rect(i * bw, H - 40, bw, 40)
            t = self.font_small.render(label, True, config.ACCENT_COLOR)
            trect = t.get_rect(center=r.center)
            self.screen.blit(t, trect)
            self.footer_rects.append((r, label))

    def draw_message(self):
        if self.message:
            t = self.font_small.render(self.message, True, (255, 180, 80))
            self.screen.blit(t, (8, H - 60))
        self.toast.draw(self.screen, self.font_small)

    def open_entry(self, name, kind):
        full = os.path.join(self.path, name)
        if kind == "up":
            self.path = os.path.dirname(self.path.rstrip("/")) or "/"
            self.scroll = 0
        elif kind == "dir":
            self.path = full
            self.scroll = 0
        else:
            lower = name.lower()
            if name.endswith(".phoneapp"):
                self.install_phoneapp(full)
            elif lower.endswith(TEXT_EXTS):
                self.screen = launch.run_app(launch.texteditor_path(), args=[full])
            elif lower.endswith(IMAGE_EXTS):
                self.screen = launch.run_app(launch.gallery_path(), args=[full])
            else:
                self.message = f"Can't open {name}"

    def view_text(self, path):
        try:
            with open(path, "r", errors="replace") as f:
                content = f.read(4000)
        except OSError as e:
            self.message = f"Error: {e}"
            return
        self.text_view = content

    def install_phoneapp(self, path):
        try:
            dest_name = os.path.splitext(os.path.basename(path))[0]
            dest = os.path.join(config.APPS_DIR, dest_name)
            with zipfile.ZipFile(path) as z:
                z.extractall(dest)
            from core import app_manager
            app_manager.rebuild_db()
            self.message = f"Installed {dest_name}"
        except (zipfile.BadZipFile, OSError) as e:
            self.message = f"Install failed: {e}"

    def handle_footer(self, label, selected):
        if label == "New":
            base = "New Folder"
            name, i = base, 1
            while os.path.exists(os.path.join(self.path, name)):
                i += 1
                name = f"{base} {i}"
            os.makedirs(os.path.join(self.path, name), exist_ok=True)
        elif label == "Copy" and selected:
            self.clipboard = (os.path.join(self.path, selected[1]), "copy")
            self.toast.show(f"Copied {selected[1]}")
        elif label == "Move" and selected:
            self.clipboard = (os.path.join(self.path, selected[1]), "move")
            self.toast.show(f"Cut {selected[1]}")
        elif label == "Del" and selected:
            name = selected[1]
            if not dialog.confirm(
                self.screen, "Delete?", f"Delete \"{name}\"? This can't be undone.",
                confirm_label="Delete",
            ):
                self.message = "Cancelled"
                return
            full = os.path.join(self.path, name)
            try:
                if os.path.isdir(full):
                    shutil.rmtree(full)
                else:
                    os.remove(full)
                self.toast.show(f"Deleted {name}")
            except OSError as e:
                self.toast.show(f"Error: {e}", color=(255, 120, 120))
        elif label == "Paste" and self.clipboard:
            src, mode = self.clipboard
            dest = os.path.join(self.path, os.path.basename(src))
            try:
                if mode == "copy":
                    (shutil.copytree if os.path.isdir(src) else shutil.copy2)(src, dest)
                else:
                    shutil.move(src, dest)
                    self.clipboard = None
                self.toast.show("Pasted")
            except OSError as e:
                self.toast.show(f"Error: {e}", color=(255, 120, 120))

    def run(self):
        selected = None
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.text_view is not None:
                        self.text_view = None
                    else:
                        self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    if self.text_view is not None:
                        self.text_view = None
                        continue
                    for rect, name, kind in self.row_rects:
                        if rect.collidepoint(pos):
                            if selected and selected[1] == name:
                                self.open_entry(name, kind)
                                selected = None
                            else:
                                selected = (self.path, name, kind)
                            break
                    else:
                        for r, label in self.footer_rects:
                            if r.collidepoint(pos):
                                sel = (selected[1], selected[2]) if selected else None
                                self.handle_footer(label, sel)
                                break

            self.screen.fill(config.BG_COLOR)
            if self.text_view is not None:
                self.draw_header()
                y = 44
                for line in self.text_view.splitlines()[:20]:
                    t = self.font_small.render(line[:50], True, config.FG_COLOR)
                    self.screen.blit(t, (8, y))
                    y += 18
            else:
                self.draw_header()
                self.draw_list()
                self.draw_footer()
                self.draw_message()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    FilesApp().run()

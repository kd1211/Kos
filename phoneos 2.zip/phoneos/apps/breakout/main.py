#!/usr/bin/env python3
"""PhoneOS Breakout. Drag your finger/mouse left-right to move the paddle."""
import sys
import random

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch, gamescores

W, H = config.SCREEN_W, config.SCREEN_H
GAME_ID = "com.phoneos.breakout"

HEADER_H = 36
BRICK_ROWS = 5
BRICK_COLS = 8
BRICK_W = 36
BRICK_H = 14
BRICK_GAP = 4
BRICK_TOP = HEADER_H + 10
BRICK_MARGIN_X = (W - (BRICK_COLS * BRICK_W + (BRICK_COLS - 1) * BRICK_GAP)) // 2

PADDLE_W = 60
PADDLE_H = 10
PADDLE_Y = H - 40
BALL_RADIUS = 5
BALL_SPEED = 4.2

ROW_COLORS = [(220, 90, 90), (230, 150, 80), (230, 210, 80), (140, 210, 100), (100, 160, 230)]


class Breakout:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Breakout")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.running = True
        self.high_score = gamescores.get_high_score(GAME_ID)
        self._paddle_rect = pygame.Rect(0, 0, PADDLE_W, PADDLE_H)
        self.reset()

    def reset(self):
        self.bricks = {
            (r, c) for r in range(BRICK_ROWS) for c in range(BRICK_COLS)
        }
        self.paddle_x = W // 2
        self.score = 0
        self.lives = 3
        self.game_over = False
        self.won = False
        self._launch_ball()

    def _launch_ball(self):
        self.ball_x = float(W // 2)
        self.ball_y = float(PADDLE_Y - 20)
        angle_choices = [(-0.6, -1), (0.6, -1), (-0.3, -1), (0.3, -1)]
        vx, vy = random.choice(angle_choices)
        norm = (vx ** 2 + vy ** 2) ** 0.5
        self.ball_vx = vx / norm * BALL_SPEED
        self.ball_vy = vy / norm * BALL_SPEED
        self.launched = False

    def brick_rect(self, r, c):
        x = BRICK_MARGIN_X + c * (BRICK_W + BRICK_GAP)
        y = BRICK_TOP + r * (BRICK_H + BRICK_GAP)
        return pygame.Rect(x, y, BRICK_W, BRICK_H)

    def _update_paddle_rect(self):
        self._paddle_rect.size = (PADDLE_W, PADDLE_H)
        self._paddle_rect.center = (self.paddle_x, PADDLE_Y)

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, HEADER_H))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        s = self.font_small.render(
            f"Score: {self.score}  Lives: {self.lives}  Best: {self.high_score}", True, config.FG_COLOR
        )
        self.screen.blit(s, (44, 10))

    def draw_bricks(self):
        for (r, c) in self.bricks:
            rect = self.brick_rect(r, c)
            pygame.draw.rect(self.screen, ROW_COLORS[r % len(ROW_COLORS)], rect, border_radius=3)

    def draw_paddle_and_ball(self):
        pygame.draw.rect(self.screen, config.ACCENT_COLOR, self._paddle_rect, border_radius=5)
        pygame.draw.circle(self.screen, (255, 255, 255), (int(self.ball_x), int(self.ball_y)), BALL_RADIUS)

    def draw_overlay(self, title):
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.screen.blit(overlay, (0, 0))
        t = self.font.render(title, True, (255, 255, 255))
        self.screen.blit(t, t.get_rect(center=(W // 2, H // 2 - 40)))
        s = self.font_small.render(f"Score: {self.score}   Best: {self.high_score}", True, (220, 220, 220))
        self.screen.blit(s, s.get_rect(center=(W // 2, H // 2 - 10)))
        self.restart_rect = pygame.Rect(W // 2 - 70, H // 2 + 20, 140, 40)
        pygame.draw.rect(self.screen, config.ACCENT_COLOR, self.restart_rect, border_radius=8)
        rt = self.font_small.render("Play Again", True, (255, 255, 255))
        self.screen.blit(rt, rt.get_rect(center=self.restart_rect.center))

    def set_paddle(self, x):
        half = PADDLE_W // 2
        self.paddle_x = max(half, min(W - half, x))
        if not self.launched:
            self.ball_x = self.paddle_x

    def update(self):
        self._update_paddle_rect()
        if self.game_over or self.won or not self.launched:
            return

        self.ball_x += self.ball_vx
        self.ball_y += self.ball_vy

        if self.ball_x - BALL_RADIUS < 0:
            self.ball_x = BALL_RADIUS
            self.ball_vx *= -1
        elif self.ball_x + BALL_RADIUS > W:
            self.ball_x = W - BALL_RADIUS
            self.ball_vx *= -1
        if self.ball_y - BALL_RADIUS < HEADER_H:
            self.ball_y = HEADER_H + BALL_RADIUS
            self.ball_vy *= -1

        ball_rect = pygame.Rect(self.ball_x - BALL_RADIUS, self.ball_y - BALL_RADIUS,
                                 BALL_RADIUS * 2, BALL_RADIUS * 2)

        if ball_rect.colliderect(self._paddle_rect) and self.ball_vy > 0:
            offset = (self.ball_x - self._paddle_rect.centerx) / (PADDLE_W / 2)
            offset = max(-1, min(1, offset))
            self.ball_vx = offset * BALL_SPEED
            self.ball_vy = -abs(self.ball_vy)
            norm = (self.ball_vx ** 2 + self.ball_vy ** 2) ** 0.5
            self.ball_vx = self.ball_vx / norm * BALL_SPEED
            self.ball_vy = self.ball_vy / norm * BALL_SPEED

        hit = None
        for (r, c) in self.bricks:
            if ball_rect.colliderect(self.brick_rect(r, c)):
                hit = (r, c)
                break
        if hit:
            self.bricks.discard(hit)
            self.ball_vy *= -1
            self.score += 10
            if not self.bricks:
                self.won = True
                if gamescores.submit_score(GAME_ID, self.score):
                    self.high_score = self.score

        if self.ball_y - BALL_RADIUS > H:
            self.lives -= 1
            if self.lives <= 0:
                self.game_over = True
                if gamescores.submit_score(GAME_ID, self.score):
                    self.high_score = self.score
            else:
                self._launch_ball()

    def handle_tap(self, pos):
        if self.game_over or self.won:
            if self.restart_rect.collidepoint(pos):
                self.reset()
            return
        if self.back_rect.collidepoint(pos):
            self.running = False
            return
        if not self.launched:
            self.launched = True

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = touch.get_pos(event)
                    self.set_paddle(pos[0])
                    self.handle_tap(pos)
                elif event.type in (pygame.MOUSEMOTION, pygame.FINGERMOTION):
                    pos = touch.get_pos(event)
                    self.set_paddle(pos[0])
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key == pygame.K_SPACE:
                        self.launched = True
                    elif event.key == pygame.K_LEFT:
                        self.set_paddle(self.paddle_x - 20)
                    elif event.key == pygame.K_RIGHT:
                        self.set_paddle(self.paddle_x + 20)

            self.update()

            self.screen.fill(config.BG_COLOR)
            self.draw_header()
            self.draw_bricks()
            self.draw_paddle_and_ball()
            if not self.launched and not self.game_over and not self.won:
                hint = self.font_small.render("Tap to launch", True, (150, 150, 160))
                self.screen.blit(hint, hint.get_rect(center=(W // 2, PADDLE_Y - 30)))
            if self.game_over:
                self.draw_overlay("Game Over")
            elif self.won:
                self.draw_overlay("You cleared it!")

            pygame.display.flip()
            self.clock.tick(45)
        pygame.quit()


if __name__ == "__main__":
    Breakout().run()

#!/usr/bin/env python3
"""PhoneOS Snake."""
import sys
import random

sys.path.insert(0, "/phoneos")
import pygame
from core import config, touch, gamescores

W, H = config.SCREEN_W, config.SCREEN_H
GAME_ID = "com.phoneos.snake"

CELL = 20
COLS = W // CELL
FIELD_TOP = 56
FOOTER_TOP = H - 150
ROWS = (FOOTER_TOP - FIELD_TOP) // CELL

START_INTERVAL = 0.18
MIN_INTERVAL = 0.07

UP, DOWN, LEFT, RIGHT = (0, -1), (0, 1), (-1, 0), (1, 0)


class Snake:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Snake")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.running = True
        self.high_score = gamescores.get_high_score(GAME_ID)
        self._build_dpad()
        self.reset()

    def reset(self):
        cx, cy = COLS // 2, ROWS // 2
        self.snake = [(cx, cy), (cx - 1, cy), (cx - 2, cy)]
        self.direction = RIGHT
        self.pending_direction = RIGHT
        self.food = self._place_food()
        self.score = 0
        self.game_over = False
        self.interval = START_INTERVAL
        self.timer = 0.0

    def _place_food(self):
        occupied = set(self.snake)
        while True:
            pos = (random.randrange(COLS), random.randrange(ROWS))
            if pos not in occupied:
                return pos

    def _build_dpad(self):
        cx, cy = W // 2, FOOTER_TOP + 75
        size = 46
        gap = 4
        self.up_rect = pygame.Rect(cx - size // 2, cy - size - gap, size, size)
        self.down_rect = pygame.Rect(cx - size // 2, cy + gap, size, size)
        self.left_rect = pygame.Rect(cx - size - size // 2 - gap, cy - size // 2, size, size)
        self.right_rect = pygame.Rect(cx + size // 2 + gap, cy - size // 2, size, size)

    def draw_dpad(self):
        for rect, label in [
            (self.up_rect, "^"), (self.down_rect, "v"),
            (self.left_rect, "<"), (self.right_rect, ">"),
        ]:
            pygame.draw.rect(self.screen, (40, 40, 48), rect, border_radius=8)
            t = self.font.render(label, True, config.ACCENT_COLOR)
            self.screen.blit(t, t.get_rect(center=rect.center))

    def draw_header(self):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)
        s = self.font_small.render(f"Score: {self.score}   Best: {self.high_score}", True, config.FG_COLOR)
        self.screen.blit(s, (44, 10))

    def draw_field(self):
        field_rect = pygame.Rect(0, FIELD_TOP, COLS * CELL, ROWS * CELL)
        pygame.draw.rect(self.screen, (18, 18, 22), field_rect)
        fx, fy = self.food
        pygame.draw.rect(self.screen, (220, 90, 90),
                          (fx * CELL, FIELD_TOP + fy * CELL, CELL, CELL))
        for i, (x, y) in enumerate(self.snake):
            color = config.ACCENT_COLOR if i == 0 else (60, 130, 210)
            pygame.draw.rect(self.screen, color,
                              (x * CELL + 1, FIELD_TOP + y * CELL + 1, CELL - 2, CELL - 2), border_radius=4)

    def draw_game_over(self):
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.screen.blit(overlay, (0, 0))
        t = self.font.render("Game Over", True, (255, 255, 255))
        self.screen.blit(t, t.get_rect(center=(W // 2, H // 2 - 40)))
        s = self.font_small.render(f"Score: {self.score}   Best: {self.high_score}", True, (220, 220, 220))
        self.screen.blit(s, s.get_rect(center=(W // 2, H // 2 - 10)))
        self.restart_rect = pygame.Rect(W // 2 - 70, H // 2 + 20, 140, 40)
        pygame.draw.rect(self.screen, config.ACCENT_COLOR, self.restart_rect, border_radius=8)
        rt = self.font_small.render("Play Again", True, (255, 255, 255))
        self.screen.blit(rt, rt.get_rect(center=self.restart_rect.center))

    def set_direction(self, new_dir):
        # can't reverse directly into yourself
        if (new_dir[0] * -1, new_dir[1] * -1) == self.direction:
            return
        self.pending_direction = new_dir

    def update(self, dt):
        if self.game_over:
            return
        self.timer += dt
        if self.timer < self.interval:
            return
        self.timer = 0.0
        self.direction = self.pending_direction
        head_x, head_y = self.snake[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)

        if not (0 <= new_head[0] < COLS and 0 <= new_head[1] < ROWS) or new_head in self.snake:
            self.game_over = True
            if gamescores.submit_score(GAME_ID, self.score):
                self.high_score = self.score
            return

        self.snake.insert(0, new_head)
        if new_head == self.food:
            self.score += 10
            self.food = self._place_food()
            self.interval = max(MIN_INTERVAL, self.interval - 0.004)
        else:
            self.snake.pop()

    def handle_tap(self, pos):
        if self.game_over:
            if self.restart_rect.collidepoint(pos):
                self.reset()
            return
        if self.back_rect.collidepoint(pos):
            self.running = False
        elif self.up_rect.collidepoint(pos):
            self.set_direction(UP)
        elif self.down_rect.collidepoint(pos):
            self.set_direction(DOWN)
        elif self.left_rect.collidepoint(pos):
            self.set_direction(LEFT)
        elif self.right_rect.collidepoint(pos):
            self.set_direction(RIGHT)

    def run(self):
        while self.running:
            dt = self.clock.tick(30) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    self.handle_tap(touch.get_pos(event))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        self.set_direction(UP)
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.set_direction(DOWN)
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        self.set_direction(LEFT)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        self.set_direction(RIGHT)

            self.update(dt)

            self.screen.fill(config.BG_COLOR)
            self.draw_header()
            self.draw_field()
            self.draw_dpad()
            if self.game_over:
                self.draw_game_over()

            pygame.display.flip()
        pygame.quit()


if __name__ == "__main__":
    Snake().run()

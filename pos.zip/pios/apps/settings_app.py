from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_MD, FONT_SM, FONT_LG, CARD_COLOR, ACCENT

TOP = STATUS_BAR_H + 20
BAR_Y0 = TOP + 70
BAR_Y1 = TOP + 100
ADJUST_Y = BAR_Y1 + 40
SLEEP_Y = ADJUST_Y + 70


class SettingsApp(App):
    name = "Settings"
    icon = "\u2699"

    def on_open(self):
        self.brightness = 90
        self.buttons = [
            Button(30, ADJUST_Y, 70, 55, "-10", self._adjust(-10), font=FONT_MD),
            Button(SCREEN_W - 100, ADJUST_Y, 70, 55, "+10", self._adjust(10), font=FONT_MD),
            Button(SCREEN_W // 2 - 90, SLEEP_Y, 180, 44,
                   "Sleep display", self._sleep, font=FONT_SM),
            Button(SCREEN_W // 2 - 60, SCREEN_H - 70, 120, 45,
                   "Home", self.os.go_home),
        ]

    def _adjust(self, delta):
        def handler():
            self.brightness = max(10, min(100, self.brightness + delta))
            try:
                self.os.lcd.set_backlight(self.brightness)
            except Exception:
                pass
        return handler

    def _sleep(self):
        self.os.enter_sleep(self.brightness)

    def draw(self, draw, canvas):
        draw.text((SCREEN_W // 2, TOP), "Settings", font=FONT_LG,
                   fill=(255, 255, 255), anchor="mm")

        draw.text((SCREEN_W // 2, TOP + 40), "Backlight", font=FONT_MD,
                   fill=(200, 200, 210), anchor="mm")

        bar_x0, bar_x1 = 30, SCREEN_W - 30
        draw.rounded_rectangle([bar_x0, BAR_Y0, bar_x1, BAR_Y1], radius=10,
                                fill=CARD_COLOR)
        fill_w = int((bar_x1 - bar_x0) * self.brightness / 100)
        draw.rounded_rectangle([bar_x0, BAR_Y0, bar_x0 + fill_w, BAR_Y1],
                                radius=10, fill=ACCENT)
        draw.text((SCREEN_W // 2, ADJUST_Y + 27), f"{self.brightness}%",
                   font=FONT_MD, fill=(255, 255, 255), anchor="mm")

        for b in self.buttons:
            b.draw(draw)

        draw.text((SCREEN_W // 2, SLEEP_Y + 66),
                   "Tap anywhere on a sleeping\nscreen to wake it up",
                   font=FONT_SM, fill=(140, 140, 150), anchor="mm", align="center")

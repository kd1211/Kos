import os
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_MD, FONT_SM, CARD_COLOR, ACCENT

NOTES_FILE = os.path.expanduser("~/.pios_notes.txt")

QUICK_PHRASES = ["Milk", "Call mom", "Water plants", "Pay bills",
                 "Meeting 3pm", "Backup files"]


class NotesApp(App):
    name = "Notes"
    icon = "\U0001F4DD"

    def on_open(self):
        self.notes = self._load()
        self.buttons = []
        top = STATUS_BAR_H + 90
        for i, phrase in enumerate(QUICK_PHRASES):
            row, col = divmod(i, 2)
            x = 16 + col * ((SCREEN_W - 48) // 2 + 16)
            y = top + row * 46
            self.buttons.append(
                Button(x, y, (SCREEN_W - 48) // 2, 38, phrase,
                       self._add(phrase), font=FONT_SM))
        self.buttons.append(
            Button(16, SCREEN_H - 60, (SCREEN_W - 48) // 2, 44,
                   "Clear", self._clear, font=FONT_SM))
        self.buttons.append(
            Button(SCREEN_W // 2, SCREEN_H - 60, (SCREEN_W - 48) // 2, 44,
                   "Home", self.os.go_home, font=FONT_SM))

    def _load(self):
        if os.path.exists(NOTES_FILE):
            with open(NOTES_FILE) as f:
                return [line.strip() for line in f if line.strip()]
        return []

    def _save(self):
        with open(NOTES_FILE, "w") as f:
            f.write("\n".join(self.notes[-6:]))

    def _add(self, phrase):
        def handler():
            self.notes.append(phrase)
            self._save()
        return handler

    def _clear(self):
        self.notes = []
        self._save()

    def draw(self, draw, canvas):
        top = STATUS_BAR_H + 10
        draw.text((SCREEN_W // 2, top), "Notes", font=FONT_MD,
                   fill=(255, 255, 255), anchor="mm")

        draw.rectangle([16, top + 16, SCREEN_W - 16, top + 66], fill=CARD_COLOR)
        text = self.notes[-1] if self.notes else "No notes yet - tap a quick note"
        draw.text((24, top + 41), text, font=FONT_SM, fill=ACCENT, anchor="lm")

        for b in self.buttons:
            b.draw(draw)

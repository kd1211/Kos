from PIL import Image, ImageDraw
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, \
    FONT_SM, CARD_COLOR

TOOLBAR_H = 96
CANVAS_TOP = STATUS_BAR_H
CANVAS_BOTTOM = SCREEN_H - TOOLBAR_H
CANVAS_H = CANVAS_BOTTOM - CANVAS_TOP

PALETTE = [
    ("Black", (20, 20, 20)),
    ("White", (255, 255, 255)),
    ("Red", (230, 70, 70)),
    ("Green", (80, 210, 120)),
    ("Blue", (80, 140, 240)),
    ("Yellow", (240, 210, 70)),
]

BRUSH_R = 5


class PaintApp(App):
    name = "Paint"
    icon = "\U0001F3A8"

    def __init__(self, os_ref):
        super().__init__(os_ref)
        self.surface = Image.new("RGB", (SCREEN_W, CANVAS_H), (250, 250, 250))
        self.surface_draw = ImageDraw.Draw(self.surface)
        self.current_color = (20, 20, 20)
        self._last_point = None

    def on_open(self):
        self._last_point = None
        self.buttons = []
        swatch_w = SCREEN_W // len(PALETTE)
        for i, (label, color) in enumerate(PALETTE):
            self.buttons.append(
                Button(i * swatch_w, CANVAS_BOTTOM, swatch_w, 40, "",
                       self._pick_color(color), bg=color, font=FONT_SM))

        self.buttons.append(
            Button(10, CANVAS_BOTTOM + 46, (SCREEN_W - 30) // 2, 42,
                   "Clear", self._clear, font=FONT_SM))
        self.buttons.append(
            Button(20 + (SCREEN_W - 30) // 2, CANVAS_BOTTOM + 46,
                   (SCREEN_W - 30) // 2, 42, "Home", self.os.go_home, font=FONT_SM))

    def _pick_color(self, color):
        def handler():
            self.current_color = color
        return handler

    def _clear(self):
        self.surface_draw.rectangle([0, 0, SCREEN_W, CANVAS_H], fill=(250, 250, 250))

    def on_touch_move(self, x, y):
        if y >= CANVAS_BOTTOM:
            self._last_point = None  # finger is over the toolbar, don't draw
            return
        local_y = y - CANVAS_TOP
        if self._last_point:
            self.surface_draw.line(
                [self._last_point, (x, local_y)], fill=self.current_color,
                width=BRUSH_R * 2)
        self.surface_draw.ellipse(
            [x - BRUSH_R, local_y - BRUSH_R, x + BRUSH_R, local_y + BRUSH_R],
            fill=self.current_color)
        self._last_point = (x, local_y)

    def on_touch_up(self):
        self._last_point = None

    def draw(self, draw, canvas):
        canvas.paste(self.surface, (0, CANVAS_TOP))
        draw.rectangle([0, CANVAS_BOTTOM, SCREEN_W, SCREEN_H], fill=CARD_COLOR)
        for b in self.buttons:
            b.draw(draw)
        # outline the active color so it's clear what's selected
        swatch_w = SCREEN_W // len(PALETTE)
        for i, (_, color) in enumerate(PALETTE):
            if color == self.current_color:
                x0 = i * swatch_w
                draw.rectangle([x0, CANVAS_BOTTOM, x0 + swatch_w, CANVAS_BOTTOM + 40],
                                outline=(255, 255, 255), width=3)

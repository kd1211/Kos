import math
from ui.framework import App, Button, SCREEN_W, SCREEN_H, STATUS_BAR_H, FONT_LG, FONT_SM


class Home(App):
    name = "Home"
    icon = "\u2302"

    def on_open(self):
        self.buttons = []
        apps_to_show = [n for n in self.os.apps if n != "Home"]

        cols = 3
        margin = 10
        top = STATUS_BAR_H + 44
        bottom_pad = 10
        rows = max(1, math.ceil(len(apps_to_show) / cols))

        available_w = SCREEN_W - margin * (cols + 1)
        available_h = SCREEN_H - top - bottom_pad - margin * (rows + 1)
        cell = max(48, min(available_w // cols, available_h // rows))

        grid_w = cell * cols + margin * (cols - 1)
        x_offset = (SCREEN_W - grid_w) // 2

        font = FONT_SM if cell < 80 else None  # shrink labels on dense grids

        for i, name in enumerate(apps_to_show):
            row, col = divmod(i, cols)
            x = x_offset + col * (cell + margin)
            y = top + row * (cell + margin)
            app = self.os.apps[name]
            btn = Button(x, y, cell, cell, name, self._open(name), icon=app.icon)
            if font:
                btn.font = font
            self.buttons.append(btn)

    def _open(self, name):
        return lambda: self.os.open_app(name)

    def draw(self, draw, canvas):
        draw.text((SCREEN_W // 2, STATUS_BAR_H + 20), "PiOS", font=FONT_LG,
                   fill=(255, 255, 255), anchor="mm")
        for b in self.buttons:
            b.draw(draw)

#!/usr/bin/env python3
"""
PiOS - a tiny touchscreen phone OS for the Raspberry Pi, built for:
  - Waveshare 3.5inch Capacitive Touch LCD (ST7796S + FT6336U, SPI/I2C)
  - Waveshare UPS HAT (C) (INA219 battery monitor, I2C)

Run with:
    sudo python3 main.py
(sudo is needed for GPIO/SPI access, same as Waveshare's own demos)
"""

from drivers.lcd_st7796 import ST7796
from drivers.touch_ft6336u import FT6336U
from drivers.ina219_battery import INA219
from ui.framework import PhoneOS

from apps.home import Home
from apps.clock_app import ClockApp
from apps.battery_app import BatteryApp
from apps.notes_app import NotesApp
from apps.calculator_app import CalculatorApp
from apps.settings_app import SettingsApp
from apps.paint_app import PaintApp
from apps.tictactoe_app import TicTacToeApp
from apps.memory_app import MemoryApp
from apps.reaction_app import ReactionApp
from apps.flashlight_app import FlashlightApp
from apps.sysinfo_app import SysInfoApp


def main():
    lcd = ST7796()
    lcd.init()

    touch = FT6336U()
    battery = INA219()

    os_ = PhoneOS(lcd, touch, battery)

    os_.register_app(Home)
    os_.register_app(ClockApp)
    os_.register_app(BatteryApp)
    os_.register_app(NotesApp)
    os_.register_app(CalculatorApp)
    os_.register_app(SettingsApp)
    os_.register_app(PaintApp)
    os_.register_app(TicTacToeApp)
    os_.register_app(MemoryApp)
    os_.register_app(ReactionApp)
    os_.register_app(FlashlightApp)
    os_.register_app(SysInfoApp)

    os_.run()


if __name__ == "__main__":
    main()

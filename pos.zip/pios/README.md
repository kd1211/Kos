# PiOS — a tiny touchscreen phone OS for the Raspberry Pi

Built for two specific Waveshare boards:

- **3.5inch Capacitive Touch LCD** — 320×480 IPS panel, ST7796S driver chip
  (SPI) + FT6336U capacitive touch controller (I2C).
- **UPS HAT (C)** — battery power board with an INA219 voltage/current
  monitor (I2C), for the Raspberry Pi.

## Hardware setup

1. Mount the UPS HAT (C) onto the Pi's GPIO header via its pogo pins,
   clip in the included Li-po battery, and charge it fully once before
   first use (per the wiki, this activates the protection circuit).
2. Connect the LCD's 15PIN cable to the Pi as described on the LCD wiki:
   SPI (DIN/CLK/CS/DC/RST) for the display, I2C (SDA/SCL) for touch,
   plus VCC/GND/BL.
3. Enable SPI and I2C:
   ```bash
   sudo raspi-config
   # Interface Options -> SPI -> Enable
   # Interface Options -> I2C -> Enable
   sudo reboot
   ```
4. Confirm the buses are alive:
   ```bash
   ls /dev/spidev*      # expect /dev/spidev0.0
   i2cdetect -y 1       # expect 0x38 (touch) and 0x43 (battery)
   ```

## Install

```bash
sudo apt-get update
sudo apt-get install -y python3-pip python3-pil python3-numpy python3-spidev python3-smbus
pip3 install -r requirements.txt --break-system-packages
```

## Run

```bash
sudo python3 main.py
```

(`sudo` is required for GPIO/SPI access, the same as Waveshare's own demos.)

To boot straight into PiOS on power-up, add a line to the pi user's
crontab or a systemd service that runs `sudo python3 /path/to/main.py`.

## What's included

- `drivers/lcd_st7796.py` — SPI driver for the ST7796S panel (init sequence,
  RGB565 framebuffer push from a PIL image).
- `drivers/touch_ft6336u.py` — I2C driver for the FT6336U touch controller.
- `drivers/ina219_battery.py` — I2C driver for the INA219 fuel gauge on the
  UPS HAT (C), reporting voltage, current, power and estimated battery %.
- `ui/framework.py` — the "OS": a status bar (clock + live battery icon),
  an `App` base class (with tap, drag, and release hooks), a
  render/touch-poll main loop, and a sleep/wake power-saving mode.
- `apps/` — twelve built-in apps:
  - **Home** — app grid launcher that auto-scales icon size/spacing as
    you add more apps, so it never overflows the screen
  - **Clock** — live time and date
  - **Battery** — live voltage/current/power/percent from the UPS HAT,
    with a circular charge gauge
  - **Notes** — quick tap-to-save notes, persisted to a text file
  - **Calculator** — basic touch calculator
  - **Settings** — backlight brightness slider + a "Sleep display" button
  - **Paint** — finger-drag drawing app with a 6-color palette, brush,
    and clear button (uses continuous drag input, not just taps)
  - **Tic-Tac-Toe** — two players, one device
  - **Memory** — card-flip matching game
  - **Reaction** — whack-a-mole style reflex game, score against a timer
  - **Flashlight** — full-brightness white screen, doubles as a torch
  - **System** — CPU temperature, uptime, storage and memory usage

### Quality-of-life touches
- **Sleep mode**: `Settings -> Sleep display` blanks the screen and cuts
  the backlight to save the UPS HAT's battery; tap anywhere to wake it.
- **Auto-scaling launcher grid**: the Home screen recalculates icon size
  so any number of installed apps fits without needing pagination.
- **Drag support**: the framework distinguishes taps (for buttons) from
  continuous touch-and-drag (for Paint), so both interaction styles work
  on the same touch driver.

## Notes on tuning for your exact unit

- If touch coordinates come out swapped or mirrored, adjust
  `swap_xy` / `invert_x` / `invert_y` in `FT6336U(...)` in `main.py`.
- If colors look off (red/blue swapped), flip the `0x36` memory-access
  value in `lcd_st7796.py`'s init sequence.
- INA219 address defaults to `0x43` (UPS HAT (C) default); check with
  `i2cdetect -y 1` and pass `addr=` if yours differs.
- Adding a new app is just a new `App` subclass in `apps/` plus one
  `os_.register_app(YourApp)` line in `main.py`.

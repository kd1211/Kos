"""
Minimal phone-OS UI framework.

Everything is drawn into a single PIL "canvas" image every frame, which
gets pushed to the ST7796 panel. Touch is polled from the FT6336U.

Two kinds of touch input are exposed to apps:
  - on_tap(x, y)         -- fires once on finger-down (rising edge), used
                             by buttons/menus.
  - on_touch_move(x, y)  -- fires every frame the finger is held down,
                             used by apps that need continuous drag input
                             (e.g. Paint).
  - on_touch_up()        -- fires once when the finger is lifted.

The OS also owns a simple sleep mode (screen + backlight off) to save
battery on the UPS HAT (C) -- tap anywhere to wake back up.
"""

import time
from PIL import Image, ImageDraw, ImageFont

SCREEN_W = 320
SCREEN_H = 480
STATUS_BAR_H = 28

BG_COLOR = (18, 18, 24)
FG_COLOR = (235, 235, 240)
ACCENT = (68, 140, 255)
CARD_COLOR = (32, 32, 40)


def load_font(size):
    try:
        return ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size)
    except IOError:
        return ImageFont.load_default()


FONT_SM = load_font(14)
FONT_MD = load_font(18)
FONT_LG = load_font(28)
FONT_XL = load_font(40)


class Button:
    """A tappable rectangular region with a label."""

    def __init__(self, x, y, w, h, label, on_tap, icon=None,
                 bg=CARD_COLOR, fg=FG_COLOR, font=FONT_MD):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.label = label
        self.on_tap = on_tap
        self.icon = icon
        self.bg = bg
        self.fg = fg
        self.font = font

    def contains(self, px, py):
        return self.x <= px <= self.x + self.w and self.y <= py <= self.y + self.h

    def draw(self, draw):
        draw.rounded_rectangle(
            [self.x, self.y, self.x + self.w, self.y + self.h],
            radius=14, fill=self.bg)
        if self.icon:
            draw.text((self.x + self.w // 2, self.y + self.h // 2 - 14),
                       self.icon, font=FONT_XL, fill=self.fg, anchor="mm")
            draw.text((self.x + self.w // 2, self.y + self.h - 16),
                       self.label, font=FONT_SM, fill=self.fg, anchor="mm")
        else:
            draw.text((self.x + self.w // 2, self.y + self.h // 2),
                       self.label, font=self.font, fill=self.fg, anchor="mm")


class App:
    """Base class every app screen implements."""

    name = "App"
    icon = "?"

    def __init__(self, os_ref):
        self.os = os_ref
        self.buttons = []

    def on_open(self):
        pass

    def on_close(self):
        pass

    def draw(self, draw, canvas):
        pass

    def on_tap(self, x, y):
        for b in self.buttons:
            if b.contains(x, y):
                b.on_tap()
                return True
        return False

    def on_touch_move(self, x, y):
        """Called every frame while the finger is held down. Override for drag input."""
        pass

    def on_touch_up(self):
        """Called once when the finger is lifted."""
        pass


class PhoneOS:
    """Owns the frame loop: render -> push to LCD -> poll touch -> dispatch."""

    def __init__(self, lcd, touch, battery):
        self.lcd = lcd
        self.touch = touch
        self.battery = battery
        self.apps = {}
        self.current_app = None
        self._last_touch_state = False
        self._battery_cache = {"voltage": 0, "percent": 100, "charging": False}
        self._battery_last_read = 0
        self.sleeping = False
        self._prev_brightness = 90

    def register_app(self, app_cls):
        self.apps[app_cls.name] = app_cls(self)

    def open_app(self, name):
        if self.current_app:
            self.current_app.on_close()
        self.current_app = self.apps[name]
        self.current_app.on_open()

    def go_home(self):
        self.open_app("Home")

    # -- power / sleep -----------------------------------------------
    def enter_sleep(self, current_brightness=90):
        self._prev_brightness = current_brightness
        self.sleeping = True
        try:
            self.lcd.set_backlight(0)
        except Exception:
            pass

    def wake(self):
        self.sleeping = False
        try:
            self.lcd.set_backlight(self._prev_brightness)
        except Exception:
            pass

    # -- battery -------------------------------------------------------
    def _read_battery(self):
        now = time.time()
        if now - self._battery_last_read > 2.0:
            try:
                self._battery_cache = self.battery.read_all()
            except Exception:
                pass
            self._battery_last_read = now
        return self._battery_cache

    def _draw_status_bar(self, draw):
        draw.rectangle([0, 0, SCREEN_W, STATUS_BAR_H], fill=(10, 10, 14))
        clock_str = time.strftime("%H:%M")
        draw.text((10, STATUS_BAR_H // 2), clock_str, font=FONT_SM,
                   fill=FG_COLOR, anchor="lm")

        batt = self._read_battery()
        pct = batt.get("percent", 100)
        charging = batt.get("charging", False)
        label = f"{pct}%{' +' if charging else ''}"
        draw.text((SCREEN_W - 10, STATUS_BAR_H // 2), label, font=FONT_SM,
                   fill=FG_COLOR, anchor="rm")

        # simple battery glyph
        bx, by, bw, bh = SCREEN_W - 60, 8, 26, 12
        draw.rectangle([bx, by, bx + bw, by + bh], outline=FG_COLOR)
        draw.rectangle([bx + bw, by + 3, bx + bw + 3, by + bh - 3], fill=FG_COLOR)
        fill_w = int((bw - 2) * pct / 100)
        color = (80, 220, 120) if pct > 20 else (230, 90, 90)
        draw.rectangle([bx + 1, by + 1, bx + 1 + fill_w, by + bh - 1], fill=color)

    def render(self):
        if self.sleeping:
            canvas = Image.new("RGB", (SCREEN_W, SCREEN_H), (0, 0, 0))
            self.lcd.display(canvas)
            return
        canvas = Image.new("RGB", (SCREEN_W, SCREEN_H), BG_COLOR)
        draw = ImageDraw.Draw(canvas)
        self._draw_status_bar(draw)
        if self.current_app:
            self.current_app.draw(draw, canvas)
        self.lcd.display(canvas)

    def poll_touch_raw(self):
        """Returns the current touch point every frame, or None."""
        return self.touch.read_point()

    def run(self):
        self.go_home()
        try:
            while True:
                raw = self.poll_touch_raw()

                if self.sleeping:
                    # any touch wakes the display; swallow that touch
                    if raw:
                        self.wake()
                    self.render()
                    time.sleep(0.05)
                    continue

                was_down = self._last_touch_state
                now_down = bool(raw)

                if self.current_app:
                    if now_down and not was_down:
                        self.current_app.on_tap(*raw)
                    elif now_down and was_down:
                        self.current_app.on_touch_move(*raw)
                    elif was_down and not now_down:
                        self.current_app.on_touch_up()

                self._last_touch_state = now_down

                self.render()
                time.sleep(0.05)
        except KeyboardInterrupt:
            pass
        finally:
            self.lcd.close()

#!/usr/bin/env python3
"""PhoneOS Settings app. Single-screen list of toggles/pages, tap
back arrow (top-left) or ESC to return to the launcher."""
import sys
import os
import subprocess

sys.path.insert(0, "/phoneos")
import pygame
from core import config, settings, battery, netstatus, app_manager

W, H = config.SCREEN_W, config.SCREEN_H


class SettingsApp:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Settings")
        self.font = pygame.font.Font(None, 22)
        self.font_small = pygame.font.Font(None, 16)
        self.clock = pygame.time.Clock()
        self.settings = settings.load()
        self.page = "main"
        self.running = True

    def draw_header(self, title):
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, (0, 0, W, 36))
        back = self.font.render("<", True, config.FG_COLOR)
        self.screen.blit(back, (10, 6))
        t = self.font.render(title, True, config.FG_COLOR)
        self.screen.blit(t, (40, 6))
        self.back_rect = pygame.Rect(0, 0, 36, 36)

    def row(self, y, text, value=None):
        rect = pygame.Rect(10, y, W - 20, 40)
        pygame.draw.rect(self.screen, (24, 24, 30), rect, border_radius=6)
        t = self.font.render(text, True, config.FG_COLOR)
        self.screen.blit(t, (rect.x + 10, rect.y + 10))
        if value is not None:
            v = self.font_small.render(str(value), True, config.ACCENT_COLOR)
            self.screen.blit(v, (rect.right - v.get_width() - 10, rect.y + 12))
        return rect

    def draw_main(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Settings")
        y = 46
        self.rows = {}
        wifi_connected, ssid = netstatus.wifi_status()
        self.rows["wifi"] = self.row(y, "Wi-Fi", ssid or ("On" if wifi_connected else "Off"))
        y += 46
        self.rows["bluetooth"] = self.row(y, "Bluetooth", "On" if netstatus.bluetooth_status() else "Off")
        y += 46
        b = battery.read()
        self.rows["battery"] = self.row(y, "Battery", f"{b['percent']}%")
        y += 46
        self.rows["display"] = self.row(y, "Display", f"{self.settings['brightness']}%")
        y += 46
        self.rows["storage"] = self.row(y, "Storage", "")
        y += 46
        self.rows["apps"] = self.row(y, "Installed Apps", str(len(app_manager.load_db())))
        y += 46
        self.rows["updates"] = self.row(y, "Updates", "")
        y += 46
        self.rows["developer"] = self.row(y, "Developer Mode", "On" if self.settings["developer_mode"] else "Off")
        y += 46
        self.rows["about"] = self.row(y, "About", "")

    def draw_battery_detail(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Battery")
        b = battery.read()
        lines = [
            f"Percent: {b['percent']}%",
            f"Charging: {'Yes' if b['charging'] else 'No'}",
            f"Voltage: {b['voltage']} V",
            f"Current: {b['current_ma']} mA",
            f"Power: {b['power_w']} W",
            f"Est. runtime: {b['runtime_min']} min" if b["runtime_min"] else "Est. runtime: --",
        ]
        y = 50
        for line in lines:
            t = self.font.render(line, True, config.FG_COLOR)
            self.screen.blit(t, (16, y))
            y += 30

    def draw_about(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("About")
        lines = ["PhoneOS", "Version 0.1.0", "Raspberry Pi Zero build"]
        y = 50
        for line in lines:
            t = self.font.render(line, True, config.FG_COLOR)
            self.screen.blit(t, (16, y))
            y += 30

    def draw_developer(self):
        self.screen.fill(config.BG_COLOR)
        self.draw_header("Developer Mode")
        state = "On" if self.settings["developer_mode"] else "Off"
        self.rows = {"toggle": self.row(50, "Developer Mode", state)}

    def handle_tap(self, pos):
        if self.back_rect.collidepoint(pos):
            if self.page == "main":
                self.running = False
            else:
                self.page = "main"
            return
        if self.page == "main":
            for key, rect in self.rows.items():
                if rect.collidepoint(pos):
                    if key in ("battery", "about", "developer"):
                        self.page = key
                    elif key == "wifi":
                        subprocess.run(["nmcli", "radio", "wifi"], capture_output=True)
                    return
        elif self.page == "developer":
            if self.rows["toggle"].collidepoint(pos):
                self.settings["developer_mode"] = not self.settings["developer_mode"]
                settings.save(self.settings)

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.handle_tap(event.pos)
                elif event.type == pygame.FINGERDOWN:
                    self.handle_tap((int(event.x * W), int(event.y * H)))
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            if self.page == "main":
                self.draw_main()
            elif self.page == "battery":
                self.draw_battery_detail()
            elif self.page == "about":
                self.draw_about()
            elif self.page == "developer":
                self.draw_developer()

            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    SettingsApp().run()

#!/usr/bin/env python3
"""PhoneOS Clock app: large digital clock + date. Tap anywhere to exit."""
import sys
import time

sys.path.insert(0, "/phoneos")
import pygame
from core import config

W, H = config.SCREEN_W, config.SCREEN_H


def main():
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Clock")
    font_time = pygame.font.Font(None, 72)
    font_date = pygame.font.Font(None, 28)
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False

        screen.fill(config.BG_COLOR)
        time_str = time.strftime("%H:%M:%S")
        date_str = time.strftime("%A, %B %d")
        t = font_time.render(time_str, True, config.FG_COLOR)
        d = font_date.render(date_str, True, config.ACCENT_COLOR)
        screen.blit(t, t.get_rect(center=(W // 2, H // 2 - 20)))
        screen.blit(d, d.get_rect(center=(W // 2, H // 2 + 40)))
        pygame.display.flip()
        clock.tick(1)
    pygame.quit()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""PhoneOS Terminal: runs shell commands via subprocess, with a simple
on-screen keyboard for touch input (a real keyboard also works if
attached via USB/Bluetooth)."""
import sys
import os
import subprocess

sys.path.insert(0, "/phoneos")
import pygame
from core import config

W, H = config.SCREEN_W, config.SCREEN_H
KB_ROWS = [
    "1234567890",
    "qwertyuiop",
    "asdfghjkl",
    "zxcvbnm",
]
KEY_H = 34


class Terminal:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Terminal")
        self.font = pygame.font.Font(None, 16)
        self.font_kb = pygame.font.Font(None, 18)
        self.clock = pygame.time.Clock()
        self.lines = ["PhoneOS Terminal", "$ "]
        self.input_buf = ""
        self.cwd = os.path.expanduser("~")
        self.shift = False
        self.running = True
        self._build_keyboard()

    def _build_keyboard(self):
        self.keys = []  # (rect, char)
        kb_top = H - (len(KB_ROWS) + 1) * KEY_H - 4
        for r, row in enumerate(KB_ROWS):
            n = len(row)
            key_w = W // (n + 1)
            offset = (W - n * key_w) // 2
            for i, ch in enumerate(row):
                rect = pygame.Rect(offset + i * key_w, kb_top + r * KEY_H, key_w - 2, KEY_H - 2)
                self.keys.append((rect, ch))
        # bottom row: space, backspace, enter, shift
        y = kb_top + len(KB_ROWS) * KEY_H
        self.key_space = pygame.Rect(60, y, W - 220, KEY_H - 2)
        self.key_back = pygame.Rect(W - 155, y, 70, KEY_H - 2)
        self.key_enter = pygame.Rect(W - 80, y, 70, KEY_H - 2)
        self.key_shift = pygame.Rect(4, y, 50, KEY_H - 2)
        self.kb_top = kb_top

    def run_command(self, cmd):
        self.lines[-1] = "$ " + cmd
        if cmd.strip() == "clear":
            self.lines = ["$ "]
            return
        if cmd.strip().startswith("cd"):
            parts = cmd.strip().split(maxsplit=1)
            target = parts[1] if len(parts) > 1 else os.path.expanduser("~")
            target = os.path.join(self.cwd, target) if not target.startswith("/") else target
            if os.path.isdir(target):
                self.cwd = os.path.abspath(target)
            else:
                self.lines.append(f"cd: no such directory: {target}")
            self.lines.append("$ ")
            return
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=self.cwd, capture_output=True,
                text=True, timeout=15,
            )
            out = (result.stdout + result.stderr).strip()
        except subprocess.TimeoutExpired:
            out = "(timed out)"
        except OSError as e:
            out = str(e)
        for line in out.splitlines()[-100:]:
            self.lines.append(line)
        self.lines.append("$ ")

    def draw(self):
        self.screen.fill((8, 8, 10))
        y = H - self.kb_top - 8
        visible = max(1, y // 16)
        for line in self.lines[-visible:]:
            t = self.font.render(line[:52], True, (120, 230, 120))
            self.screen.blit(t, (4, y - visible * 16 + (self.lines[-visible:].index(line) * 16)))
        cur = self.lines[-1] + self.input_buf
        t = self.font.render(cur[-52:], True, (255, 255, 255))
        self.screen.blit(t, (4, y - 16))

        pygame.draw.rect(self.screen, (18, 18, 22), (0, self.kb_top - 2, W, H - self.kb_top + 2))
        for rect, ch in self.keys:
            pygame.draw.rect(self.screen, (40, 40, 48), rect, border_radius=4)
            disp = ch.upper() if self.shift else ch
            t = self.font_kb.render(disp, True, config.FG_COLOR)
            self.screen.blit(t, t.get_rect(center=rect.center))

        for rect, label in [
            (self.key_space, "space"), (self.key_back, "back"),
            (self.key_enter, "enter"), (self.key_shift, "shift"),
        ]:
            pygame.draw.rect(self.screen, (40, 40, 48), rect, border_radius=4)
            t = self.font_kb.render(label, True, config.ACCENT_COLOR)
            self.screen.blit(t, t.get_rect(center=rect.center))

    def handle_tap(self, pos):
        for rect, ch in self.keys:
            if rect.collidepoint(pos):
                self.input_buf += ch.upper() if self.shift else ch
                return
        if self.key_space.collidepoint(pos):
            self.input_buf += " "
        elif self.key_back.collidepoint(pos):
            self.input_buf = self.input_buf[:-1]
        elif self.key_enter.collidepoint(pos):
            cmd = self.input_buf
            self.input_buf = ""
            self.run_command(cmd)
        elif self.key_shift.collidepoint(pos):
            self.shift = not self.shift

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pos = (int(event.x * W), int(event.y * H)) if event.type == pygame.FINGERDOWN else event.pos
                    self.handle_tap(pos)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key == pygame.K_RETURN:
                        cmd = self.input_buf
                        self.input_buf = ""
                        self.run_command(cmd)
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_buf = self.input_buf[:-1]
                    elif event.unicode:
                        self.input_buf += event.unicode

            self.draw()
            pygame.display.flip()
            self.clock.tick(20)
        pygame.quit()


if __name__ == "__main__":
    Terminal().run()

# PhoneOS

Lightweight phone-style OS for Raspberry Pi Zero / Zero 2 W.

## Install on the Pi

1. Flash Raspberry Pi OS Lite, boot it, SSH in (or use a keyboard).
2. Copy this whole `phoneos/` folder onto the Pi, e.g.:
   scp -r phoneos pi@<ip>:~/phoneos
3. On the Pi:
   cd ~/phoneos
   sudo bash install.sh
   sudo reboot

The installer enables I2C/SPI, installs pygame + deps, copies everything
to /phoneos, registers the built-in apps, and sets up a systemd service
(phoneos.service) that boots straight into the launcher.

## Test on a desktop first (recommended)

You can run the launcher on your dev machine before touching the Pi:

    pip install pygame
    PYTHONPATH=. python3 boot.py

It runs in a normal window at 320x480. Tap = left click, drag not needed.

## What's included (v1)

- core/ — launcher, single-foreground-app window manager (apps run as
  subprocesses, only one draws at a time), app_manager (manifest
  scanning + installed_apps.json), battery reader (Waveshare UPS HAT C /
  INA219 over I2C, with a safe dummy fallback), wifi/bluetooth status.
- apps/ — Settings, Files (browse/copy/move/delete/.phoneapp install),
  Terminal (on-screen keyboard + shell), Clock, Calculator.
- install.sh — one-shot Pi installer + systemd autostart service.

## Not yet built (from the full spec)

App Store (GitHub repo index + .phoneapp downloads), System Updater
(GitHub version.json diffing/rollback), Browser, peer-to-peer Messages,
Notification system, touchscreen calibration UI, brightness control.
The app manifest format and installed_apps.json db are already in place
so these can slot in without changing existing apps.

## Adding your own app

Create `/phoneos/apps/<yourapp>/manifest.json`:

    {
      "id": "com.you.yourapp",
      "name": "Your App",
      "version": "1.0.0",
      "entry": "main.py",
      "icon": "icon.png",
      "type": "user"
    }

Add `main.py` (any pygame app, 320x480, reads config.SCREEN_W/H) and an
optional `icon.png`. It shows up on the home screen after a rescan
(automatic on next boot, or call `core.app_manager.rebuild_db()`).

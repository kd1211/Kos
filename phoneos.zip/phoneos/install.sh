#!/usr/bin/env bash
# PhoneOS installer for Raspberry Pi OS Lite (Zero / Zero 2 W).
# Run as root on the Pi itself: sudo bash install.sh
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run this with sudo: sudo bash install.sh"
  exit 1
fi

PHONEOS_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PHONEOS_DEST="/phoneos"
CONFIG_TXT="/boot/firmware/config.txt"
[[ -f "$CONFIG_TXT" ]] || CONFIG_TXT="/boot/config.txt"

echo "==> Installing PhoneOS from $PHONEOS_SRC to $PHONEOS_DEST"

echo "==> Updating apt and installing system packages"
apt-get update
apt-get install -y \
  python3 python3-pip python3-venv \
  python3-pygame python3-smbus i2c-tools \
  git

echo "==> Enabling I2C and SPI"
raspi-config nonint do_i2c 0
raspi-config nonint do_spi 0

echo "==> Copying PhoneOS files"
mkdir -p "$PHONEOS_DEST"
rsync -a --delete \
  --exclude 'cache' --exclude 'downloads' --exclude 'logs' \
  "$PHONEOS_SRC"/ "$PHONEOS_DEST"/

mkdir -p "$PHONEOS_DEST"/{system,cache,downloads,packages,themes,wallpapers,user,logs}

echo "==> Installing Python dependencies"
pip3 install --break-system-packages -r "$PHONEOS_DEST/requirements.txt" || \
  pip3 install -r "$PHONEOS_DEST/requirements.txt"

echo "==> Configuring display (Waveshare 3.5in capacitive touch LCD)"
# NOTE: exact overlay depends on your specific Waveshare 3.5" model/revision.
# These are safe common defaults; check Waveshare's wiki for your model if
# the display does not come up after reboot.
if ! grep -q "phoneos-display" "$CONFIG_TXT"; then
  cat >> "$CONFIG_TXT" <<'EOF'

# --- phoneos-display: Waveshare 3.5in capacitive touch LCD ---
dtoverlay=vc4-kms-dsi-waveshare-panel,4_0_inch
display_rotate=0
EOF
fi

echo "==> Registering built-in apps"
python3 - <<PYEOF
import sys
sys.path.insert(0, "$PHONEOS_DEST")
from core import app_manager
apps = app_manager.rebuild_db()
print(f"Registered {len(apps)} apps")
PYEOF

echo "==> Installing systemd service (auto-start into PhoneOS)"
cp "$PHONEOS_DEST/system/phoneos.service" /etc/systemd/system/phoneos.service
systemctl daemon-reload
systemctl enable phoneos.service

echo "==> Disabling the default getty on tty1 console output flooding the LCD (optional)"
systemctl disable getty@tty1.service || true

echo ""
echo "PhoneOS installed. Reboot to boot directly into it:"
echo "  sudo reboot"
echo ""
echo "After reboot, check logs at $PHONEOS_DEST/logs/service.log if the"
echo "display doesn't come up, and verify your exact Waveshare display"
echo "overlay in $CONFIG_TXT."

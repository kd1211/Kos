"""Loads and saves /phoneos/user/settings.json."""
import json
import os

from core import config


def load():
    if not os.path.isfile(config.SETTINGS_FILE):
        return dict(config.DEFAULT_SETTINGS)
    try:
        with open(config.SETTINGS_FILE, "r") as f:
            data = json.load(f)
        merged = dict(config.DEFAULT_SETTINGS)
        merged.update(data)
        return merged
    except (json.JSONDecodeError, OSError):
        return dict(config.DEFAULT_SETTINGS)


def save(settings):
    os.makedirs(config.USER_DIR, exist_ok=True)
    with open(config.SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)

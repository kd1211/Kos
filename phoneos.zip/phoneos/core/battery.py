"""Reads the Waveshare UPS HAT (C), based on the INA219 current/power
monitor over I2C. Falls back to dummy values if hardware or the smbus2
library is unavailable, so PhoneOS still runs for development off-Pi."""
import logging

log = logging.getLogger("phoneos.battery")

I2C_ADDR = 0x41
_bus = None
_available = False

try:
    import smbus2

    _REG_CONFIG = 0x00
    _REG_BUSVOLTAGE = 0x02
    _REG_POWER = 0x03
    _REG_CURRENT = 0x04
    _REG_CALIBRATION = 0x05

    def _read16(bus, reg):
        raw = bus.read_word_data(I2C_ADDR, reg)
        return ((raw << 8) & 0xFF00) + (raw >> 8)

    _bus = smbus2.SMBus(1)
    # Calibration value for 16V/5A range (per Waveshare UPS HAT C datasheet)
    _bus.write_word_data(I2C_ADDR, _REG_CALIBRATION, 0x1000)
    _available = True
except Exception as e:  # noqa: BLE001 - hardware may simply not be present
    log.info("UPS HAT not available, using dummy battery values: %s", e)
    _available = False

# Rough LiPo voltage curve for percentage estimate (2S pack, ~6.0-8.4V)
_MIN_V = 6.0
_MAX_V = 8.4


def read():
    """Return dict with percent, charging, voltage, current_ma, power_w."""
    if not _available:
        return {
            "percent": 100,
            "charging": False,
            "voltage": 0.0,
            "current_ma": 0.0,
            "power_w": 0.0,
            "runtime_min": None,
        }
    try:
        raw_v = _read16(_bus, _REG_BUSVOLTAGE)
        voltage = (raw_v >> 3) * 0.004  # LSB = 4mV, shifted 3 bits

        raw_i = _read16(_bus, _REG_CURRENT)
        if raw_i > 32767:
            raw_i -= 65536
        current_ma = raw_i * 0.1  # depends on calibration, approximate

        raw_p = _read16(_bus, _REG_POWER)
        power_w = raw_p * 0.002

        percent = max(0, min(100, int((voltage - _MIN_V) / (_MAX_V - _MIN_V) * 100)))
        charging = current_ma > 0

        runtime_min = None
        if current_ma < 0 and current_ma != 0:
            # crude estimate assuming 1200mAh pack
            runtime_min = int(1200 / abs(current_ma) * 60)

        return {
            "percent": percent,
            "charging": charging,
            "voltage": round(voltage, 2),
            "current_ma": round(current_ma, 1),
            "power_w": round(power_w, 2),
            "runtime_min": runtime_min,
        }
    except Exception as e:  # noqa: BLE001
        log.warning("Battery read failed: %s", e)
        return {
            "percent": -1,
            "charging": False,
            "voltage": 0.0,
            "current_ma": 0.0,
            "power_w": 0.0,
            "runtime_min": None,
        }

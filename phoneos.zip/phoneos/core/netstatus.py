"""Lightweight Wi-Fi / Bluetooth status checks. Uses cheap shell calls
instead of heavy libraries to keep this usable on a Pi Zero."""
import subprocess
import logging

log = logging.getLogger("phoneos.netstatus")


def wifi_status():
    """Return (connected: bool, ssid: str|None)."""
    try:
        out = subprocess.run(
            ["iwgetid", "-r"], capture_output=True, text=True, timeout=1.5
        )
        ssid = out.stdout.strip()
        return (bool(ssid), ssid or None)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        log.debug("wifi_status unavailable: %s", e)
        return (False, None)


def bluetooth_status():
    """Return True if the bluetooth controller is powered on."""
    try:
        out = subprocess.run(
            ["bluetoothctl", "show"], capture_output=True, text=True, timeout=1.5
        )
        return "Powered: yes" in out.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        log.debug("bluetooth_status unavailable: %s", e)
        return False

#!/usr/bin/env python3
"""PhoneOS Launcher.

Boots into a touch-friendly home screen. Apps run as separate processes;
the launcher tears down its own display before starting one and only
draws again once it exits, guaranteeing a single foreground app.
"""
import os
import sys
import time
import subprocess
import logging

sys.path.insert(0, "/phoneos")

import pygame

from core import config, app_manager, battery, netstatus, settings

logging.basicConfig(
    filename=os.path.join(config.LOGS_DIR, "launcher.log")
    if os.path.isdir(config.LOGS_DIR)
    else None,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("phoneos.launcher")


class Launcher:
    def __init__(self):
        os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
        pygame.init()
        pygame.mouse.set_visible(False)
        self.settings = settings.load()
        self._init_display()
        self.clock = pygame.time.Clock()
        self.font_small = pygame.font.Font(None, 18)
        self.font_med = pygame.font.Font(None, 22)
        self.font_large = pygame.font.Font(None, 30)

        self.apps = app_manager.load_db()
        self.page = 0
        self.page_count = max(1, -(-len(self.apps) // config.APPS_PER_PAGE))

        self._last_status_poll = 0
        self._battery = battery.read()
        self._wifi = netstatus.wifi_status()
        self._bt = netstatus.bluetooth_status()

        self._icon_cache = {}
        self.running = True

    def _init_display(self):
        flags = 0
        # Fullscreen on real hardware; the FRAMEBUFFER driver is set via
        # env var by the systemd service / install script on the Pi.
        try:
            self.screen = pygame.display.set_mode(
                (config.SCREEN_W, config.SCREEN_H), flags
            )
        except pygame.error as e:
            log.error("Failed to init display: %s", e)
            raise
        pygame.display.set_caption("PhoneOS")

    # ---------------------------------------------------------- rendering
    def _get_icon(self, app):
        if app["id"] in self._icon_cache:
            return self._icon_cache[app["id"]]
        surf = None
        if app.get("icon"):
            try:
                surf = pygame.image.load(app["icon"]).convert_alpha()
                surf = pygame.transform.smoothscale(
                    surf, (config.ICON_SIZE, config.ICON_SIZE)
                )
            except (pygame.error, OSError):
                surf = None
        if surf is None:
            surf = pygame.Surface((config.ICON_SIZE, config.ICON_SIZE))
            surf.fill(config.ACCENT_COLOR)
            label = self.font_large.render(app["name"][:1].upper(), True, (255, 255, 255))
            rect = label.get_rect(center=(config.ICON_SIZE // 2, config.ICON_SIZE // 2))
            surf.blit(label, rect)
        self._icon_cache[app["id"]] = surf
        return surf

    def _draw_statusbar(self):
        bar = pygame.Rect(0, 0, config.SCREEN_W, config.STATUSBAR_H)
        pygame.draw.rect(self.screen, config.STATUSBAR_COLOR, bar)

        time_str = time.strftime("%H:%M")
        t_surf = self.font_small.render(time_str, True, config.FG_COLOR)
        self.screen.blit(t_surf, (8, 6))

        connected, ssid = self._wifi
        wifi_color = config.ACCENT_COLOR if connected else (90, 90, 90)
        wifi_label = "WiFi" if connected else "--"
        w_surf = self.font_small.render(wifi_label, True, wifi_color)
        self.screen.blit(w_surf, (config.SCREEN_W - 140, 6))

        bt_color = config.ACCENT_COLOR if self._bt else (90, 90, 90)
        bt_surf = self.font_small.render("BT", True, bt_color)
        self.screen.blit(bt_surf, (config.SCREEN_W - 90, 6))

        pct = self._battery["percent"]
        pct_str = f"{pct}%" if pct >= 0 else "?"
        if self._battery["charging"]:
            pct_str += " +"
        b_surf = self.font_small.render(pct_str, True, config.FG_COLOR)
        self.screen.blit(b_surf, (config.SCREEN_W - 48, 6))

    def _icon_rects(self):
        """Yield (rect, app) for icons on the current page."""
        start = self.page * config.APPS_PER_PAGE
        page_apps = self.apps[start:start + config.APPS_PER_PAGE]

        margin_x = 20
        margin_y = 20
        cell_w = (config.SCREEN_W - 2 * margin_x) // config.COLS
        cell_h = 100

        top = config.STATUSBAR_H + margin_y
        for i, app in enumerate(page_apps):
            col = i % config.COLS
            row = i // config.COLS
            cx = margin_x + col * cell_w + cell_w // 2
            cy = top + row * cell_h + config.ICON_SIZE // 2
            rect = pygame.Rect(0, 0, config.ICON_SIZE, config.ICON_SIZE)
            rect.center = (cx, cy)
            yield rect, app, (cx, cy)

    def _draw_home(self):
        self.screen.fill(config.BG_COLOR)
        for rect, app, (cx, cy) in self._icon_rects():
            icon = self._get_icon(app)
            self.screen.blit(icon, rect)
            label = self.font_small.render(app["name"], True, config.FG_COLOR)
            lrect = label.get_rect(center=(cx, cy + config.ICON_SIZE // 2 + 12))
            self.screen.blit(label, lrect)

        if self.page_count > 1:
            dots = ""
            for i in range(self.page_count):
                dots += "●" if i == self.page else "○"
            d_surf = self.font_small.render(dots, True, config.FG_COLOR)
            drect = d_surf.get_rect(midbottom=(config.SCREEN_W // 2, config.SCREEN_H - 8))
            self.screen.blit(d_surf, drect)

        self._draw_statusbar()

    # ------------------------------------------------------------- events
    def _poll_status(self):
        now = time.time()
        if now - self._last_status_poll > 5:
            self._battery = battery.read()
            self._wifi = netstatus.wifi_status()
            self._bt = netstatus.bluetooth_status()
            self._last_status_poll = now

    def _handle_tap(self, pos):
        for rect, app, _ in self._icon_rects():
            if rect.collidepoint(pos):
                self.launch_app(app)
                return
        # swipe zones: left/right thirds of screen tap to change page
        if self.page_count > 1:
            if pos[0] < config.SCREEN_W // 4:
                self.page = (self.page - 1) % self.page_count
            elif pos[0] > config.SCREEN_W - config.SCREEN_W // 4:
                self.page = (self.page + 1) % self.page_count

    def launch_app(self, app):
        log.info("Launching %s", app["id"])
        pygame.display.quit()
        pygame.mouse.set_visible(True)
        try:
            env = os.environ.copy()
            subprocess.run([sys.executable, app["entry"]], cwd=app["path"], env=env)
        except Exception as e:  # noqa: BLE001
            log.error("App %s crashed: %s", app["id"], e)
        pygame.display.init()
        pygame.mouse.set_visible(False)
        self._init_display()
        # apps may have changed settings/apps list
        self.settings = settings.load()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    if event.type == pygame.FINGERDOWN:
                        pos = (int(event.x * config.SCREEN_W), int(event.y * config.SCREEN_H))
                    else:
                        pos = event.pos
                    self._handle_tap(pos)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.running = False

            self._poll_status()
            self._draw_home()
            pygame.display.flip()
            self.clock.tick(config.FPS)

        pygame.quit()


def main():
    os.makedirs(config.LOGS_DIR, exist_ok=True) if os.path.isdir(config.ROOT) else None
    app_manager.rebuild_db()
    Launcher().run()


if __name__ == "__main__":
    main()

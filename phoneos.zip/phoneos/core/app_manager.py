"""Scans /phoneos/apps for manifest.json files and maintains the
installed apps database at /phoneos/system/installed_apps.json."""
import json
import os
import logging

from core import config

log = logging.getLogger("phoneos.app_manager")


def _read_manifest(app_dir):
    manifest_path = os.path.join(app_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        return None
    try:
        with open(manifest_path, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log.warning("Bad manifest %s: %s", manifest_path, e)
        return None

    required = ("id", "name", "version", "entry")
    if not all(k in data for k in required):
        log.warning("Manifest missing required fields: %s", manifest_path)
        return None

    entry_path = os.path.join(app_dir, data["entry"])
    if not os.path.isfile(entry_path):
        log.warning("Entry point missing for %s: %s", data["id"], entry_path)
        return None

    icon_name = data.get("icon", "icon.png")
    icon_path = os.path.join(app_dir, icon_name)

    return {
        "id": data["id"],
        "name": data["name"],
        "version": data["version"],
        "path": app_dir,
        "entry": entry_path,
        "icon": icon_path if os.path.isfile(icon_path) else None,
        "type": data.get("type", "user"),
        "description": data.get("description", ""),
    }


def scan_apps():
    """Scan the apps directory and return a list of valid app records."""
    apps = []
    if not os.path.isdir(config.APPS_DIR):
        return apps
    for entry in sorted(os.listdir(config.APPS_DIR)):
        app_dir = os.path.join(config.APPS_DIR, entry)
        if not os.path.isdir(app_dir):
            continue
        record = _read_manifest(app_dir)
        if record:
            apps.append(record)
    return apps


def rebuild_db():
    """Rescan apps and write the installed_apps.json database."""
    apps = scan_apps()
    os.makedirs(config.SYSTEM_DIR, exist_ok=True)
    with open(config.INSTALLED_APPS_DB, "w") as f:
        json.dump({"apps": apps}, f, indent=2)
    return apps


def load_db():
    """Load installed_apps.json, rebuilding it if missing or empty."""
    if not os.path.isfile(config.INSTALLED_APPS_DB):
        return rebuild_db()
    try:
        with open(config.INSTALLED_APPS_DB, "r") as f:
            data = json.load(f)
        apps = data.get("apps", [])
        if not apps:
            return rebuild_db()
        return apps
    except (json.JSONDecodeError, OSError):
        return rebuild_db()


def uninstall_app(app_id):
    """Remove an app's files and rebuild the db. Returns True on success."""
    import shutil
    apps = load_db()
    target = next((a for a in apps if a["id"] == app_id), None)
    if not target:
        return False
    if target["type"] == "system":
        log.warning("Refusing to uninstall system app: %s", app_id)
        return False
    try:
        shutil.rmtree(target["path"])
    except OSError as e:
        log.error("Failed to remove %s: %s", target["path"], e)
        return False
    rebuild_db()
    return True

"""PhoneOS core configuration."""
import os

ROOT = "/phoneos"
CORE_DIR = os.path.join(ROOT, "core")
SYSTEM_DIR = os.path.join(ROOT, "system")
APPS_DIR = os.path.join(ROOT, "apps")
PACKAGES_DIR = os.path.join(ROOT, "packages")
CACHE_DIR = os.path.join(ROOT, "cache")
DOWNLOADS_DIR = os.path.join(ROOT, "downloads")
THEMES_DIR = os.path.join(ROOT, "themes")
WALLPAPERS_DIR = os.path.join(ROOT, "wallpapers")
USER_DIR = os.path.join(ROOT, "user")
LOGS_DIR = os.path.join(ROOT, "logs")

INSTALLED_APPS_DB = os.path.join(SYSTEM_DIR, "installed_apps.json")
SETTINGS_FILE = os.path.join(USER_DIR, "settings.json")

# Waveshare 3.5" capacitive touch LCD, portrait
SCREEN_W = 320
SCREEN_H = 480

FPS = 30

# Grid layout
ICON_SIZE = 64
COLS = 3
ROWS = 4
APPS_PER_PAGE = COLS * ROWS

# Colors
BG_COLOR = (12, 12, 16)
FG_COLOR = (230, 230, 230)
ACCENT_COLOR = (70, 140, 255)
STATUSBAR_COLOR = (20, 20, 26)
STATUSBAR_H = 28

DEFAULT_SETTINGS = {
    "brightness": 100,
    "wifi_enabled": True,
    "bluetooth_enabled": True,
    "developer_mode": False,
    "theme": "default",
    "wallpaper": None,
}

#!/usr/bin/env python3
"""PhoneOS entry point. Run this on boot (see phoneos.service)."""
import os
import sys

ROOT = "/phoneos"
sys.path.insert(0, ROOT)

REQUIRED_DIRS = [
    "core", "system", "apps", "packages", "cache",
    "downloads", "themes", "wallpapers", "user", "logs",
]


def ensure_dirs():
    for d in REQUIRED_DIRS:
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)


def main():
    ensure_dirs()
    from core import launcher
    launcher.main()


if __name__ == "__main__":
    main()
